const express = require('express');
const crypto = require('crypto');
const { Pool } = require('pg');
const { parseAfterSalesText } = require('./rules/parser');
const { catalog: seedCatalog } = require('./rules/catalog');
const { normalizeAnengTracking } = require('./rules/tracking');
const { normalizeOrderNo, safeCase } = require('./integrations/feishu');

const app = express();
app.use(express.json({ limit: '1mb' }));

const pool = new Pool({
  host: process.env.POSTGRES_HOST || 'postgres',
  port: Number(process.env.POSTGRES_PORT || 5432),
  database: process.env.POSTGRES_DB,
  user: process.env.POSTGRES_USER,
  password: process.env.POSTGRES_PASSWORD,
});

const sessions = new Map();
const cookie = (req, name) => (req.headers.cookie || '').split(';').map((x) => x.trim()).find((x) => x.startsWith(`${name}=`))?.slice(name.length + 1);
const hashPassword = (password, salt = crypto.randomBytes(16).toString('hex')) => {
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `${salt}:${hash}`;
};
const verifyPassword = (password, stored) => {
  const [salt, hash] = String(stored || '').split(':');
  if (!salt || !hash) return false;
  const actual = crypto.scryptSync(String(password), salt, 64);
  const expected = Buffer.from(hash, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
};
const safeUser = (row) => ({ id: row.id, username: row.username, displayName: row.display_name, role: row.role, active: row.active });
const normalizeTracking = (value) => String(value || '').trim().replace(/\s+/g, '').toUpperCase();
const trackingHash = (value) => crypto
  .createHmac('sha256', process.env.SCAN_HASH_SECRET || process.env.POSTGRES_PASSWORD || 'after-sales')
  .update(normalizeTracking(value))
  .digest('hex');

async function migrate() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY, username VARCHAR(60) UNIQUE NOT NULL, display_name VARCHAR(100) NOT NULL,
      password_hash TEXT NOT NULL, role VARCHAR(30) NOT NULL DEFAULT 'customer_service',
      active BOOLEAN NOT NULL DEFAULT true, created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS product_catalog (
      id BIGSERIAL PRIMARY KEY, model VARCHAR(100) UNIQUE NOT NULL, product_type VARCHAR(100),
      aliases TEXT NOT NULL DEFAULT '', colors TEXT NOT NULL DEFAULT '', color_required BOOLEAN NOT NULL DEFAULT false,
      active BOOLEAN NOT NULL DEFAULT true, created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS audit_logs (
      id BIGSERIAL PRIMARY KEY, case_id BIGINT, user_id BIGINT, action VARCHAR(60) NOT NULL,
      detail TEXT, created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS package_scans (
      id BIGSERIAL PRIMARY KEY,
      tracking_no VARCHAR(100) UNIQUE NOT NULL,
      carton_spec VARCHAR(100) NOT NULL,
      batch_id VARCHAR(100) NOT NULL,
      created_by BIGINT,
      created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS scan_registry (
      tracking_hash CHAR(64) PRIMARY KEY,
      scan_type VARCHAR(30) NOT NULL,
      carrier VARCHAR(50) NOT NULL DEFAULT '未分类',
      created_by BIGINT,
      created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS scan_batches (
      batch_id VARCHAR(100) PRIMARY KEY,
      batch_name VARCHAR(150) NOT NULL,
      copied_at TIMESTAMPTZ,
      created_by BIGINT,
      created_at TIMESTAMPTZ DEFAULT now(),
      updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS ai_parse_cache (
      cache_key CHAR(64) PRIMARY KEY,
      result JSONB NOT NULL,
      prompt_tokens INTEGER DEFAULT 0,
      completion_tokens INTEGER DEFAULT 0,
      cache_hit_tokens INTEGER DEFAULT 0,
      hit_count INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT now(),
      updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS idx_package_scans_batch ON package_scans(batch_id);
    CREATE INDEX IF NOT EXISTS idx_package_scans_created ON package_scans(created_at);
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS color VARCHAR(50);
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS parsed_raw_text TEXT;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS parse_warnings TEXT;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS assigned_to BIGINT;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS created_by BIGINT;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS priority VARCHAR(20) NOT NULL DEFAULT 'normal';
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS due_at TIMESTAMPTZ;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS tags TEXT NOT NULL DEFAULT '';
    ALTER TABLE scan_registry ADD COLUMN IF NOT EXISTS carrier VARCHAR(50) NOT NULL DEFAULT '未分类';
    CREATE INDEX IF NOT EXISTS idx_after_sales_cases_order_no ON after_sales_cases(order_no);
    CREATE INDEX IF NOT EXISTS idx_after_sales_cases_status ON after_sales_cases(status);
    CREATE INDEX IF NOT EXISTS idx_after_sales_cases_created_at ON after_sales_cases(created_at);
    CREATE INDEX IF NOT EXISTS idx_after_sales_cases_assigned_to ON after_sales_cases(assigned_to);
  `);
  const oldScans = await pool.query('SELECT tracking_no,created_by,created_at FROM package_scans');
  for (const scan of oldScans.rows) {
    await pool.query(
      `INSERT INTO scan_registry(tracking_hash,scan_type,carrier,created_by,created_at)
       VALUES($1,'aneng','安能',$2,$3) ON CONFLICT DO NOTHING`,
      [trackingHash(normalizeAnengTracking(scan.tracking_no)), scan.created_by, scan.created_at]
    );
  }
  await pool.query(`UPDATE scan_registry SET carrier='安能' WHERE scan_type='aneng' AND carrier='未分类'`);
  await pool.query(`
    INSERT INTO scan_batches(batch_id,batch_name,created_by,created_at)
    SELECT batch_id,'历史安能批次',min(created_by),min(created_at)
    FROM package_scans GROUP BY batch_id
    ON CONFLICT(batch_id) DO NOTHING
  `);
  const admin = await pool.query('SELECT id FROM users WHERE username=$1', ['admin']);
  if (!admin.rows[0]) {
    await pool.query(
      'INSERT INTO users(username,display_name,password_hash,role) VALUES($1,$2,$3,$4)',
      ['admin', '系统管理员', hashPassword(process.env.ADMIN_PASSWORD || 'a123456'), 'admin']
    );
  }
  for (const item of seedCatalog) {
    await pool.query(
      `INSERT INTO product_catalog(model,product_type,aliases,colors,color_required)
       VALUES($1,$2,$3,$4,$5) ON CONFLICT(model) DO NOTHING`,
      [item.model, item.productType, item.aliases.join(','), item.colors.join(','), item.colorRequired]
    );
  }
}

async function catalogForParser() {
  const { rows } = await pool.query('SELECT * FROM product_catalog WHERE active=true ORDER BY length(model) DESC');
  return rows.map((x) => ({
    model: x.model,
    productType: x.product_type,
    aliases: x.aliases.split(',').map((v) => v.trim()).filter(Boolean),
    colors: x.colors.split(',').map((v) => v.trim()).filter(Boolean),
    colorRequired: x.color_required,
  }));
}

function needsAi(parsed) {
  return !parsed.orderNo || !parsed.model || parsed.platform === '未知平台';
}

function mergeAiResult(local, ai, catalog) {
  const models = new Set(catalog.map((item) => item.model));
  const orderNo = String(ai.orderNo || '').trim();
  const validOrder = /^\d{5,8}-\d{10,24}$|^\d{12,22}$/.test(orderNo);
  const model = models.has(ai.model) ? ai.model : local.model;
  const item = catalog.find((entry) => entry.model === model);
  const color = item && !item.colorRequired ? '' : String(ai.color || local.color || '').trim();
  const result = {
    ...local,
    platform: local.platform !== '未知平台' ? local.platform : (['拼多多','抖店','淘宝/天猫'].includes(ai.platform) ? ai.platform : local.platform),
    orderNo: local.orderNo || (validOrder ? orderNo : ''),
    type: ['补发','换货','退件'].includes(ai.type) ? ai.type : local.type,
    model,
    productName: model || local.productName,
    productType: item?.productType || local.productType,
    quantity: Math.max(1, Math.min(999, Number(ai.quantity || local.quantity || 1))),
    color,
    colorRequired: item?.colorRequired ?? local.colorRequired,
  };
  const warnings = [];
  if (!result.orderNo) warnings.push('未识别订单号');
  if (result.platform === '未知平台') warnings.push('未识别平台');
  if (!result.model) warnings.push('未识别商品型号');
  if (result.colorRequired && !result.color) warnings.push('该商品需要确认颜色');
  if (Number(ai.confidence || 0) < 0.75) warnings.push('AI 识别置信度较低，请人工确认');
  return { ...result, warnings, needReview: warnings.length > 0 };
}

async function parseWithDeepSeek(text, catalog) {
  if (!process.env.DEEPSEEK_API_KEY) throw Object.assign(new Error('尚未配置 DeepSeek API Key'), { status: 503 });
  const catalogText = catalog.map((item) =>
    `${item.model}|别名:${item.aliases.join('/') || item.model}|颜色:${item.colors.join('/') || '无'}|颜色必填:${item.colorRequired ? '是' : '否'}`
  ).join('\n');
  const promptVersion = 'after-sales-v1';
  const cacheKey = crypto.createHash('sha256').update(`${promptVersion}\n${catalogText}\n${String(text).trim()}`).digest('hex');
  const cached = await pool.query('SELECT result FROM ai_parse_cache WHERE cache_key=$1', [cacheKey]);
  if (cached.rows[0]) {
    await pool.query('UPDATE ai_parse_cache SET hit_count=hit_count+1,updated_at=now() WHERE cache_key=$1', [cacheKey]);
    return { result: cached.rows[0].result, cached: true, usage: null };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}` },
      signal: controller.signal,
      body: JSON.stringify({
        model: process.env.DEEPSEEK_MODEL || 'deepseek-v4-flash',
        thinking: { type: 'disabled' },
        response_format: { type: 'json_object' },
        max_tokens: 260,
        temperature: 0,
        messages: [
          { role: 'system', content: `你是网店售后信息提取器。只输出 json，不解释。不得编造订单号和商品。商品必须从目录选择。输出格式：{"platform":"","orderNo":"","type":"补发","model":"","quantity":1,"color":"","confidence":0.0}\n商品目录：\n${catalogText}` },
          { role: 'user', content: `请从这句客服原话提取 json：${String(text).slice(0, 500)}` },
        ],
      }),
    });
    const payload = await response.json();
    if (!response.ok) throw Object.assign(new Error(payload.error?.message || 'DeepSeek 调用失败'), { status: 502 });
    const content = payload.choices?.[0]?.message?.content;
    if (!content) throw Object.assign(new Error('DeepSeek 返回内容为空'), { status: 502 });
    const result = JSON.parse(content);
    const usage = payload.usage || {};
    await pool.query(
      `INSERT INTO ai_parse_cache(cache_key,result,prompt_tokens,completion_tokens,cache_hit_tokens)
       VALUES($1,$2,$3,$4,$5)`,
      [cacheKey, result, usage.prompt_tokens || 0, usage.completion_tokens || 0, usage.prompt_cache_hit_tokens || 0]
    );
    return { result, cached: false, usage };
  } finally {
    clearTimeout(timer);
  }
}

async function auth(req, res, next) {
  const token = cookie(req, 'as_session');
  const session = token && sessions.get(token);
  if (!session || session.expires < Date.now()) return res.status(401).json({ error: '请先登录' });
  const { rows } = await pool.query('SELECT * FROM users WHERE id=$1 AND active=true', [session.userId]);
  if (!rows[0]) return res.status(401).json({ error: '账号不可用' });
  req.user = rows[0];
  next();
}
function integrationAuth(req, res, next) {
  const expected = String(process.env.FEISHU_INTEGRATION_TOKEN || '');
  if (!expected) return res.status(503).json({ error: '飞书集成尚未配置' });
  const authorization = String(req.headers.authorization || '');
  const provided = authorization.startsWith('Bearer ') ? authorization.slice(7).trim() : '';
  const expectedHash = crypto.createHash('sha256').update(expected).digest();
  const providedHash = crypto.createHash('sha256').update(provided).digest();
  if (!provided || !crypto.timingSafeEqual(expectedHash, providedHash)) {
    return res.status(401).json({ error: '飞书集成鉴权失败' });
  }
  next();
}
const allow = (...roles) => (req, res, next) => roles.includes(req.user.role) ? next() : res.status(403).json({ error: '没有操作权限' });
const run = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
async function audit(req, action, caseId, detail = '') {
  await pool.query('INSERT INTO audit_logs(case_id,user_id,action,detail) VALUES($1,$2,$3,$4)', [caseId || null, req.user.id, action, detail]);
}

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'after-sales-api', version: '1.5.1' }));
app.post('/api/auth/login', run(async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM users WHERE username=$1 AND active=true', [String(req.body.username || '').trim()]);
  if (!rows[0] || !verifyPassword(req.body.password, rows[0].password_hash)) return res.status(401).json({ error: '账号或密码错误' });
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { userId: rows[0].id, expires: Date.now() + 12 * 60 * 60 * 1000 });
  res.setHeader('Set-Cookie', `as_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=43200`);
  res.json(safeUser(rows[0]));
}));
app.post('/api/auth/logout', auth, (req, res) => {
  sessions.delete(cookie(req, 'as_session'));
  res.setHeader('Set-Cookie', 'as_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  res.json({ ok: true });
});
app.get('/api/auth/me', auth, (req, res) => res.json(safeUser(req.user)));
app.post('/api/auth/change-password', auth, run(async (req, res) => {
  if (!verifyPassword(req.body.oldPassword, req.user.password_hash)) return res.status(400).json({ error: '原密码不正确' });
  if (String(req.body.newPassword || '').length < 8) return res.status(400).json({ error: '新密码至少8位' });
  await pool.query('UPDATE users SET password_hash=$1,updated_at=now() WHERE id=$2', [hashPassword(req.body.newPassword), req.user.id]);
  await audit(req, '修改登录密码', null);
  res.json({ ok: true });
}));

app.post('/api/parse', auth, run(async (req, res) => {
  const text = String(req.body.text || '').trim();
  const catalog = await catalogForParser();
  const local = parseAfterSalesText(text, catalog);
  const mode = req.query.ai || 'auto';
  const shouldCall = mode === 'force' || (mode === 'auto' && needsAi(local));
  if (!shouldCall || !process.env.DEEPSEEK_API_KEY) {
    return res.json({ ...local, source: 'rules', aiAvailable: Boolean(process.env.DEEPSEEK_API_KEY) });
  }
  try {
    const ai = await parseWithDeepSeek(text, catalog);
    res.json({ ...mergeAiResult(local, ai.result, catalog), source: ai.cached ? 'ai_cache' : 'ai', aiAvailable: true, aiUsage: ai.usage });
  } catch (error) {
    if (mode === 'force') throw error;
    res.json({ ...local, source: 'rules_fallback', aiAvailable: true, aiError: 'AI 暂时不可用，已使用本地规则' });
  }
}));

app.get('/api/dashboard', auth, run(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT count(*)::int total,
      count(*) FILTER (WHERE status='need_review')::int need_review,
      count(*) FILTER (WHERE status IN ('pending','processing'))::int pending,
      count(*) FILTER (WHERE status='done')::int done,
      count(*) FILTER (WHERE created_at::date=current_date)::int today,
      count(*) FILTER (WHERE due_at < now() AND status NOT IN ('done','cancelled'))::int overdue,
      count(*) FILTER (WHERE resend_tracking_no IS NULL OR resend_tracking_no='')::int no_tracking
    FROM after_sales_cases`);
  res.json(rows[0]);
}));

app.get('/api/cases', auth, run(async (req, res) => {
  const params = [];
  const where = [];
  if (req.query.status) { params.push(req.query.status); where.push(`c.status=$${params.length}`); }
  if (req.query.type) { params.push(req.query.type); where.push(`c.type=$${params.length}`); }
  if (req.query.platform) { params.push(req.query.platform); where.push(`c.platform=$${params.length}`); }
  if (req.query.priority) { params.push(req.query.priority); where.push(`c.priority=$${params.length}`); }
  if (req.query.createdBy) { params.push(req.query.createdBy); where.push(`c.created_by=$${params.length}`); }
  if (req.query.assignedTo) { params.push(req.query.assignedTo); where.push(`c.assigned_to=$${params.length}`); }
  if (req.query.dateFrom) { params.push(req.query.dateFrom); where.push(`c.created_at >= $${params.length}::date`); }
  if (req.query.dateTo) { params.push(req.query.dateTo); where.push(`c.created_at < ($${params.length}::date + interval '1 day')`); }
  if (req.query.tracking === 'missing') where.push(`coalesce(c.resend_tracking_no,'')=''`);
  if (req.query.tracking === 'filled') where.push(`coalesce(c.resend_tracking_no,'')<>''`);
  if (req.query.overdue === 'true') where.push(`c.due_at < now() AND c.status NOT IN ('done','cancelled')`);
  if (req.query.keyword) {
    params.push(`%${req.query.keyword}%`);
    where.push(`concat_ws(' ',c.order_no,c.platform,c.shop_name,c.customer_name,c.customer_phone,c.product_name,c.product_sku,c.color,c.resend_tracking_no,c.reason,c.remark,c.tags) ILIKE $${params.length}`);
  }
  const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 50));
  const page = Math.max(1, Number(req.query.page) || 1);
  const count = await pool.query(`SELECT count(*)::int total FROM after_sales_cases c ${where.length ? `WHERE ${where.join(' AND ')}` : ''}`, params);
  params.push(limit, (page - 1) * limit);
  const { rows } = await pool.query(
    `SELECT c.*,u.display_name created_by_name,a.display_name assigned_to_name
     FROM after_sales_cases c
     LEFT JOIN users u ON u.id=c.created_by LEFT JOIN users a ON a.id=c.assigned_to
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY CASE c.priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 ELSE 3 END,c.created_at DESC
     LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
  res.json({ rows, total: count.rows[0].total, page, pageSize: limit });
}));

app.get('/api/cases/export.csv', auth, run(async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM after_sales_cases ORDER BY created_at DESC LIMIT 5000');
  const fields = ['case_no','type','status','platform','order_no','product_name','product_sku','quantity','color','resend_tracking_no','reason','remark','created_at'];
  const esc = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;
  const csv = '\ufeff' + [fields.join(','), ...rows.map((r) => fields.map((f) => esc(r[f])).join(','))].join('\r\n');
  res.type('text/csv').set('Content-Disposition', 'attachment; filename=after-sales.csv').send(csv);
}));

app.get('/api/cases/:id', auth, run(async (req, res) => {
  const item = await pool.query('SELECT * FROM after_sales_cases WHERE id=$1', [req.params.id]);
  if (!item.rows[0]) return res.status(404).json({ error: '记录不存在' });
  const logs = await pool.query('SELECT l.*,u.display_name FROM audit_logs l LEFT JOIN users u ON u.id=l.user_id WHERE case_id=$1 ORDER BY l.created_at DESC', [req.params.id]);
  res.json({ case: item.rows[0], logs: logs.rows });
}));

app.get('/api/integrations/feishu/cases/by-order/:orderNo', integrationAuth, run(async (req, res) => {
  const orderNo = normalizeOrderNo(req.params.orderNo);
  if (!orderNo) return res.status(400).json({ error: '订单号格式不正确' });
  const { rows } = await pool.query(
    `SELECT id,case_no,type,status,platform,order_no,product_name,product_sku,quantity,color,
      resend_tracking_no,reason,solution,remark,created_at,updated_at,completed_at
     FROM after_sales_cases
     WHERE order_no=$1
     ORDER BY CASE WHEN status='cancelled' THEN 1 ELSE 0 END,created_at DESC
     LIMIT 10`,
    [orderNo]
  );
  res.json({ orderNo, found: rows.length > 0, case: safeCase(rows[0]), cases: rows.map(safeCase) });
}));

app.post('/api/cases/from-text', auth, allow('admin', 'customer_service'), run(async (req, res) => {
  const text = String(req.body.text || '').trim();
  if (!text) return res.status(400).json({ error: '请输入客服原话' });
  const parsed = { ...parseAfterSalesText(text, await catalogForParser()), ...(req.body.overrides || {}) };
  const duplicate = parsed.orderNo ? await pool.query("SELECT case_no FROM after_sales_cases WHERE order_no=$1 AND status<>'cancelled' LIMIT 1", [parsed.orderNo]) : { rows: [] };
  if (duplicate.rows[0] && !req.body.allowDuplicate) return res.status(409).json({ error: `该订单已有售后单 ${duplicate.rows[0].case_no}`, duplicate: true, parsed });
  const caseNo = `AS${new Date().toISOString().slice(0,10).replaceAll('-','')}${String(Date.now()).slice(-6)}`;
  const warnings = parsed.warnings || [];
  const { rows } = await pool.query(
    `INSERT INTO after_sales_cases(case_no,type,status,platform,shop_name,order_no,customer_name,customer_phone,
      product_name,product_sku,quantity,color,reason,solution,parsed_raw_text,parse_warnings,remark,created_by)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18) RETURNING *`,
    [caseNo,parsed.type,parsed.needReview?'need_review':'pending',parsed.platform,req.body.shopName||'',parsed.orderNo,
      req.body.customerName||'',req.body.customerPhone||'',parsed.productName,parsed.model,Number(parsed.quantity)||1,parsed.color||'',
      req.body.reason||text,req.body.solution||parsed.type,text,warnings.join('；'),req.body.remark||'',req.user.id]
  );
  await audit(req, '创建售后单', rows[0].id, text);
  res.status(201).json({ case: rows[0], parsed });
}));

app.patch('/api/cases/:id', auth, allow('admin', 'customer_service'), run(async (req, res) => {
  const allowed = ['type','status','platform','shop_name','order_no','customer_name','customer_phone','product_name','product_sku','quantity','color','reason','solution','remark','priority','due_at','tags','assigned_to'];
  const entries = Object.entries(req.body).filter(([key]) => allowed.includes(key));
  if (!entries.length) return res.status(400).json({ error: '没有可修改内容' });
  const values = entries.map(([, value]) => value);
  values.push(req.params.id);
  const set = entries.map(([key], i) => `${key}=$${i + 1}`).join(',');
  const { rows } = await pool.query(`UPDATE after_sales_cases SET ${set},updated_at=now() WHERE id=$${values.length} RETURNING *`, values);
  if (!rows[0]) return res.status(404).json({ error: '记录不存在' });
  await audit(req, '修改售后单', rows[0].id, entries.map(([k]) => k).join(','));
  res.json(rows[0]);
}));

app.patch('/api/cases/:id/tracking', auth, allow('admin', 'printer'), run(async (req, res) => {
  const trackingNo = String(req.body.trackingNo || '').trim().replace(/\s+/g, '');
  if (!/^[A-Za-z0-9-]{6,40}$/.test(trackingNo)) return res.status(400).json({ error: '快递单号格式不正确' });
  const { rows } = await pool.query(
    `UPDATE after_sales_cases SET resend_tracking_no=$1,status='done',completed_at=now(),updated_at=now() WHERE id=$2 RETURNING *`,
    [trackingNo, req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: '记录不存在' });
  await audit(req, '填写快递单号', rows[0].id, trackingNo);
  res.json(rows[0]);
}));

app.get('/api/package-scans', auth, run(async (req, res) => {
  const params = [];
  const where = [];
  if (req.query.batchId) { params.push(req.query.batchId); where.push(`s.batch_id=$${params.length}`); }
  if (req.query.date) { params.push(req.query.date); where.push(`s.created_at::date=$${params.length}::date`); }
  const { rows } = await pool.query(
    `SELECT s.*,u.display_name created_by_name FROM package_scans s LEFT JOIN users u ON u.id=s.created_by
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY s.created_at DESC LIMIT 2000`, params);
  res.json(rows);
}));

app.post('/api/package-scans', auth, run(async (req, res) => {
  const originalTrackingNo = normalizeTracking(req.body.trackingNo);
  const trackingNo = normalizeAnengTracking(originalTrackingNo);
  const cartonSpec = String(req.body.cartonSpec || '').trim();
  const batchId = String(req.body.batchId || '').trim();
  if (!/^[A-Za-z0-9-]{6,40}$/.test(trackingNo)) return res.status(400).json({ error: '未识别到有效快递单号' });
  if (!cartonSpec) return res.status(400).json({ error: '请先选择纸箱规格' });
  if (!batchId) return res.status(400).json({ error: '扫码批次无效，请刷新页面' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const unique = await client.query(
      `INSERT INTO scan_registry(tracking_hash,scan_type,carrier,created_by) VALUES($1,'aneng','安能',$2)
       ON CONFLICT DO NOTHING RETURNING tracking_hash`,
      [trackingHash(trackingNo), req.user.id]);
    if (!unique.rows[0]) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: '该单号已经扫描过，不能重复保存', duplicate: true });
    }
    await client.query(
      `INSERT INTO scan_batches(batch_id,batch_name,created_by) VALUES($1,$2,$3)
       ON CONFLICT(batch_id) DO NOTHING`,
      [batchId, req.body.batchName || '安能扫码批次', req.user.id]);
    const { rows } = await client.query(
      'INSERT INTO package_scans(tracking_no,carton_spec,batch_id,created_by) VALUES($1,$2,$3,$4) RETURNING *',
      [trackingNo, cartonSpec, batchId, req.user.id]);
    await client.query('UPDATE scan_batches SET copied_at=NULL,updated_at=now() WHERE batch_id=$1', [batchId]);
    await client.query('COMMIT');
    res.status(201).json({ ...rows[0], normalized_from: originalTrackingNo !== trackingNo ? originalTrackingNo : null });
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}));

app.delete('/api/package-scans/:id', auth, run(async (req, res) => {
  const { rows } = await pool.query('DELETE FROM package_scans WHERE id=$1 RETURNING tracking_no,batch_id', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: '扫码记录不存在' });
  await Promise.all([
    pool.query('DELETE FROM scan_registry WHERE tracking_hash=$1 AND scan_type=$2', [trackingHash(normalizeAnengTracking(rows[0].tracking_no)), 'aneng']),
    pool.query('UPDATE scan_batches SET copied_at=NULL,updated_at=now() WHERE batch_id=$1', [rows[0].batch_id])
  ]);
  res.json({ ok: true });
}));

app.patch('/api/package-scans/:id/spec', auth, run(async (req, res) => {
  const cartonSpec = String(req.body.cartonSpec || '').trim();
  if (!cartonSpec) return res.status(400).json({ error: '纸箱规格不能为空' });
  const { rows } = await pool.query(
    'UPDATE package_scans SET carton_spec=$1 WHERE id=$2 RETURNING *',
    [cartonSpec, req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: '扫码记录不存在' });
  await pool.query('UPDATE scan_batches SET copied_at=NULL,updated_at=now() WHERE batch_id=$1', [rows[0].batch_id]);
  res.json(rows[0]);
}));

app.get('/api/scan-batches', auth, run(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT b.batch_id,b.batch_name,b.copied_at,b.created_at,
      count(s.id)::int total,
      string_agg(DISTINCT s.carton_spec, '、' ORDER BY s.carton_spec) specs
    FROM scan_batches b
    LEFT JOIN package_scans s ON s.batch_id=b.batch_id
    GROUP BY b.batch_id,b.batch_name,b.copied_at,b.created_at
    ORDER BY b.created_at DESC LIMIT 100`);
  res.json(rows);
}));

app.patch('/api/scan-batches/:batchId', auth, run(async (req, res) => {
  const fields = [];
  const values = [];
  if (req.body.batchName !== undefined) { values.push(String(req.body.batchName).trim()); fields.push(`batch_name=$${values.length}`); }
  if (req.body.copied === true) fields.push('copied_at=now()');
  if (req.body.copied === false) fields.push('copied_at=NULL');
  if (!fields.length) return res.status(400).json({ error: '没有可修改内容' });
  values.push(req.params.batchId);
  const { rows } = await pool.query(
    `UPDATE scan_batches SET ${fields.join(',')},updated_at=now() WHERE batch_id=$${values.length} RETURNING *`, values);
  if (!rows[0]) return res.status(404).json({ error: '批次不存在' });
  res.json(rows[0]);
}));

app.get('/api/shipment-volume/today', auth, run(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT count(*)::int total FROM scan_registry WHERE created_at::date=current_date`);
  res.json(rows[0]);
}));

app.post('/api/shipment-volume/scan', auth, run(async (req, res) => {
  const trackingNo = normalizeAnengTracking(normalizeTracking(req.body.trackingNo));
  const carrier = String(req.body.carrier || '未分类').trim().slice(0, 50) || '未分类';
  if (!/^[A-Z0-9-]{6,40}$/.test(trackingNo)) return res.status(400).json({ error: '未识别到有效快递单号' });
  const { rows } = await pool.query(
    `INSERT INTO scan_registry(tracking_hash,scan_type,carrier,created_by) VALUES($1,'volume',$2,$3)
     ON CONFLICT DO NOTHING RETURNING tracking_hash`,
    [trackingHash(trackingNo), carrier, req.user.id]);
  if (!rows[0]) return res.status(409).json({ error: '该单号已经扫描过，不能重复统计', duplicate: true });
  const total = await pool.query('SELECT count(*)::int total FROM scan_registry WHERE created_at::date=current_date');
  res.status(201).json({ ok: true, total: total.rows[0].total });
}));

app.get('/api/shipping-stats', auth, run(async (req, res) => {
  const date = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.date || '')) ? req.query.date : null;
  const params = date ? [date] : [];
  const dayFilter = date ? 'r.created_at::date=$1::date' : 'r.created_at::date=current_date';
  const [summary, carriers, people, cartons] = await Promise.all([
    pool.query(`SELECT count(*)::int total FROM scan_registry r WHERE ${dayFilter}`, params),
    pool.query(`SELECT coalesce(nullif(r.carrier,''),'未分类') name,count(*)::int total
      FROM scan_registry r WHERE ${dayFilter} GROUP BY 1 ORDER BY total DESC,name`, params),
    pool.query(`SELECT coalesce(u.display_name,'未知人员') name,count(*)::int total
      FROM scan_registry r LEFT JOIN users u ON u.id=r.created_by
      WHERE ${dayFilter} GROUP BY 1 ORDER BY total DESC,name`, params),
    pool.query(`SELECT p.carton_spec name,count(*)::int total
      FROM package_scans p WHERE ${date ? 'p.created_at::date=$1::date' : 'p.created_at::date=current_date'}
      GROUP BY p.carton_spec ORDER BY total DESC,name`, params)
  ]);
  res.json({
    date: date || new Date().toISOString().slice(0, 10),
    total: summary.rows[0].total,
    carriers: carriers.rows,
    people: people.rows,
    cartons: cartons.rows
  });
}));

app.get('/api/catalog', auth, run(async (req, res) => res.json((await pool.query('SELECT * FROM product_catalog ORDER BY model')).rows)));
app.post('/api/catalog', auth, allow('admin'), run(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO product_catalog(model,product_type,aliases,colors,color_required) VALUES($1,$2,$3,$4,$5) RETURNING *`,
    [b.model,b.productType||'',b.aliases||b.model,b.colors||'',Boolean(b.colorRequired)]);
  res.status(201).json(rows[0]);
}));
app.patch('/api/catalog/:id', auth, allow('admin'), run(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `UPDATE product_catalog SET model=$1,product_type=$2,aliases=$3,colors=$4,color_required=$5,active=$6,updated_at=now() WHERE id=$7 RETURNING *`,
    [b.model,b.product_type||'',b.aliases||'',b.colors||'',Boolean(b.color_required),b.active!==false,req.params.id]);
  res.json(rows[0]);
}));

app.get('/api/users', auth, allow('admin'), run(async (req, res) => {
  const { rows } = await pool.query('SELECT id,username,display_name,role,active,created_at FROM users ORDER BY id');
  res.json(rows);
}));
app.post('/api/users', auth, allow('admin'), run(async (req, res) => {
  const b = req.body;
  const roles = ['customer_service', 'printer', 'warehouse', 'operator', 'admin'];
  if (!b.username || String(b.password || '').length < 8) return res.status(400).json({ error: '账号必填，密码至少 8 位' });
  if (!roles.includes(b.role)) return res.status(400).json({ error: '账号角色不正确' });
  const { rows } = await pool.query(
    'INSERT INTO users(username,display_name,password_hash,role) VALUES($1,$2,$3,$4) RETURNING *',
    [b.username,b.displayName||b.username,hashPassword(b.password),b.role||'customer_service']);
  res.status(201).json(safeUser(rows[0]));
}));
app.patch('/api/users/:id', auth, allow('admin'), run(async (req, res) => {
  const b = req.body;
  if (!['customer_service', 'printer', 'warehouse', 'operator', 'admin'].includes(b.role)) return res.status(400).json({ error: '账号角色不正确' });
  if (String(req.params.id) === String(req.user.id) && b.active === false) return res.status(400).json({ error: '不能停用当前登录账号' });
  const password = b.password ? ',password_hash=$4' : '';
  const params = b.password ? [b.displayName,b.role,b.active,hashPassword(b.password),req.params.id] : [b.displayName,b.role,b.active,req.params.id];
  const idPos = params.length;
  const { rows } = await pool.query(`UPDATE users SET display_name=$1,role=$2,active=$3${password},updated_at=now() WHERE id=$${idPos} RETURNING *`, params);
  res.json(safeUser(rows[0]));
}));

app.post('/api/users/:id/reset-password', auth, allow('admin'), run(async (req, res) => {
  const password = String(req.body.password || '');
  if (password.length < 8) return res.status(400).json({ error: '新密码至少 8 位' });
  const { rows } = await pool.query(
    'UPDATE users SET password_hash=$1,updated_at=now() WHERE id=$2 RETURNING *',
    [hashPassword(password), req.params.id]
  );
  if (!rows[0]) return res.status(404).json({ error: '账号不存在' });
  await audit(req, '管理员重置密码', null, `账号：${rows[0].username}`);
  res.json({ ok: true });
}));

app.get('/api/admin/overview', auth, allow('admin'), run(async (req, res) => {
  const [users, cases, scans, ai] = await Promise.all([
    pool.query(`SELECT count(*)::int total,count(*) FILTER(WHERE active)::int active FROM users`),
    pool.query(`SELECT count(*)::int total,
      count(*) FILTER(WHERE created_at::date=current_date)::int today,
      count(*) FILTER(WHERE status NOT IN ('done','cancelled'))::int open,
      count(*) FILTER(WHERE due_at<now() AND status NOT IN ('done','cancelled'))::int overdue
      FROM after_sales_cases`),
    pool.query(`SELECT count(*)::int total,count(*) FILTER(WHERE created_at::date=current_date)::int today FROM scan_registry`),
    pool.query(`SELECT count(*)::int cache_entries,coalesce(sum(hit_count),0)::int cache_hits,
      coalesce(sum(prompt_tokens),0)::int prompt_tokens,coalesce(sum(completion_tokens),0)::int completion_tokens
      FROM ai_parse_cache`)
  ]);
  res.json({ users: users.rows[0], cases: cases.rows[0], scans: scans.rows[0], ai: ai.rows[0] });
}));

app.get('/api/admin/audit-logs', auth, allow('admin'), run(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT l.*,u.display_name,u.username,c.order_no
     FROM audit_logs l LEFT JOIN users u ON u.id=l.user_id LEFT JOIN after_sales_cases c ON c.id=l.case_id
     ORDER BY l.created_at DESC LIMIT 200`
  );
  res.json(rows);
}));

app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === '23505') return res.status(409).json({ error: '数据重复，请检查账号、型号或单号' });
  res.status(err.status || 500).json({ error: err.message || '服务器处理失败，请稍后重试' });
});

async function start() {
  await migrate();
  app.listen(3000, () => console.log('After-sales API 1.5.1 running on port 3000'));
}
start().catch((err) => { console.error(err); process.exit(1); });
