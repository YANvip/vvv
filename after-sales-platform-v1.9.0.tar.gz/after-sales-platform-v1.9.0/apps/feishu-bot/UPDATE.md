# 飞书机器人修复包

版本：1.0.3

## 修复内容

- 改用飞书 Python SDK 官方事件注册接口接收消息。
- 移除对 SDK 私有 `_do_event` 方法的替换。
- 兼容飞书事件对象、JSON 字符串和字典格式。
- 兼容文本消息内容的不同数据格式。
- 修正卡片操作人员 ID 的解析。
- 确认建单时把飞书中已确认的识别结果传给网站。
- `6600灰` 和 `6600灰色` 自动归一为 `6600高级灰`，不再进入异常中心。
- 真正存在歧义的工单会明确显示“等待人工确认”。
- 卡片回调改为直接读取飞书 SDK 事件对象，修复 `200671` 和 `'str' object has no attribute 'get'`。
- 使用 `context.open_message_id` 更新原卡片，不再误用回调 token。
- 注册已读事件处理器，清理 `processor not found` 日志。

## 服务器更新

在 `/opt/after-sales-platform/infra` 执行：

```bash
cp -a /opt/after-sales-platform/apps/feishu-bot \
  /opt/after-sales-platform/apps/feishu-bot-backup-$(date +%Y%m%d-%H%M%S)

tar -xzf /opt/feishu-bot-fixed-v1.0.1.tar.gz \
  -C /opt/after-sales-platform/apps

cd /opt/after-sales-platform/infra
docker compose up -d --force-recreate feishu-bot
docker logs after_sales_feishu_bot --since 2m
```

不要把服务器上的 `.env`、飞书 App Secret 或集成令牌放进压缩包或 GitHub。

## 飞书事件订阅

机器人需要保留：

- `im.message.receive_v1`

如果没有使用已读或进入机器人会话事件，可在飞书开放平台删除：

- `im.message.message_read_v1`
- `im.chat.access_event.bot_p2p_chat_entered_v1`

删除这两个多余订阅可避免日志中出现 `processor not found`，不影响机器人收发消息。
