import json
import os
import threading
import time
from collections import deque

import lark_oapi as lark
from lark_oapi.api.im.v1 import (
    CreateMessageRequest,
    CreateMessageRequestBody,
    PatchMessageRequest,
    PatchMessageRequestBody,
    ReplyMessageRequest,
    ReplyMessageRequestBody,
)
from lark_oapi.event.callback.model.p2_card_action_trigger import (
    P2CardActionTriggerResponse,
)

from bot_logic import (
    extract_order_query,
    is_confirm,
    is_cancel,
    looks_like_create_request,
    build_query_card,
    build_parse_card,
    build_create_success_card,
    build_result_card,
)

APP_ID = os.environ.get("FEISHU_APP_ID", "").strip()
APP_SECRET = os.environ.get("FEISHU_APP_SECRET", "").strip()
INTEGRATION_TOKEN = os.environ.get("FEISHU_INTEGRATION_TOKEN", "").strip()
AFTER_SALES_API_URL = os.environ.get("AFTER_SALES_API_URL", "http://api:3000").rstrip("/")
ALLOWED_OPEN_IDS = {
    value.strip()
    for value in os.environ.get("FEISHU_ALLOWED_OPEN_IDS", "").split(",")
    if value.strip()
}

_client = None
_client_lock = threading.Lock()

_processed_ids = set()
_processed_order = deque()
_processed_lock = threading.Lock()

_pending_create = {}
_pending_lock = threading.Lock()
MAX_PENDING = 200
PENDING_TTL_SECONDS = 10 * 60

def log(message, **fields):
    suffix = " ".join(f"{key}={value}" for key, value in fields.items())
    print(f"[feishu-bot] {message}{' ' + suffix if suffix else ''}", flush=True)

def get_client():
    global _client
    with _client_lock:
        if _client is None:
            _client = (
                lark.Client.builder()
                .app_id(APP_ID)
                .app_secret(APP_SECRET)
                .log_level(lark.LogLevel.ERROR)
                .build()
            )
        return _client

def api_request(path, method="GET", body=None):
    import urllib.error
    import urllib.parse
    import urllib.request

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {INTEGRATION_TOKEN}",
    }
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    url = f"{AFTER_SALES_API_URL}{path}"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            detail = json.loads(raw).get("error") or raw
        except json.JSONDecodeError:
            detail = raw
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc

def query_case(order_no):
    import urllib.parse
    return api_request(
        f"/api/integrations/feishu/cases/by-order/{urllib.parse.quote(order_no, safe='')}"
    )

def parse_text(text):
    return api_request("/api/integrations/feishu/parse", method="POST", body={"text": text})

def create_case(text, open_id, overrides=None, allow_duplicate=False):
    body = {"text": text, "openId": open_id, "allowDuplicate": allow_duplicate}
    if overrides:
        body["overrides"] = overrides
    return api_request("/api/integrations/feishu/cases", method="POST", body=body)

def reply_text(message_id, text):
    client = get_client()
    req = (
        ReplyMessageRequest.builder()
        .message_id(message_id)
        .request_body(
            ReplyMessageRequestBody.builder()
            .msg_type("text")
            .content(json.dumps({"text": text}, ensure_ascii=False))
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.reply(req)
    if not resp.success():
        raise RuntimeError(f"回复消息失败：{resp.msg} (code={resp.code})")
    return resp.data

def reply_card(message_id, card):
    client = get_client()
    card_json = card if isinstance(card, str) else json.dumps(card, ensure_ascii=False)
    req = (
        ReplyMessageRequest.builder()
        .message_id(message_id)
        .request_body(
            ReplyMessageRequestBody.builder()
            .msg_type("interactive")
            .content(card_json)
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.reply(req)
    if not resp.success():
        raise RuntimeError(f"回复卡片失败：{resp.msg} (code={resp.code})")
    return resp.data

def update_card(message_id, card):
    client = get_client()
    card_json = card if isinstance(card, str) else json.dumps(card, ensure_ascii=False)
    req = (
        PatchMessageRequest.builder()
        .message_id(message_id)
        .request_body(
            PatchMessageRequestBody.builder()
            .content(card_json)
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.patch(req)
    if not resp.success():
        raise RuntimeError(f"更新卡片失败：{resp.msg} (code={resp.code})")
    return resp.data

def as_dict(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return {}
        return value if isinstance(value, dict) else {}
    return {}

def event_to_dict(data):
    if isinstance(data, dict):
        return data
    try:
        marshaled = lark.JSON.marshal(data)
    except Exception:
        return {}
    return as_dict(marshaled) if isinstance(marshaled, str) else as_dict(marshaled)

def extract_text(content):
    if isinstance(content, str):
        parsed = as_dict(content)
        if not parsed:
            return content.strip()
        content = parsed
    return str(as_dict(content).get("text") or "").strip()

def mark_once(message_id):
    with _processed_lock:
        if message_id in _processed_ids:
            return False
        _processed_ids.add(message_id)
        _processed_order.append(message_id)
        while len(_processed_order) > 5000:
            _processed_ids.discard(_processed_order.popleft())
        return True

def set_pending(open_id, text, parsed, card_message_id=""):
    with _pending_lock:
        _pending_create[open_id] = {
            "text": text,
            "parsed": parsed,
            "card_message_id": card_message_id,
            "created_at": time.time(),
        }
        while len(_pending_create) > MAX_PENDING:
            oldest_key = min(
                _pending_create, key=lambda k: _pending_create[k]["created_at"]
            )
            _pending_create.pop(oldest_key, None)

def get_pending(open_id):
    with _pending_lock:
        entry = _pending_create.get(open_id)
        if not entry:
            return None
        if time.time() - entry["created_at"] > PENDING_TTL_SECONDS:
            _pending_create.pop(open_id, None)
            return None
        return entry

def clear_pending(open_id):
    with _pending_lock:
        return _pending_create.pop(open_id, None)

def handle_create_request(message_id, open_id, text):
    try:
        parsed = parse_text(text)
    except Exception as exc:
        log("解析失败", error=exc, open_id=open_id)
        try:
            reply_text(message_id, f"解析失败：{exc}\n请稍后再试，或联系管理员。")
        except Exception:
            pass
        return

    order_no = parsed.get("orderNo") or ""
    if not order_no:
        try:
            reply_text(
                message_id,
                "没有识别到订单号。\n"
                "请确保消息中包含完整的订单号，例如：\n"
                "260708-560380003972903 补发两个6600灰",
            )
        except Exception:
            pass
        return

    try:
        existing = query_case(order_no)
        if existing.get("found"):
            reply_card(message_id, build_query_card(existing))
            return
    except Exception:
        pass

    try:
        card_result = reply_card(message_id, build_parse_card(parsed, text))
        card_message_id = card_result.message_id or ""
    except Exception as exc:
        log("发送确认卡片失败", error=exc)
        try:
            from bot_logic import format_parse_result
            reply_text(message_id, format_parse_result(parsed, text))
        except Exception:
            pass
        card_message_id = ""

    set_pending(open_id, text, parsed, card_message_id)

def handle_confirm(message_id, open_id, trigger_from_card=False):
    pending = get_pending(open_id)
    if not pending:
        if not trigger_from_card:
            try:
                reply_card(
                    message_id,
                    build_result_card(
                        "没有待确认的建单请求",
                        "请直接发送售后信息，例如：\n260708-560380003972903 补发两个6600灰",
                        "grey",
                    ),
                )
            except Exception:
                pass
        return

    card_message_id = pending.get("card_message_id") or ""

    try:
        result = create_case(pending["text"], open_id)
        clear_pending(open_id)

        if card_message_id:
            try:
                update_card(card_message_id, build_create_success_card(result))
                log("飞书建单成功（卡片已更新）", open_id=open_id,
                    case_no=(result.get("case") or {}).get("caseNo") or "-")
                return
            except Exception as exc:
                log("更新卡片失败，改用回复", error=exc)

        if message_id and not trigger_from_card:
            reply_card(message_id, build_create_success_card(result))
        log("飞书建单成功", open_id=open_id,
            case_no=(result.get("case") or {}).get("caseNo") or "-")
    except RuntimeError as exc:
        if "HTTP 409" in str(exc):
            clear_pending(open_id)
            if card_message_id:
                try:
                    update_card(
                        card_message_id,
                        build_result_card(
                            "该订单已有售后单",
                            "不能重复创建。\n你可以直接发送订单号查询进度，或联系管理员确认。",
                            "red",
                        ),
                    )
                    return
                except Exception:
                    pass
            try:
                reply_text(
                    message_id,
                    "该订单已有售后单，不能重复创建。\n"
                    "你可以直接发送订单号查询进度，或联系管理员确认。",
                )
            except Exception:
                pass
            return
        log("建单失败", error=exc, open_id=open_id)
        try:
            reply_text(message_id, f"建单失败：{exc}\n请稍后再试，或联系管理员。")
        except Exception:
            pass
    except Exception as exc:
        log("建单异常", error=exc, open_id=open_id)
        try:
            reply_text(message_id, f"建单失败：{exc}\n请稍后再试，或联系管理员。")
        except Exception:
            pass

def handle_cancel(open_id, card_message_id=""):
    pending = clear_pending(open_id)
    if not pending:
        return "没有待确认的建单请求。"

    if card_message_id:
        try:
            update_card(
                card_message_id,
                build_result_card("已取消建单", "如有需要，可以重新发送售后信息。", "grey"),
            )
            return None
        except Exception:
            pass
    return "已取消建单。"

def handle_message_raw(event_dict):
    event = as_dict(event_dict.get("event"))
    message = as_dict(event.get("message"))
    message_id = message.get("message_id") or ""
    if not message_id or not mark_once(message_id):
        return

    sender = as_dict(event.get("sender"))
    sender_id = as_dict(sender.get("sender_id"))
    open_id = sender_id.get("open_id") or ""

    if ALLOWED_OPEN_IDS and open_id and open_id not in ALLOWED_OPEN_IDS:
        try:
            reply_text(message_id, "当前账号没有订单查询权限，请联系管理员。")
        except Exception:
            pass
        return

    msg_type = message.get("message_type") or ""
    if msg_type != "text":
        try:
            reply_text(message_id, "请发送文字消息。\n直接发送订单号可查询，发送售后信息可建单。")
        except Exception:
            pass
        return

    text = extract_text(message.get("content") or "{}")
    log("收到消息", open_id=open_id, msg_type=msg_type, preview=text[:50])

    if get_pending(open_id):
        if is_confirm(text):
            handle_confirm(message_id, open_id)
            return
        if is_cancel(text):
            result = handle_cancel(open_id)
            if result:
                try:
                    reply_text(message_id, result)
                except Exception:
                    pass
            return
        clear_pending(open_id)

    order_no = extract_order_query(text)
    if order_no:
        try:
            result = query_case(order_no)
            reply_card(message_id, build_query_card(result))
            log("订单查询完成", order_no=order_no, open_id=open_id)
        except Exception as exc:
            log("订单查询失败", order_no=order_no, error=exc)
            try:
                reply_text(message_id, "订单查询暂时失败，请稍后重试；如果持续失败，请联系管理员。")
            except Exception:
                pass
        return

    if looks_like_create_request(text):
        handle_create_request(message_id, open_id, text)
        return

    help_card = build_result_card(
        "售后助手使用说明",
        "**查询订单**\n直接发送订单号，或发送「查询 + 订单号」\n例如：260708-560380003972903\n\n"
        "**创建售后单**\n发送售后信息，我会识别并让你确认后创建\n例如：260708-560380003972903 补发两个6600灰",
        "blue",
    )
    try:
        reply_card(message_id, help_card)
    except Exception as exc:
        log("发送帮助卡片失败", error=exc)
        try:
            reply_text(
                message_id,
                "你可以这样使用我：\n\n"
                "【查询】直接发送订单号，或发送「查询 + 订单号」\n"
                "例如：260708-560380003972903\n\n"
                "【建单】发送售后信息，我会识别并让你确认后创建\n"
                "例如：260708-560380003972903 补发两个6600灰",
            )
        except Exception:
            pass

def handle_card_action_raw(event_dict):
    event = as_dict(event_dict.get("event"))
    action = as_dict(event.get("action"))
    value = action.get("value") or {}
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (json.JSONDecodeError, TypeError):
            value = {}

    action_type = value.get("action") or ""

    operator = as_dict(event.get("operator"))
    open_id = ""
    tenant_key = as_dict(operator.get("tenant_key"))
    if tenant_key:
        open_id = tenant_key.get("open_id") or ""
    if not open_id:
        open_id = operator.get("open_id") or ""

    card_message_id = event.get("token") or ""

    log("卡片按钮点击", action=action_type, open_id=open_id)

    if ALLOWED_OPEN_IDS and open_id and open_id not in ALLOWED_OPEN_IDS:
        return {"toast": {"type": "error", "content": "没有操作权限"}}

    def process():
        if action_type == "confirm_create":
            handle_confirm(card_message_id or "card_action", open_id, trigger_from_card=True)
        elif action_type == "cancel_create":
            handle_cancel(open_id, card_message_id)

    threading.Thread(target=process, daemon=True).start()

    return {"toast": {"type": "info", "content": "处理中..."}}

def raw_event_handler(data):
    """原始事件处理函数"""
    try:
        # 尝试各种方式解析 data
        event_dict = None
        if isinstance(data, dict):
            event_dict = data
        elif isinstance(data, str):
            event_dict = json.loads(data)
        elif hasattr(data, '__dict__'):
            try:
                marshaled = lark.JSON.marshal(data)
                if isinstance(marshaled, str):
                    event_dict = json.loads(marshaled)
                elif isinstance(marshaled, dict):
                    event_dict = marshaled
            except Exception:
                event_dict = vars(data)

        if not event_dict:
            log("无法解析事件数据", type=type(data).__name__)
            return None

        header = event_dict.get("header") or event_dict.get("header", {})
        event_type = ""
        if isinstance(header, dict):
            event_type = header.get("event_type") or ""
        elif hasattr(header, "event_type"):
            event_type = header.event_type or ""

        if event_type == "im.message.receive_v1":
            handle_message_raw(event_dict)
            return None
        elif event_type == "card.action.trigger":
            result = handle_card_action_raw(event_dict)
            return result
        # 其他事件忽略
        return None
    except Exception as exc:
        log("事件处理异常", error=exc, type=type(data).__name__)
        import traceback
        log("异常堆栈", trace=traceback.format_exc()[:500])
        return None

def on_message_receive(data):
    event_dict = event_to_dict(data)
    if event_dict:
        handle_message_raw(event_dict)

def on_card_action(data):
    event_dict = event_to_dict(data)
    if event_dict:
        result = handle_card_action_raw(event_dict)
    else:
        result = {"toast": {"type": "error", "content": "无法读取本次操作"}}
    return P2CardActionTriggerResponse(result)

def main():
    missing = [
        name
        for name, value in {
            "FEISHU_APP_ID": APP_ID,
            "FEISHU_APP_SECRET": APP_SECRET,
            "FEISHU_INTEGRATION_TOKEN": INTEGRATION_TOKEN,
        }.items()
        if not value
    ]
    if missing:
        raise SystemExit("缺少配置：" + ", ".join(missing))

    get_client()
    log("正在启动飞书长连接", api=AFTER_SALES_API_URL)

    try:
        handler = (
            lark.EventDispatcherHandler.builder("", "")
            .register_p2_im_message_receive_v1(on_message_receive)
            .register_p2_card_action_trigger(on_card_action)
            .build()
        )
        client = lark.ws.Client(
            APP_ID,
            APP_SECRET,
            event_handler=handler,
            log_level=lark.LogLevel.INFO,
        )
        client.start()
    except Exception as exc:
        log("启动失败", error=exc)
        import traceback
        log(traceback.format_exc())

if __name__ == "__main__":
    main()
