from bot_logic import build_existing_case_card, is_my_id_request


def test_my_id_commands():
    accepted = (
        "我的id",
        "我的 ID",
        "我的飞书ID",
        "获取ID",
        "查询 open_id",
        "查看用户ID？",
    )
    rejected = (
        "",
        "订单ID",
        "我的订单",
        "查询260708-560380003972903",
    )

    for value in accepted:
        assert is_my_id_request(value), value
    for value in rejected:
        assert not is_my_id_request(value), value


def test_existing_case_card_is_not_labeled_as_query():
    card = build_existing_case_card({
        "found": True,
        "orderNo": "6954683200173249559",
        "case": {
            "orderNo": "6954683200173249559",
            "status": "pending",
            "platform": "douyin",
            "items": [{"model": "7001", "color": "大象灰", "quantity": 2}],
        },
    })
    assert card["header"]["title"]["content"] == "该订单已有售后工单"
    assert "未重复创建" in card["elements"][0]["text"]["content"]


if __name__ == "__main__":
    test_my_id_commands()
    test_existing_case_card_is_not_labeled_as_query()
    print("Feishu identity command tests passed")
