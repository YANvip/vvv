const assert = require('assert');
const { normalizeOrderNo, safeCase } = require('./feishu');

assert.equal(normalizeOrderNo(' 260627-227897567592037 '), '260627-227897567592037');
assert.equal(normalizeOrderNo('6927550207970082166'), '6927550207970082166');
assert.equal(normalizeOrderNo('查询订单'), '');
assert.equal(normalizeOrderNo('123'), '');

assert.deepEqual(
  safeCase({
    id: 8,
    case_no: 'AS202607250001',
    type: 'resend',
    status: 'done',
    platform: 'douyin',
    order_no: '6927550207970082166',
    product_name: '7001',
    product_sku: '7001',
    quantity: '2',
    color: '大象灰',
    resend_tracking_no: 'YT1234567890',
    reason: '漏发',
    solution: '补发',
    remark: '',
    created_at: '2026-07-25T00:00:00Z',
    updated_at: '2026-07-25T01:00:00Z',
    completed_at: '2026-07-25T01:00:00Z',
  }),
  {
    id: 8,
    caseNo: 'AS202607250001',
    type: 'resend',
    status: 'done',
    platform: 'douyin',
    orderNo: '6927550207970082166',
    productName: '7001',
    productSku: '7001',
    quantity: 2,
    color: '大象灰',
    resendTrackingNo: 'YT1234567890',
    reason: '漏发',
    solution: '补发',
    remark: '',
    createdAt: '2026-07-25T00:00:00Z',
    updatedAt: '2026-07-25T01:00:00Z',
    completedAt: '2026-07-25T01:00:00Z',
  }
);

console.log('Feishu integration helpers passed');
