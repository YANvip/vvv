const assert = require('assert');
const { splitIds, createFeishuService } = require('./feishu-service');

assert.deepStrictEqual(splitIds('ou_1, ou_2,,ou_1'), ['ou_1', 'ou_2', 'ou_1']);
assert.deepStrictEqual(splitIds(''), []);
assert.deepStrictEqual(splitIds(undefined), []);

const service = createFeishuService({
  FEISHU_APP_ID: 'cli_test',
  FEISHU_APP_SECRET: 'secret_test',
  FEISHU_PRINTER_OPEN_IDS: 'ou_p1, ou_p2',
  FEISHU_CUSTOMER_SERVICE_OPEN_IDS: 'ou_cs1',
  FEISHU_OPERATOR_OPEN_IDS: '',
});
assert.strictEqual(service.enabled(), true);
assert.deepStrictEqual(service.printerIds, ['ou_p1', 'ou_p2']);
assert.deepStrictEqual(service.customerServiceIds, ['ou_cs1']);
assert.deepStrictEqual(service.operatorIds, []);

const disabled = createFeishuService({});
assert.strictEqual(disabled.enabled(), false);

(async () => {
  const fetchImpl = async (url, options = {}) => {
    if (url.includes('/auth/v3/tenant_access_token/internal')) {
      return {
        ok: true,
        json: async () => ({ code: 0, tenant_access_token: 'token', expire: 7200 }),
      };
    }
    const body = JSON.parse(options.body || '{}');
    const failed = body.receive_id === 'ou_failed';
    return {
      ok: true,
      json: async () => (
        failed
          ? { code: 230013, msg: 'recipient unavailable' }
          : { code: 0, data: { message_id: `msg_${body.receive_id}` } }
      ),
    };
  };
  const detailed = createFeishuService({
    FEISHU_APP_ID: 'cli_test',
    FEISHU_APP_SECRET: 'secret_test',
  }, fetchImpl);
  const result = await detailed.sendCard(['ou_ok', 'ou_failed'], { elements: [] });
  assert.strictEqual(result.sent, 1);
  assert.strictEqual(result.failed, 1);
  assert.deepStrictEqual(result.failedOpenIds, ['ou_failed']);
  assert.deepStrictEqual(result.failureDetails, [
    { openId: 'ou_failed', error: 'recipient unavailable' },
  ]);
  console.log('Feishu service helpers passed');
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
