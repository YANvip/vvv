const ORDER_NO_RE = /^[A-Za-z0-9][A-Za-z0-9_-]{5,39}$/;

function normalizeOrderNo(value) {
  const orderNo = String(value || '').trim().replace(/\s+/g, '');
  return ORDER_NO_RE.test(orderNo) ? orderNo : '';
}

function safeCase(row) {
  if (!row) return null;
  return {
    id: row.id,
    caseNo: row.case_no,
    type: row.type,
    status: row.status,
    platform: row.platform,
    orderNo: row.order_no,
    productName: row.product_name,
    productSku: row.product_sku,
    quantity: Number(row.quantity) || 0,
    color: row.color || '',
    ...(Array.isArray(row.items) ? { items: row.items } : {}),
    resendTrackingNo: row.resend_tracking_no || '',
    reason: row.reason || '',
    solution: row.solution || '',
    remark: row.remark || '',
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    completedAt: row.completed_at,
  };
}

module.exports = { normalizeOrderNo, safeCase };
