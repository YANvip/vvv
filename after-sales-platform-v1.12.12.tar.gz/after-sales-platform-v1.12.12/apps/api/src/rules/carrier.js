const normalizeCarrierTracking = (value) => String(value || '')
  .trim()
  .replace(/\s+/g, '')
  .toUpperCase();

const rules = [
  { carrier: '安能', confidence: 1, pattern: /^(?:74|75)\d{10}$/ },
  { carrier: '顺丰', confidence: 1, pattern: /^SF\d{10,18}$/ },
  { carrier: '京东', confidence: 1, pattern: /^(?:JD|JDX|VA)\d{8,20}$/ },
  { carrier: '极兔', confidence: 1, pattern: /^JT\d{10,20}$/ },
  { carrier: '圆通', confidence: 1, pattern: /^YT\d{8,20}$/ },
  { carrier: '中通', confidence: 1, pattern: /^ZTO\d{8,20}$/ },
  { carrier: '申通', confidence: 1, pattern: /^STO\d{8,20}$/ },
  { carrier: '韵达', confidence: 1, pattern: /^YD\d{8,20}$/ },
  { carrier: '德邦', confidence: 1, pattern: /^(?:DPK|DEPPON)\d{7,20}$/ },
  { carrier: '邮政', confidence: 0.98, pattern: /^(?:EMS\d{8,20}|[A-Z]{2}\d{9}CN)$/ },
];

function detectCarrier(value) {
  const trackingNo = normalizeCarrierTracking(value);
  const matched = rules.find((rule) => rule.pattern.test(trackingNo));
  if (matched) return { trackingNo, carrier: matched.carrier, confidence: matched.confidence, matched: true };
  return { trackingNo, carrier: '待确认', confidence: 0, matched: false };
}

module.exports = { detectCarrier, normalizeCarrierTracking };
