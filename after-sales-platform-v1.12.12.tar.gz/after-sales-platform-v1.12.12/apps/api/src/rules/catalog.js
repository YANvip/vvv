const catalog = [
  { model: '6600脚垫', aliases: ['6600脚垫', '6600防滑垫', '6600垫', '6600凳脚垫'], productType: '配件', colors: [], colorRequired: false },
  { model: '7001脚垫', aliases: ['7001脚垫', '7001防滑垫', '7001垫'], productType: '配件', colors: [], colorRequired: false },
  { model: '210脚垫', aliases: ['210脚垫', '210防滑垫', '210蛋白皮脚垫'], productType: '配件', colors: [], colorRequired: false },
  { model: '6600凳面', aliases: ['6600凳面', '6600凳子面'], productType: '配件', colors: ['抹茶绿', '西瓜红', '高级灰', '青象灰', '淡雅灰', '天空蓝', '火焰橙', '蓝色', '绿色', '红色'], colorRequired: true },
  { model: '7001凳面', aliases: ['7001凳面', '7001凳子面'], productType: '配件', colors: ['雨林绿', '大象灰', '冰河灰'], colorRequired: true },
  { model: '210座框', aliases: ['210座框', '蛋白皮座框', '蛋壳椅座框'], productType: '配件', colors: [], colorRequired: false },
  { model: '210螺丝', aliases: ['210螺丝', '210螺丝钉'], productType: '配件', colors: [], colorRequired: false },
  { model: '6600', aliases: ['6600'], productType: '塑料凳', colors: ['抹茶绿', '西瓜红', '高级灰', '青象灰', '淡雅灰', '天空蓝', '火焰橙', '蓝色', '绿色', '红色', '灰色'], colorRequired: true },
  { model: '7001', aliases: ['7001'], productType: '塑料凳', colors: ['雨林绿', '大象灰', '冰河灰'], colorRequired: true },
  { model: '7002', aliases: ['7002'], productType: '塑料凳', colors: [], colorRequired: false },
  { model: '210蛋白皮', aliases: ['210蛋白皮', '210 蛋白皮', '210'], productType: '软包凳', colors: ['抹茶绿', '橙色', '卡其色', '米白', '奶白', '灰色', '咖色', '黑色'], colorRequired: true },
  { model: '033软包', aliases: ['033软包', '033 软包'], productType: '软包凳', colors: ['卡其色', '橙色', '灰色', '米白', '黑色'], colorRequired: true },
  { model: '033', aliases: ['033'], productType: '塑料凳', colors: ['旋风橙黄色', '橙黄色', '抹茶绿', '粉色', '蓝色', '灰色', '白色', '黑色'], colorRequired: true },
  { model: '马扎', aliases: ['马扎', '中号马扎'], productType: '折叠凳', colors: ['军绿色', '军绿'], colorRequired: true },
];

module.exports = { catalog };
