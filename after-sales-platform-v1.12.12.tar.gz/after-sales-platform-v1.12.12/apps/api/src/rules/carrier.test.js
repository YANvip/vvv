const assert = require('node:assert/strict');
const { detectCarrier, normalizeCarrierTracking } = require('./carrier');

assert.equal(normalizeCarrierTracking(' sf 123456789012 '), 'SF123456789012');
assert.equal(detectCarrier('741011448638').carrier, '安能');
assert.equal(detectCarrier('SF123456789012').carrier, '顺丰');
assert.equal(detectCarrier('JD123456789012').carrier, '京东');
assert.equal(detectCarrier('JT5508800000790').carrier, '极兔');
assert.equal(detectCarrier('YT123456789012').carrier, '圆通');
assert.equal(detectCarrier('ZTO123456789012').carrier, '中通');
assert.equal(detectCarrier('STO123456789012').carrier, '申通');
assert.equal(detectCarrier('YD123456789012').carrier, '韵达');
assert.equal(detectCarrier('DPK1234567890').carrier, '德邦');
assert.equal(detectCarrier('EA123456789CN').carrier, '邮政');
assert.equal(detectCarrier('123456789012345').carrier, '待确认');

console.log('Carrier detection tests passed');
