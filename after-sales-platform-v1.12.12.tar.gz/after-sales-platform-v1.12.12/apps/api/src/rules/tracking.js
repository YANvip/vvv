function normalizeAnengTracking(value) {
  const tracking = String(value || '').trim().replace(/\s+/g, '').toUpperCase();
  const linkedPackage = tracking.match(/^(\d{12})0001\d{0,8}$/);
  return linkedPackage ? linkedPackage[1] : tracking;
}

function isAnengTracking(value) {
  return /^(74|75)\d{10}$/.test(normalizeAnengTracking(value));
}

module.exports = { normalizeAnengTracking, isAnengTracking };
