const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const server = fs.readFileSync(path.join(__dirname, 'server.js'), 'utf8');
const web = fs.readFileSync(path.join(__dirname, '../../web/index.html'), 'utf8');

const operatorRoutes = [
  "app.post('/api/parse', auth, allow('admin', 'customer_service', 'operator')",
  "app.post('/api/cases/from-text', auth, allow('admin', 'customer_service', 'operator')",
  "app.patch('/api/cases/:id', auth, allow('admin', 'customer_service', 'operator')",
  "app.delete('/api/cases/:id', auth, allow('admin', 'customer_service', 'operator')",
  "app.patch('/api/cases/:id/tracking', auth, allow('admin', 'printer', 'operator')",
  "app.post('/api/package-scans', auth, allow('admin', 'warehouse', 'operator')",
  "app.post('/api/shipment-volume/scan', auth, allow('admin', 'warehouse', 'operator')",
  "app.post('/api/return-receipts', auth, allow('admin', 'warehouse', 'operator')",
  "app.patch('/api/return-receipts/:id', auth, allow('admin', 'warehouse', 'operator')",
  "app.delete('/api/return-receipts/:id', auth, allow('admin', 'warehouse', 'operator')",
];

for (const route of operatorRoutes) {
  assert.ok(server.includes(route), `operator permission missing: ${route}`);
}

assert.ok(
  server.includes("app.get('/api/return-receipts', auth, allow('admin', 'customer_service', 'warehouse', 'operator')"),
  'return receipt lookup roles missing'
);

const adminOnlyRoutes = [
  "app.get('/api/users', auth, allow('admin')",
  "app.post('/api/users', auth, allow('admin')",
  "app.post('/api/catalog', auth, allow('admin')",
  "app.get('/api/integrations/feishu/status', auth, allow('admin')",
  "app.get('/api/admin/overview', auth, allow('admin')",
  "app.get('/api/admin/audit-logs', auth, allow('admin')",
];

for (const route of adminOnlyRoutes) {
  assert.ok(server.includes(route), `admin boundary changed: ${route}`);
}

assert.ok(web.includes('data-roles="admin,printer,operator"'), 'operator printing menu missing');
assert.ok(web.includes('data-roles="admin,warehouse,operator"'), 'operator scanner menu missing');
assert.ok(web.includes('data-page="returns"'), 'return receipt menu missing');
assert.ok(web.includes("selectScanMode('return')"), 'return receipt scan mode missing');
assert.ok(web.includes("['自动识别','圆通'"), 'automatic carrier option missing');
assert.ok(web.includes("['admin','printer','operator'].includes(me.role)"), 'operator tracking UI missing');
assert.ok(web.includes("['admin','customer_service','operator'].includes(me.role)"), 'operator case editor missing');
assert.ok(web.includes("me.role!=='admin'"), 'admin menu visibility boundary missing');

console.log('Operator permissions tests passed');
