(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  const API = "/api";
  let me = null;
  let parsed = null;
  let casePage = 1;
  let caseTotal = 0;
  let selectedSpec = localStorage.getItem("scanSpec") || "";
  let scanRows = [];
  let scanBatches = [];
  let returnReceipts = [];
  let cameraStream = null;
  let detector = null;
  let zxingReader = null;
  let zxingControls = null;
  let detecting = false;
  let scanMode = "aneng";
  let scanInputMode = localStorage.getItem("scanInputMode") || "camera";
  let audioCtx = null;
  let wakeLock = null;
  let scanBatchId = localStorage.getItem("scanBatchId") || (crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random().toString(16).slice(2));
  localStorage.setItem("scanBatchId", scanBatchId);
  const roleText = { admin: "管理员", customer_service: "客服", printer: "打单员", warehouse: "仓库人员", operator: "运营" };
  const statusText = { need_review: "待确认", pending: "待处理", processing: "处理中", done: "已完成", cancelled: "已取消" };
  const esc = (v) => String(v != null ? v : "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const urlArg = (v) => encodeURIComponent(String(v != null ? v : "")).replace(/'/g, "%27");
  const carrierOptions = (selected = "") => ["自动识别", "圆通", "韵达", "中通", "申通", "极兔", "顺丰", "邮政", "京东", "德邦", "安能", "其他"].map((x) => `<option ${x === selected ? "selected" : ""}>${x}</option>`).join("");
  async function request(url, opts = {}) {
    const res = await fetch(API + url, __spreadValues({ headers: __spreadValues({ "Content-Type": "application/json" }, opts.headers || {}) }, opts));
    let data;
    try {
      data = await res.json();
    } catch (e) {
      data = {};
    }
    if (res.status === 401) {
      showLogin();
      throw Error(data.error || "请先登录");
    }
    if (!res.ok) {
      const e = Error(data.error || "操作失败");
      e.data = data;
      throw e;
    }
    return data;
  }
  function toast(text) {
    const el = document.getElementById("toast");
    el.textContent = text;
    el.classList.remove("hidden");
    setTimeout(() => el.classList.add("hidden"), 2200);
  }
  function clearLoginForm() {
    loginUser.value = "";
    loginPassword.value = "";
  }
  function showLogin() {
    document.getElementById("login").classList.remove("hidden");
    document.getElementById("app").classList.add("hidden");
    clearLoginForm();
    setTimeout(clearLoginForm, 100);
  }
  function startApp() {
    document.getElementById("login").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
    who.textContent = `${me.displayName} · ${roleText[me.role]}`;
    document.querySelectorAll(".admin-only").forEach((x) => x.classList.toggle("hidden", me.role !== "admin"));
    document.querySelectorAll("[data-roles]").forEach((x) => x.classList.toggle("hidden", !x.dataset.roles.split(",").includes(me.role)));
    document.querySelectorAll(".customer-action").forEach((x) => x.classList.toggle("hidden", ["printer", "warehouse"].includes(me.role)));
    entryPanel.classList.toggle("hidden", ["printer", "warehouse"].includes(me.role));
    const requested = new URLSearchParams(location.search).get("page");
    const defaultPage = { warehouse: "scanner", printer: "printing", customer_service: "work", operator: "dashboard", admin: "dashboard" }[me.role] || "dashboard";
    const firstPage = requested === "scanner" && ["admin", "warehouse", "operator"].includes(me.role) ? "scanner" : defaultPage;
    showPage(firstPage);
    if (me.role !== "warehouse") loadAll();
  }
  function showPage(name) {
    document.querySelectorAll("[id^=page-]").forEach((x) => x.classList.add("hidden"));
    document.getElementById("page-" + name).classList.remove("hidden");
    document.querySelectorAll(".nav button").forEach((x) => x.classList.toggle("active", x.dataset.page === name));
    if (name === "scanner") loadScans();
    else stopCamera();
    if (name === "dashboard") loadDashboardHome();
    if (name === "printing") loadPrinting();
    if (name === "shipping") loadShippingStats();
    if (name === "exceptions") loadExceptions();
    if (name === "returns") loadReturns();
  }
  async function loadAll() {
    await Promise.all([loadDashboard(), loadCases()]);
  }
  async function loadDashboard() {
    const s = await request("/dashboard");
    sTotal.textContent = s.total;
    sToday.textContent = s.today;
    sReview.textContent = s.need_review;
    sPending.textContent = s.pending;
    sDone.textContent = s.done;
    sOverdue.textContent = s.overdue;
    return s;
  }
  async function loadDashboardHome() {
    try {
      const [s, tasks, overdue] = await Promise.all([request("/dashboard"), request("/cases?status=pending&tracking=missing&page=1&limit=8"), request("/cases?overdue=true&page=1&limit=5")]);
      hToday.textContent = s.today;
      hPending.textContent = s.pending;
      hReview.textContent = s.need_review;
      hDone.textContent = s.done;
      dashboardGreeting.textContent = `${me.display_name}，这里是今天最需要关注的任务。`;
      dashboardTasks.innerHTML = tasks.rows.length ? tasks.rows.map((x) => `<div class="task-row"><div><b>${esc(x.order_no || "待补订单号")}</b><small>${esc(x.platform || "未知平台")}</small></div><div>${esc(x.product_sku || x.product_name || "-")} ${esc(x.color || "")}<small>${esc((x.reason || "暂无补发原因").slice(0, 36))}</small></div><button class="btn small ghost" onclick="openCase(${x.id})">查看</button></div>`).join("") : '<div class="report-empty">当前没有待处理任务</div>';
      if (overdue.rows.length) {
        overdueAlert.classList.remove("hidden");
        overdueCount.textContent = overdue.rows.length;
        overdueList.innerHTML = overdue.rows.map((x) => `<div class="overdue-item"><span class="overdue-order">${esc(x.order_no || "待补订单号")}</span><span>${esc(x.product_sku || x.product_name || "-")} ${esc(x.color || "")}</span><span class="overdue-due">到期：${new Date(x.due_at).toLocaleDateString()}</span><button class="btn small" onclick="openCase(${x.id})">处理</button></div>`).join("");
      } else {
        overdueAlert.classList.add("hidden");
      }
    } catch (err) {
      dashboardTasks.innerHTML = `<div class="report-empty">${esc(err.message)}</div>`;
      overdueAlert.classList.add("hidden");
    }
  }
  async function loadPrinting() {
    try {
      const data = await request("/cases?status=pending&tracking=missing&page=1&limit=100");
      printingCount.textContent = `共 ${data.total} 条`;
      printingRows.innerHTML = data.rows.length ? data.rows.map((x) => `<tr><td><span class="link" onclick="openCase(${x.id})">${esc(x.order_no || "待补订单号")}</span></td><td>${esc(x.platform || "-")}</td><td>${esc(x.product_sku || x.product_name || "-")} ${esc(x.color || "")}</td><td>${Number(x.quantity) || 1}</td><td title="${esc(x.reason || "")}">${esc((x.reason || "-").slice(0, 30))}</td><td><select id="pc${x.id}">${carrierOptions(x.shipping_carrier)}</select></td><td><div class="scan"><input id="pt${x.id}" placeholder="扫描或输入快递单号"><button class="btn small green" onclick="saveTracking(${x.id},'pt${x.id}','pc${x.id}')">完成打单</button></div></td></tr>`).join("") : '<tr><td class="empty" colspan="7">没有待打单任务</td></tr>';
    } catch (err) {
      printingRows.innerHTML = `<tr><td class="empty" colspan="7">${esc(err.message)}</td></tr>`;
    }
  }
  async function loadExceptions() {
    try {
      const [review, overdue] = await Promise.all([request("/cases?status=need_review&page=1&limit=100"), request("/cases?overdue=true&page=1&limit=100")]);
      const rows = [...review.rows, ...overdue.rows.filter((x) => !review.rows.some((r) => r.id === x.id))];
      exceptionCount.textContent = `共 ${rows.length} 条`;
      exceptionRows.innerHTML = rows.length ? rows.map((x) => `<tr><td>${esc(x.order_no || "待补订单号")}</td><td><span class="badge need_review">${x.status === "need_review" ? "待确认" : "已逾期"}</span></td><td>${esc(x.platform || "-")}</td><td>${esc(x.product_sku || x.product_name || "-")} ${esc(x.color || "")}</td><td>${esc(x.parse_warnings || x.reason || x.remark || "-")}</td><td>${new Date(x.created_at).toLocaleString()}</td><td><button class="btn small" onclick="openCase(${x.id})">处理</button></td></tr>`).join("") : '<tr><td class="empty" colspan="7">当前没有异常任务</td></tr>';
    } catch (err) {
      exceptionRows.innerHTML = `<tr><td class="empty" colspan="7">${esc(err.message)}</td></tr>`;
    }
  }
  async function parseText(forceAi = false) {
    if (!rawText.value.trim()) return toast("请先输入客服原话");
    try {
      parsed = await request("/parse?ai=" + (forceAi ? "force" : "auto"), { method: "POST", body: JSON.stringify({ text: rawText.value }) });
      showParsed(parsed);
    } catch (err) {
      toast(err.message);
    }
  }
  function renderItemEditors(containerId, items = []) {
    const box = document.getElementById(containerId);
    box.innerHTML = "";
    (items.length ? items : [{ model: "", color: "", quantity: 1 }]).forEach((item) => addItemEditor(containerId, item));
  }
  function addItemEditor(containerId, item = {}) {
    const row = document.createElement("div");
    row.className = "item-editor";
    row.innerHTML = `<input class="item-model" value="${esc(item.model || item.productName || "")}" placeholder="型号或配件"><input class="item-color" value="${esc(item.color || "")}" placeholder="颜色（配件可空）"><input class="item-qty" type="number" min="1" max="999" value="${Number(item.quantity) || 1}" title="数量"><button class="btn small ghost" type="button" title="删除此商品">删除</button>`;
    row.querySelector("button").onclick = () => row.remove();
    document.getElementById(containerId).appendChild(row);
  }
  function collectItemEditors(containerId) {
    return [...document.querySelectorAll(`#${containerId} .item-editor`)].map((row) => ({ model: row.querySelector(".item-model").value.trim(), productName: row.querySelector(".item-model").value.trim(), color: row.querySelector(".item-color").value.trim(), quantity: Number(row.querySelector(".item-qty").value) || 1 })).filter((x) => x.model);
  }
  function showParsed(p) {
    var _a;
    parseBox.classList.remove("hidden");
    pPlatform.value = p.platform;
    pType.value = p.type;
    pOrder.value = p.orderNo;
    renderItemEditors("pItemRows", ((_a = p.items) == null ? void 0 : _a.length) ? p.items : [p]);
    const source = { rules: "本地规则", rules_fallback: "本地规则（AI 暂不可用）", ai: "DeepSeek AI", ai_cache: "DeepSeek 缓存（本次不计费）" }[p.source] || "本地规则";
    parseMessage.className = p.warnings.length ? "warning" : "ok";
    parseMessage.textContent = `${source}：${p.warnings.length ? p.warnings.join("；") : "识别完整，可以确认建单"}`;
  }
  async function createCase() {
    var _a, _b;
    const makeBody = (allowDuplicate = false) => {
      const items = collectItemEditors("pItemRows");
      if (!items.length) throw Error("请至少填写一条商品明细");
      return { text: rawText.value, allowDuplicate, overrides: { platform: pPlatform.value, type: pType.value, orderNo: pOrder.value, items, needReview: false, warnings: [] }, remark: pRemark.value };
    };
    try {
      if (!parsed) await parseText();
      if (!parsed) return;
      await request("/cases/from-text", { method: "POST", body: JSON.stringify(makeBody()) });
      rawText.value = "";
      parsed = null;
      parseBox.classList.add("hidden");
      toast("售后单已创建");
      loadAll();
    } catch (err) {
      if (((_a = err.data) == null ? void 0 : _a.duplicate) && confirm(err.message + "，仍要继续建单吗？")) {
        await request("/cases/from-text", { method: "POST", body: JSON.stringify(makeBody(true)) });
        toast("重复订单已建单");
        loadAll();
      } else if (!((_b = err.data) == null ? void 0 : _b.duplicate)) toast(err.message);
    }
  }
  async function loadCases() {
    const q = new URLSearchParams({ keyword: keyword.value, status: fStatus.value, type: fType.value, platform: fPlatform.value, priority: fPriority.value, assignedTo: fAssigned.value, createdBy: fCreatedBy.value, dateFrom: fDateFrom.value, dateTo: fDateTo.value, tracking: fTracking.value, overdue: fOverdue.value, page: casePage, limit: fPageSize.value });
    const data = await request("/cases?" + q);
    caseTotal = data.total;
    countText.textContent = `共 ${data.total} 条`;
    pageText.textContent = `第 ${data.page} / ${Math.max(1, Math.ceil(data.total / data.pageSize))} 页`;
    caseRows.innerHTML = data.rows.length ? data.rows.map(rowHtml).join("") : '<tr><td class="empty" colspan="9">没有符合条件的售后记录</td></tr>';
  }
  function rowHtml(x) {
    const tracking = esc(x.resend_tracking_no || "");
    const order = x.order_no || "";
    const canTrack = ["admin", "printer", "operator"].includes(me.role);
    const canManage = ["admin", "customer_service", "operator"].includes(me.role);
    const priority = { urgent: "紧急", high: "较高", normal: "普通" }[x.priority] || "普通";
    const isOverdue = x.due_at && new Date(x.due_at) < /* @__PURE__ */ new Date() && !["done", "cancelled"].includes(x.status);
    const trackingCell = canTrack ? `<div class="scan"><select id="tc${x.id}" title="快递公司">${carrierOptions(x.shipping_carrier)}</select><input id="t${x.id}" value="${tracking}" placeholder="扫码枪扫描或输入"><button class="btn small green" onclick="saveTracking(${x.id},'t${x.id}','tc${x.id}')">保存</button>${tracking ? `<button class="btn small ghost" onclick="copyTracking('${tracking}')">复制</button>` : ""}</div>` : tracking ? `<div class="scan-number">${esc(x.shipping_carrier || "")} ${tracking} <button class="btn small ghost" onclick="copyTracking('${tracking}')">复制</button></div>` : '<span style="color:var(--muted)">等待打单员填写</span>';
    const manageButton = !canManage || x.status === "done" ? "" : x.status === "cancelled" ? ` <button class="btn small red" onclick="deleteCaseById(${x.id},'${urlArg(order)}','deleted')">删除</button>` : ` <button class="btn small red" onclick="deleteCaseById(${x.id},'${urlArg(order)}','cancelled')">取消</button>`;
    return `<tr class="${isOverdue ? "row-overdue" : ""}"><td><span class="link" onclick="openCase(${x.id})">${esc(order || "待补订单号")}</span>${order ? ` <button class="btn small ghost" onclick="copyOrder('${urlArg(order)}')">复制</button>` : ""}${manageButton}<br><small>${new Date(x.created_at).toLocaleString()}</small></td><td>${esc(x.platform)}</td><td>${esc(x.type)}</td><td>${esc(x.product_name || x.product_sku || "-")}</td><td>${x.quantity || 1}</td><td><span class="priority ${x.priority}">${priority}</span></td><td><span class="badge ${x.status}">${statusText[x.status] || esc(x.status)}</span>${isOverdue ? '<br><small class="overdue-tag">已逾期</small>' : ""}</td><td>${trackingCell}</td><td>${esc(x.assigned_to_name || x.created_by_name || "-")}</td></tr>`;
  }
  function focusHardwareInput() {
    if (scanInputMode !== "hardware" || document.getElementById("page-scanner").classList.contains("hidden")) return;
    manualTracking.focus({ preventScroll: true });
  }
  function applyInputMode() {
    const hardware = scanInputMode === "hardware";
    scannerCapturePanel.classList.toggle("hardware-mode", hardware);
    inputCamera.classList.toggle("active", !hardware);
    inputHardware.classList.toggle("active", hardware);
    hardwareReady.classList.toggle("hidden", !hardware);
    manualLabel.textContent = hardware ? "PDA / 扫码枪输入" : scanMode === "aneng" ? "手工输入或扫码枪备用" : scanMode === "volume" ? "扫描或输入快递单号（只计数，不显示单号）" : "扫描或输入退件快递单号";
    manualTracking.placeholder = hardware ? "直接按设备扫描键，读取后自动保存" : scanMode === "aneng" ? "输入后按回车自动保存" : scanMode === "volume" ? "输入后按回车计入今日发货量" : "输入后按回车完成退件入库";
    manualTracking.inputMode = hardware ? "none" : "text";
    if (hardware) {
      keepScreenAwake();
      setTimeout(focusHardwareInput, 80);
    } else if (!detecting) {
      releaseScreenAwake();
    }
  }
  const standardSpecs = ["39×39×82", "39×39×92", "35×35×105", "35×35×119"];
  let customSpecs = JSON.parse(localStorage.getItem("customCartonSpecs") || "[]");
  const isToday = (value) => new Date(value).toLocaleDateString() === (/* @__PURE__ */ new Date()).toLocaleDateString();
  function renderCustomSpecs() {
    const discovered = scanBatches.flatMap((x) => String(x.specs || "").split("、")).filter(Boolean).filter((x) => !standardSpecs.includes(x));
    customSpecs = [.../* @__PURE__ */ new Set([...customSpecs, ...discovered])].slice(0, 30);
    localStorage.setItem("customCartonSpecs", JSON.stringify(customSpecs));
    customSpecButtons.innerHTML = customSpecs.map((x) => `<button class="spec-btn ${x === selectedSpec ? "active" : ""}" data-spec="${esc(x)}" onclick="selectSpec(this)">${esc(x)}</button>`).join("");
  }
  function rememberCustomSpec(spec) {
    if (standardSpecs.includes(spec) || customSpecs.includes(spec)) return;
    customSpecs.unshift(spec);
    customSpecs = customSpecs.slice(0, 30);
    localStorage.setItem("customCartonSpecs", JSON.stringify(customSpecs));
    renderCustomSpecs();
  }
  function updateBatchSummary(batch = null) {
    const today = !batch || isToday(batch.created_at);
    const name = selectedSpec ? `${selectedSpec} · ${today ? "今日清单" : new Date(batch.created_at).toLocaleDateString()}` : "选择规格后打开今日清单";
    batchName.value = selectedSpec || "";
    batchNameText.textContent = name;
    batchCreatedText.textContent = (batch == null ? void 0 : batch.total) ? `${new Date(batch.created_at).toLocaleString()} 开始 · 已保存 ${batch.total} 个单号` : today ? "今天还没有记录，首次扫码后自动保存" : "该规格没有扫码记录";
    focusSpec.textContent = selectedSpec || "未选择规格";
  }
  async function activateSpec(spec, button = null) {
    stopCamera();
    selectedSpec = spec;
    localStorage.setItem("scanSpec", spec);
    rememberCustomSpec(spec);
    document.querySelectorAll(".spec-btn").forEach((x) => x.classList.toggle("active", x === button || x.dataset.spec === spec));
    selectedSpecText.textContent = spec;
    batchSpec.textContent = `今日 ${spec}`;
    try {
      const data = await request("/package-scans/daily-spec", { method: "POST", body: JSON.stringify({ cartonSpec: spec }) });
      scanBatchId = data.batch.batch_id;
      localStorage.setItem("scanBatchId", scanBatchId);
      scanRows = data.rows;
      scanBatches = await request("/scan-batches");
      renderCustomSpecs();
      updateBatchSummary(data.batch);
      renderScans();
      renderBatchHistory();
      if (data.merged) toast(`已自动合并今天的 ${spec} 记录`);
    } catch (err) {
      toast(err.message);
    }
    applyInputMode();
  }
  async function loadScans() {
    scanBatches = await request("/scan-batches");
    renderCustomSpecs();
    if (selectedSpec) await activateSpec(selectedSpec);
    else {
      scanRows = [];
      updateBatchSummary();
      renderScans();
      renderBatchHistory();
      applyInputMode();
    }
    loadTodayVolume();
    secureHint.classList.toggle("hidden", window.isSecureContext);
    todayDate.textContent = (/* @__PURE__ */ new Date()).toLocaleDateString();
  }
  function renderScans() {
    const rows = selectedSpec ? scanRows.filter((x) => x.carton_spec === selectedSpec) : scanRows;
    scanCount.textContent = rows.length;
    focusCount.textContent = `${rows.length} 个`;
    focusSpec.textContent = scanMode === "aneng" ? selectedSpec || "未选择规格" : scanMode === "volume" ? "统计今日发货量" : `${returnType.value}入库`;
    copyPreview.textContent = rows.length ? `已保存 ${rows.length} 个快递单号` : "扫描结果会实时显示在这里";
    scanFeed.innerHTML = rows.length ? rows.map((x, i) => `<div class="scan-item"><div class="scan-index">${rows.length - i}</div><div><div class="scan-number">${esc(x.tracking_no)}</div><div class="scan-meta">${esc(x.carton_spec)} · ${new Date(x.created_at).toLocaleTimeString()}</div></div><div><button class="btn small ghost" onclick="changeScanSpec(${x.id})">改规格</button> <button class="btn small ghost" onclick="deleteScan(${x.id})">删除</button></div></div>`).join("") : '<div class="empty">还没有扫码记录</div>';
  }
  function renderBatchHistory() {
    const history = scanBatches.filter((x) => !isToday(x.created_at));
    batchHistory.innerHTML = history.length ? history.map((x) => `<div class="batch-item"><div><b>${esc(x.specs || x.batch_name)}</b><div class="scan-meta">${new Date(x.created_at).toLocaleDateString()} · ${x.total} 个</div></div><div>${x.copied_at ? '<span class="copied">已复制</span> ' : ""}<button class="btn small ghost" onclick="openScanBatch('${urlArg(x.batch_id)}')">查看</button> <button class="btn small red" onclick="event.stopPropagation();deleteScanBatch('${urlArg(x.batch_id)}','${urlArg(x.batch_name)}')">删除</button></div></div>`).join("") : '<div class="scan-meta" style="margin-top:10px">暂无以前日期的记录</div>';
  }
  async function saveScan(value) {
    var _a;
    const trackingNo = String(value || "").trim().replace(/\s+/g, "").toUpperCase();
    if (!/^[A-Z0-9-]{6,40}$/.test(trackingNo)) return;
    if (scanMode === "volume") return saveVolumeScan(trackingNo);
    if (!/^(74|75)\d{10}(?:0001\d{0,8})?$/.test(trackingNo)) {
      cameraState.textContent = "已忽略：不是 74 或 75 开头的安能单号";
      return toast("不是有效的安能单号");
    }
    if (!selectedSpec) return toast("请先选择纸箱规格");
    try {
      const row = await request("/package-scans", { method: "POST", body: JSON.stringify({ trackingNo, cartonSpec: selectedSpec }) });
      if (row.batch_id !== scanBatchId) {
        await activateSpec(selectedSpec);
      } else {
        scanRows.unshift(row);
        let batch = scanBatches.find((x) => x.batch_id === scanBatchId);
        if (!batch) {
          batch = { batch_id: scanBatchId, batch_name: selectedSpec, created_at: row.created_at, total: 0, specs: selectedSpec, copied_at: null };
          scanBatches.unshift(batch);
        }
        batch.total = scanRows.length;
        batch.specs = selectedSpec;
        batch.copied_at = null;
        updateBatchSummary(batch);
        renderScans();
        renderBatchHistory();
      }
      manualTracking.value = "";
      cameraState.textContent = row.normalized_from ? `已自动剔除联号后缀，保存：${row.tracking_no}` : `已保存：${row.tracking_no}`;
      (_a = navigator.vibrate) == null ? void 0 : _a.call(navigator, 120);
      playBeep();
      loadTodayVolume();
    } catch (err) {
      cameraState.textContent = err.message;
      toast(err.message);
    }
  }
  const saveOutboundScan = saveScan;
  saveScan = async function(value) {
    return scanMode === "return" ? saveReturnScan(value) : saveOutboundScan(value);
  };
  async function saveReturnScan(value) {
    var _a;
    const trackingNo = String(value || "").trim().replace(/\s+/g, "").toUpperCase();
    if (!/^[A-Z0-9-]{6,40}$/.test(trackingNo)) return;
    try {
      const row = await request("/return-receipts", { method: "POST", body: JSON.stringify({ trackingNo, returnType: returnType.value, remark: returnRemark.value }) });
      returnReceipts.unshift(row);
      renderReturnScanFeed();
      manualTracking.value = "";
      cameraState.textContent = `已入库：${row.tracking_no} · ${row.carrier}`;
      focusCount.textContent = `${returnReceipts.length} 件`;
      (_a = navigator.vibrate) == null ? void 0 : _a.call(navigator, 120);
      playBeep();
    } catch (err) {
      cameraState.textContent = err.message;
      toast(err.message);
    }
  }
  function renderReturnScanFeed() {
    returnTodayCount.textContent = returnReceipts.length;
    focusCount.textContent = `${returnReceipts.length} 件`;
    focusSpec.textContent = `${returnType.value}入库`;
    returnScanFeed.innerHTML = returnReceipts.length ? returnReceipts.map((x, i) => `<div class="scan-item"><div class="scan-index">${returnReceipts.length - i}</div><div><div class="scan-number">${esc(x.tracking_no)}</div><div class="scan-meta">${esc(x.carrier)} · ${esc(x.return_type)} · ${new Date(x.received_at).toLocaleTimeString()}</div></div></div>`).join("") : '<div class="empty">今天还没有退件入库记录</div>';
  }
  async function saveVolumeScan(trackingNo) {
    var _a;
    try {
      const data = await request("/shipment-volume/scan", { method: "POST", body: JSON.stringify({ trackingNo, carrier: volumeCarrier.value }) });
      volumeTotal.textContent = data.total;
      focusCount.textContent = `${data.total} 个`;
      manualTracking.value = "";
      cameraState.textContent = `已计入今日发货量 · ${data.carrier || volumeCarrier.value}`;
      (_a = navigator.vibrate) == null ? void 0 : _a.call(navigator, 120);
      playBeep();
    } catch (err) {
      cameraState.textContent = err.message;
      toast(err.message);
    }
  }
  async function loadTodayVolume() {
    try {
      const data = await request("/shipment-volume/today");
      volumeTotal.textContent = data.total;
      if (scanMode === "volume") focusCount.textContent = `${data.total} 个`;
    } catch (e) {
    }
  }
  function renderReportRows(rows) {
    return rows.length ? rows.map((x) => `<div class="report-row"><span>${esc(x.name)}</span><b>${x.total}</b></div>`).join("") : '<div class="report-empty">所选日期暂无记录</div>';
  }
  function localDateValue(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }
  function renderTrend(rows) {
    if (!rows.length) {
      dailyTrend.innerHTML = '<div class="report-empty">所选日期暂无趋势数据</div>';
      return;
    }
    const max = Math.max(1, ...rows.flatMap((x) => [Number(x.shipments) || 0, Number(x.returns) || 0]));
    dailyTrend.innerHTML = rows.map((x) => {
      const shipmentTotal = Number(x.shipments) || 0, returnTotal = Number(x.returns) || 0;
      const shipmentHeight = shipmentTotal ? Math.max(4, Math.round(shipmentTotal / max * 135)) : 2;
      const returnHeight = returnTotal ? Math.max(4, Math.round(returnTotal / max * 135)) : 2;
      return `<div class="trend-day"><div class="trend-bars" title="${esc(x.date)} 发货 ${shipmentTotal}，退件 ${returnTotal}"><i class="trend-bar shipments" style="height:${shipmentHeight}px"></i><i class="trend-bar returns" style="height:${returnHeight}px"></i></div><div class="trend-label">${esc(x.date.slice(5))}</div></div>`;
    }).join("");
  }
  async function loadShippingStats() {
    try {
      if (!shippingDateFrom.value || !shippingDateTo.value) {
        const today = localDateValue(/* @__PURE__ */ new Date());
        shippingDateFrom.value = today;
        shippingDateTo.value = today;
      }
      const q = new URLSearchParams({ dateFrom: shippingDateFrom.value, dateTo: shippingDateTo.value });
      const data = await request("/shipping-stats?" + q);
      shippingPeriodText.textContent = `${data.dateFrom} 至 ${data.dateTo} · 共 ${data.days} 天`;
      shippingTotal.textContent = data.summary.total;
      shippingAneng.textContent = data.summary.aneng;
      shippingVolume.textContent = data.summary.volume;
      shippingReturns.textContent = data.returnsSummary.total;
      shippingPendingCarrier.textContent = Number(data.summary.pending_carrier || 0) + Number(data.returnsSummary.pending_carrier || 0);
      renderTrend(data.daily || []);
      carrierStats.innerHTML = renderReportRows(data.carriers || []);
      peopleStats.innerHTML = renderReportRows(data.people || []);
      cartonStats.innerHTML = renderReportRows(data.cartons || []);
      returnCarrierStats.innerHTML = renderReportRows(data.returnCarriers || []);
      shipmentDetailCount.textContent = `共 ${data.shipments.length} 条`;
      shipmentDetailRows.innerHTML = data.shipments.length ? data.shipments.map((x) => `<tr><td>${esc(x.tracking_no || "历史记录未保存单号")}</td><td>${esc(x.carrier || "未分类")}</td><td>${esc(x.created_by_name)}</td><td>${new Date(x.created_at).toLocaleString()}</td></tr>`).join("") : '<tr><td colspan="4" class="empty">所选日期暂无安能发货记录</td></tr>';
      dataReturnDetailCount.textContent = `共 ${data.returns.length} 条`;
      dataReturnRows.innerHTML = data.returns.length ? data.returns.map((x) => `<tr><td>${esc(x.tracking_no)}</td><td><span class="${x.carrier === "待确认" ? "carrier-pending" : ""}">${esc(x.carrier || "待确认")}</span></td><td>${esc(x.return_type)}</td><td>${esc(x.created_by_name)}</td><td>${new Date(x.received_at).toLocaleString()}</td><td>${esc(x.remark || "-")}</td></tr>`).join("") : '<tr><td colspan="6" class="empty">所选日期暂无退件入库记录</td></tr>';
    } catch (err) {
      toast(err.message);
    }
  }
  function returnCarrierOptions(selected = "") {
    return ["待确认", "安能", "中通", "极兔", "圆通", "京东", "顺丰", "韵达", "申通", "邮政", "德邦", "其他"].map((x) => `<option ${x === selected ? "selected" : ""}>${x}</option>`).join("");
  }
  async function loadReturns() {
    try {
      const q = new URLSearchParams({ keyword: returnKeyword.value, carrier: returnCarrier.value, returnType: returnTypeFilter.value, dateFrom: returnDateFrom.value, dateTo: returnDateTo.value, limit: 200 });
      const data = await request("/return-receipts?" + q);
      returnCount.textContent = `共 ${data.total} 条`;
      const editable = ["admin", "warehouse", "operator"].includes(me.role);
      returnRows.innerHTML = data.rows.length ? data.rows.map((x) => `<tr><td><span class="scan-number">${esc(x.tracking_no)}</span></td><td>${editable ? `<select id="rrc${x.id}">${returnCarrierOptions(x.carrier)}</select>` : `<span class="${x.carrier === "待确认" ? "carrier-pending" : ""}">${esc(x.carrier)}</span>`}</td><td>${editable ? `<select id="rrt${x.id}"><option ${x.return_type === "退件" ? "selected" : ""}>退件</option><option ${x.return_type === "拦截件" ? "selected" : ""}>拦截件</option></select>` : esc(x.return_type)}</td><td>${new Date(x.received_at).toLocaleString()}</td><td>${esc(x.created_by_name)}</td><td>${editable ? `<input id="rrm${x.id}" value="${esc(x.remark || "")}" placeholder="可填写备注">` : esc(x.remark || "-")}</td><td>${editable ? `<button class="btn small ghost" onclick="updateReturn(${x.id})">保存</button> <button class="btn small red" onclick="deleteReturn(${x.id},'${urlArg(x.tracking_no)}')">删除</button>` : "-"}</td></tr>`).join("") : '<tr><td colspan="7" class="empty">没有符合条件的退件记录</td></tr>';
    } catch (err) {
      returnRows.innerHTML = `<tr><td colspan="7" class="empty">${esc(err.message)}</td></tr>`;
    }
  }
  async function saveManualTracking() {
    unlockAudio();
    await saveScan(manualTracking.value);
    if (scanInputMode === "hardware") setTimeout(focusHardwareInput, 50);
  }
  async function keepScreenAwake() {
    if (!("wakeLock" in navigator) || wakeLock) return;
    try {
      wakeLock = await navigator.wakeLock.request("screen");
      wakeLock.addEventListener("release", () => {
        wakeLock = null;
      });
    } catch (e) {
    }
  }
  async function releaseScreenAwake() {
    try {
      await (wakeLock == null ? void 0 : wakeLock.release());
    } catch (e) {
    }
    wakeLock = null;
  }
  function stopCamera() {
    detecting = false;
    document.body.classList.remove("scan-focus");
    releaseScreenAwake();
    try {
      zxingControls == null ? void 0 : zxingControls.stop();
    } catch (e) {
    }
    try {
      zxingReader == null ? void 0 : zxingReader.reset();
    } catch (e) {
    }
    zxingControls = null;
    zxingReader = null;
    cameraStream == null ? void 0 : cameraStream.getTracks().forEach((x) => x.stop());
    cameraStream = null;
    detector = null;
    if (window.cameraVideo) {
      cameraVideo.srcObject = null;
      cameraVideo.classList.add("hidden");
      cameraPlaceholder.classList.remove("hidden");
      cameraLine.classList.add("hidden");
      cameraButton.textContent = "打开摄像头连续扫码";
      cameraState.textContent = "摄像头未开启";
    }
  }
  function unlockAudio() {
    var _a;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      (_a = audioCtx.resume) == null ? void 0 : _a.call(audioCtx);
    } catch (e) {
    }
  }
  function playBeep() {
    try {
      unlockAudio();
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.connect(g);
      g.connect(audioCtx.destination);
      o.frequency.value = 960;
      g.gain.setValueAtTime(0.12, audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(1e-3, audioCtx.currentTime + 0.12);
      o.start();
      o.stop(audioCtx.currentTime + 0.12);
    } catch (e) {
    }
  }
  let allUsers = [];
  async function loadUserList() {
    try {
      allUsers = await request("/staff-options");
    } catch (e) {
      allUsers = [];
    }
    const opt = (u) => `<option value="${u.id}">${esc(u.display_name || u.username)}</option>`;
    if (fAssigned) {
      const cur = fAssigned.value;
      fAssigned.innerHTML = '<option value="">全部负责人</option>' + allUsers.map(opt).join("");
      fAssigned.value = cur;
    }
    if (fCreatedBy) {
      const cur = fCreatedBy.value;
      fCreatedBy.innerHTML = '<option value="">全部创建人</option>' + allUsers.map(opt).join("");
      fCreatedBy.value = cur;
    }
  }
  [keyword, fStatus, fType, fPlatform, fPriority, fAssigned, fCreatedBy, fDateFrom, fDateTo, fTracking, fOverdue, fPageSize].forEach((x) => x.addEventListener(x === keyword ? "input" : "change", () => {
    casePage = 1;
    clearTimeout(window.filterTimer);
    window.filterTimer = setTimeout(loadCases, 200);
  }));
  [returnKeyword, returnCarrier, returnTypeFilter, returnDateFrom, returnDateTo].forEach((x) => x.addEventListener(x === returnKeyword ? "input" : "change", () => {
    clearTimeout(window.returnFilterTimer);
    window.returnFilterTimer = setTimeout(loadReturns, 200);
  }));
  returnType.addEventListener("change", () => {
    if (scanMode === "return") {
      focusSpec.textContent = `${returnType.value}入库`;
    }
  });
  manualTracking.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      clearTimeout(window.hardwareScanTimer);
      saveManualTracking();
    }
  });
  manualTracking.addEventListener("input", () => {
    if (scanInputMode !== "hardware") return;
    clearTimeout(window.hardwareScanTimer);
    const minLength = scanMode === "aneng" ? 12 : 6;
    if (manualTracking.value.trim().length >= minLength) window.hardwareScanTimer = setTimeout(saveManualTracking, 180);
  });
  rawText.addEventListener("keydown", (e) => {
    if (e.ctrlKey && e.key === "Enter") createCase();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && detecting) keepScreenAwake();
  });
  window.addEventListener("pagehide", () => stopCamera());
  async function boot() {
    try {
      me = await request("/auth/me");
      loadUserList().catch(() => {
      });
      startApp();
    } catch (e) {
      showLogin();
    }
  }
  boot();
})();
