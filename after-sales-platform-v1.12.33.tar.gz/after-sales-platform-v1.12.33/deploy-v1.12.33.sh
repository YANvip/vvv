#!/usr/bin/env bash
set -Eeuo pipefail

TARGET="/opt/after-sales-platform"
SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/after-sales-platform-backup-${STAMP}"

[[ -f "${TARGET}/infra/.env" ]] || { echo "升级已停止：没有找到 ${TARGET}/infra/.env"; exit 1; }

echo "1/6 检查升级文件"
for path in apps/api apps/web apps/feishu-bot infra/docker-compose.yml infra/nginx/default.conf; do
  [[ -e "${SOURCE}/${path}" ]] || { echo "升级包缺少 ${path}"; exit 1; }
done

echo "2/6 备份当前程序到 ${BACKUP}"
mkdir -p "${BACKUP}/apps" "${BACKUP}/infra/nginx" "${BACKUP}/infra/initdb"
for app in api web feishu-bot; do
  [[ -d "${TARGET}/apps/${app}" ]] && cp -a "${TARGET}/apps/${app}" "${BACKUP}/apps/"
done
cp -a "${TARGET}/infra/docker-compose.yml" "${BACKUP}/infra/"
cp -a "${TARGET}/infra/nginx/default.conf" "${BACKUP}/infra/nginx/"
cp -a "${TARGET}/infra/initdb/." "${BACKUP}/infra/initdb/"

echo "3/6 更新应用文件（保留数据库、密码、证书和备份）"
mkdir -p "${TARGET}/apps/api" "${TARGET}/apps/web" "${TARGET}/apps/feishu-bot" "${TARGET}/infra/initdb" "${TARGET}/infra/nginx" "${TARGET}/infra/backups"
cp -a "${SOURCE}/apps/api/." "${TARGET}/apps/api/"
cp -a "${SOURCE}/apps/web/." "${TARGET}/apps/web/"
cp -a "${SOURCE}/apps/feishu-bot/." "${TARGET}/apps/feishu-bot/"
cp -a "${SOURCE}/infra/initdb/." "${TARGET}/infra/initdb/"
cp -a "${SOURCE}/infra/nginx/default.conf" "${TARGET}/infra/nginx/default.conf"
cp -a "${SOURCE}/infra/docker-compose.yml" "${TARGET}/infra/docker-compose.yml"

echo "4/6 检查服务器配置"
cd "${TARGET}/infra"
docker compose config --quiet

echo "5/6 构建并启动 1.12.33"
docker compose up -d --build --force-recreate api feishu-bot web

echo "6/6 等待健康检查"
for attempt in {1..30}; do
  if curl -fsS http://127.0.0.1:3000/api/health | grep -q '"version":"1.12.33"'; then
    echo
    docker compose ps
    echo "升级成功。备份目录：${BACKUP}"
    exit 0
  fi
  sleep 2
done

echo "升级未通过健康检查，请运行：docker compose logs api --tail=100"
echo "备份目录：${BACKUP}"
exit 1
