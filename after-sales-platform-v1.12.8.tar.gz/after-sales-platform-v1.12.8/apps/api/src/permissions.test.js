const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const server = fs.readFileSync(path.join(__dirname, 'server.js'), 'utf8');
const web = fs.readFileSync(path.join(__dirname, '../../web/index.html'), 'utf8');
const adminWeb = fs.readFileSync(path.join(__dirname, '../../web/admin/index.html'), 'utf8');
assert.ok(server.includes('该飞书 ID 已绑定给'), 'duplicate Feishu binding protection missing');
assert.ok(
  server.includes("app.get('/api/integrations/feishu/users/by-open-id/:openId', integrationAuth"),
  'Feishu bound-user permission lookup missing'
);
assert.ok(!web.includes('id="loginUser" value="admin"'), 'login page must not prefill the admin account');
assert.ok(web.includes('function clearLoginForm()'), 'login fields must be cleared for shared devices');

const operatorRoutes = [
  "app.post('/api/parse', auth, allow('admin', 'customer_service', 'operator')",
  "app.post('/api/cases/from-text', auth, allow('admin', 'customer_service', 'operator')",
  "app.patch('/api/cases/:id', auth, allow('admin', 'customer_service', 'operator')",
  "app.delete('/api/cases/:id', auth, allow('admin', 'customer_service', 'operator')",
  "app.patch('/api/cases/:id/tracking', auth, allow('admin', 'printer', 'operator')",
  "app.post('/api/package-scans', auth, allow('admin', 'warehouse', 'operator')",
  "app.post('/api/package-scans/daily-spec', auth, allow('admin', 'warehouse', 'operator')",
  "app.post('/api/shipment-volume/scan', auth, allow('admin', 'warehouse', 'operator')",
  "app.get('/api/shipping-stats', auth, allow('admin', 'warehouse', 'operator')",
  "app.post('/api/return-receipts', auth, allow('admin', 'warehouse', 'operator')",
  "app.patch('/api/return-receipts/:id', auth, allow('admin', 'warehouse', 'operator')",
  "app.delete('/api/return-receipts/:id', auth, allow('admin', 'warehouse', 'operator')",
];

for (const route of operatorRoutes) {
  assert.ok(server.includes(route), `operator permission missing: ${route}`);
}

assert.ok(
  server.includes("app.get('/api/return-receipts', auth, allow('admin', 'customer_service', 'warehouse', 'operator')"),
  'return receipt lookup roles missing'
);

const adminOnlyRoutes = [
  "app.get('/api/users', auth, allow('admin')",
  "app.post('/api/users', auth, allow('admin')",
  "app.post('/api/catalog', auth, allow('admin')",
  "app.patch('/api/catalog/:id', auth, allow('admin')",
  "app.get('/api/integrations/feishu/status', auth, allow('admin')",
  "app.get('/api/admin/overview', auth, allow('admin')",
  "app.get('/api/admin/audit-logs', auth, allow('admin')",
];

for (const route of adminOnlyRoutes) {
  assert.ok(server.includes(route), `admin boundary changed: ${route}`);
}

assert.ok(web.includes('data-roles="admin,printer,operator"'), 'operator printing menu missing');
assert.ok(web.includes('data-roles="admin,warehouse,operator"'), 'operator scanner menu missing');
assert.ok(web.includes('data-page="returns"'), 'return receipt menu missing');
assert.ok(web.includes("selectScanMode('return')"), 'return receipt scan mode missing');
assert.ok(web.includes("['自动识别','圆通'"), 'automatic carrier option missing');
assert.ok(web.includes("['admin','printer','operator'].includes(me.role)"), 'operator tracking UI missing');
assert.ok(web.includes("['admin','customer_service','operator'].includes(me.role)"), 'operator case editor missing');
assert.ok(web.includes("me.role!=='admin'"), 'admin menu visibility boundary missing');
assert.ok(server.includes('if (days > 92)'), 'data center range limit missing');
assert.ok(server.includes('returnCarriers: returnCarriers.rows'), 'return carrier statistics missing');
assert.ok(server.includes('daily: daily.rows'), 'daily trend statistics missing');
assert.ok(server.includes('AS stat_date'), 'daily trend must avoid reserved day alias');
assert.ok(!server.includes('::date day'), 'reserved day alias reintroduced');
assert.ok(web.includes('id="shippingDateFrom"'), 'data center start date missing');
assert.ok(web.includes('id="dailyTrend"'), 'data center daily trend missing');
assert.ok(web.includes('id="dataReturnRows"'), 'data center return details missing');
assert.ok(adminWeb.includes('function saveCatalog(id)'), 'catalog edit action missing');
assert.ok(adminWeb.includes("document.getElementById('ce'+id).checked"), 'catalog enable/disable control missing');
assert.ok(server.includes('ALTER TABLE scan_registry ADD COLUMN IF NOT EXISTS scan_type'), 'legacy scan registry migration missing');
assert.ok(server.includes('ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS received_at'), 'legacy return receipt migration missing');
assert.ok(server.includes('pg_advisory_xact_lock'), 'daily carton specification concurrency lock missing');
assert.ok(server.includes('await activateDailySpec(client, cartonSpec, req.user.id)'), 'daily carton specification merge missing');
assert.ok(web.includes('id="customSpecButtons"'), 'custom carton specification shortcuts missing');
assert.ok(web.includes("request('/package-scans/daily-spec'"), 'daily carton specification activation missing');
assert.ok(!web.includes('onclick="newScanBatch()"'), 'legacy new batch action should be removed');
assert.ok(!web.includes('第一批'), 'legacy numbered carton batches should be removed');

console.log('Operator permissions tests passed');
