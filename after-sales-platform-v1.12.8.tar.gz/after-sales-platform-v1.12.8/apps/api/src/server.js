const express = require('express');
const crypto = require('crypto');
const { Pool } = require('pg');
const { parseAfterSalesText } = require('./rules/parser');
const { catalog: seedCatalog } = require('./rules/catalog');
const { normalizeAnengTracking, isAnengTracking } = require('./rules/tracking');
const { detectCarrier } = require('./rules/carrier');
const { normalizeOrderNo, safeCase } = require('./integrations/feishu');
const { createFeishuService } = require('./integrations/feishu-service');

const app = express();
app.use(express.json({ limit: '1mb' }));

const pool = new Pool({
  host: process.env.POSTGRES_HOST || 'postgres',
  port: Number(process.env.POSTGRES_PORT || 5432),
  database: process.env.POSTGRES_DB,
  user: process.env.POSTGRES_USER,
  password: process.env.POSTGRES_PASSWORD,
});
const feishuService = createFeishuService();

const sessions = new Map();
const loginAttempts = new Map();
const cookie = (req, name) => (req.headers.cookie || '').split(';').map((x) => x.trim()).find((x) => x.startsWith(`${name}=`))?.slice(name.length + 1);
const hashPassword = (password, salt = crypto.randomBytes(16).toString('hex')) => {
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `${salt}:${hash}`;
};
const verifyPassword = (password, stored) => {
  const [salt, hash] = String(stored || '').split(':');
  if (!salt || !hash) return false;
  const actual = crypto.scryptSync(String(password), salt, 64);
  const expected = Buffer.from(hash, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
};
const safeUser = (row) => ({ id: row.id, username: row.username, displayName: row.display_name, display_name: row.display_name, role: row.role, active: row.active, feishuOpenId: row.feishu_open_id || '' });
const normalizeTracking = (value) => String(value || '').trim().replace(/\s+/g, '').toUpperCase();
const trackingHash = (value) => crypto
  .createHmac('sha256', process.env.SCAN_HASH_SECRET || process.env.POSTGRES_PASSWORD || 'after-sales')
  .update(normalizeTracking(value))
  .digest('hex');
const shanghaiDate = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Shanghai' });
const dailySpecBatchId = (cartonSpec) => `spec-${shanghaiDate().replaceAll('-', '')}-${crypto.createHash('sha1').update(cartonSpec).digest('hex').slice(0, 16)}`;

async function activateDailySpec(client, cartonSpec, userId) {
  const batchId = dailySpecBatchId(cartonSpec);
  await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [batchId]);
  const previous = await client.query(
    `SELECT DISTINCT batch_id FROM package_scans
     WHERE carton_spec=$1 AND created_at >= current_date AND created_at < current_date + interval '1 day'`,
    [cartonSpec]
  );
  const oldBatchIds = previous.rows.map((row) => row.batch_id).filter((id) => id !== batchId);
  await client.query(
    `INSERT INTO scan_batches(batch_id,batch_name,created_by) VALUES($1,$2,$3)
     ON CONFLICT(batch_id) DO UPDATE SET batch_name=EXCLUDED.batch_name,updated_at=now()`,
    [batchId, cartonSpec, userId]
  );
  await client.query(
    `UPDATE package_scans SET batch_id=$1
     WHERE carton_spec=$2 AND created_at >= current_date AND created_at < current_date + interval '1 day' AND batch_id<>$1`,
    [batchId, cartonSpec]
  );
  if (oldBatchIds.length) {
    await client.query(
      `UPDATE scan_batches SET copied_at=NULL,updated_at=now() WHERE batch_id=ANY($1::varchar[])`,
      [oldBatchIds]
    );
    await client.query(
      `DELETE FROM scan_batches b WHERE b.batch_id=ANY($1::varchar[])
       AND NOT EXISTS(SELECT 1 FROM package_scans s WHERE s.batch_id=b.batch_id)`,
      [oldBatchIds]
    );
  }
  await client.query(
    `UPDATE scan_batches SET batch_name=$2,
       copied_at=CASE WHEN $3::boolean THEN NULL ELSE copied_at END,
       created_at=COALESCE((SELECT min(created_at) FROM package_scans WHERE batch_id=$1),created_at),updated_at=now()
     WHERE batch_id=$1`,
    [batchId, cartonSpec, oldBatchIds.length > 0]
  );
  const [batch, scans] = await Promise.all([
    client.query(
      `SELECT b.batch_id,b.batch_name,b.copied_at,b.created_at,count(s.id)::int total,$2::text specs
       FROM scan_batches b LEFT JOIN package_scans s ON s.batch_id=b.batch_id
       WHERE b.batch_id=$1 GROUP BY b.batch_id,b.batch_name,b.copied_at,b.created_at`,
      [batchId, cartonSpec]
    ),
    client.query(
      `SELECT s.*,u.display_name created_by_name FROM package_scans s LEFT JOIN users u ON u.id=s.created_by
       WHERE s.batch_id=$1 ORDER BY s.created_at DESC LIMIT 2000`,
      [batchId]
    )
  ]);
  return { batch: batch.rows[0], rows: scans.rows, merged: oldBatchIds.length };
}

async function migrate() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY, username VARCHAR(60) UNIQUE NOT NULL, display_name VARCHAR(100) NOT NULL,
      password_hash TEXT NOT NULL, role VARCHAR(30) NOT NULL DEFAULT 'customer_service',
      active BOOLEAN NOT NULL DEFAULT true, created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS product_catalog (
      id BIGSERIAL PRIMARY KEY, model VARCHAR(100) UNIQUE NOT NULL, product_type VARCHAR(100),
      aliases TEXT NOT NULL DEFAULT '', colors TEXT NOT NULL DEFAULT '', color_required BOOLEAN NOT NULL DEFAULT false,
      active BOOLEAN NOT NULL DEFAULT true, created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS audit_logs (
      id BIGSERIAL PRIMARY KEY, case_id BIGINT, user_id BIGINT, action VARCHAR(60) NOT NULL,
      detail TEXT, created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS package_scans (
      id BIGSERIAL PRIMARY KEY,
      tracking_no VARCHAR(100) UNIQUE NOT NULL,
      carton_spec VARCHAR(100) NOT NULL,
      batch_id VARCHAR(100) NOT NULL,
      created_by BIGINT,
      created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS scan_registry (
      tracking_hash CHAR(64) PRIMARY KEY,
      tracking_no VARCHAR(100),
      scan_type VARCHAR(30) NOT NULL,
      carrier VARCHAR(50) NOT NULL DEFAULT '未分类',
      created_by BIGINT,
      created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS scan_batches (
      batch_id VARCHAR(100) PRIMARY KEY,
      batch_name VARCHAR(150) NOT NULL,
      copied_at TIMESTAMPTZ,
      created_by BIGINT,
      created_at TIMESTAMPTZ DEFAULT now(),
      updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS return_receipts (
      id BIGSERIAL PRIMARY KEY,
      tracking_no VARCHAR(100) UNIQUE NOT NULL,
      carrier VARCHAR(50) NOT NULL DEFAULT '待确认',
      carrier_confidence NUMERIC(4,3) NOT NULL DEFAULT 0,
      return_type VARCHAR(30) NOT NULL DEFAULT '退件',
      remark TEXT NOT NULL DEFAULT '',
      received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      created_by BIGINT,
      created_at TIMESTAMPTZ DEFAULT now(),
      updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS ai_parse_cache (
      cache_key CHAR(64) PRIMARY KEY,
      result JSONB NOT NULL,
      prompt_tokens INTEGER DEFAULT 0,
      completion_tokens INTEGER DEFAULT 0,
      cache_hit_tokens INTEGER DEFAULT 0,
      hit_count INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT now(),
      updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS idx_package_scans_batch ON package_scans(batch_id);
    CREATE INDEX IF NOT EXISTS idx_package_scans_created ON package_scans(created_at);
    CREATE INDEX IF NOT EXISTS idx_scan_registry_created ON scan_registry(created_at);
    CREATE INDEX IF NOT EXISTS idx_return_receipts_received ON return_receipts(received_at DESC);
    CREATE INDEX IF NOT EXISTS idx_return_receipts_carrier ON return_receipts(carrier);
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS color VARCHAR(50);
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS parsed_raw_text TEXT;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS parse_warnings TEXT;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS assigned_to BIGINT;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS created_by BIGINT;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS priority VARCHAR(20) NOT NULL DEFAULT 'normal';
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS due_at TIMESTAMPTZ;
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS tags TEXT NOT NULL DEFAULT '';
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS feishu_record_id VARCHAR(100);
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS source VARCHAR(30) NOT NULL DEFAULT 'web';
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS shipping_carrier VARCHAR(50);
    ALTER TABLE after_sales_cases ADD COLUMN IF NOT EXISTS items JSONB NOT NULL DEFAULT '[]'::jsonb;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS feishu_open_id VARCHAR(100);
    ALTER TABLE scan_registry ADD COLUMN IF NOT EXISTS scan_type VARCHAR(30) NOT NULL DEFAULT 'volume';
    ALTER TABLE scan_registry ADD COLUMN IF NOT EXISTS carrier VARCHAR(50) NOT NULL DEFAULT '未分类';
    ALTER TABLE scan_registry ADD COLUMN IF NOT EXISTS tracking_no VARCHAR(100);
    ALTER TABLE scan_registry ADD COLUMN IF NOT EXISTS created_by BIGINT;
    ALTER TABLE scan_registry ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();
    ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS carrier VARCHAR(50) NOT NULL DEFAULT '待确认';
    ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS carrier_confidence NUMERIC(4,3) NOT NULL DEFAULT 0;
    ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS return_type VARCHAR(30) NOT NULL DEFAULT '退件';
    ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS remark TEXT NOT NULL DEFAULT '';
    ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS received_at TIMESTAMPTZ NOT NULL DEFAULT now();
    ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS created_by BIGINT;
    ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();
    ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
    CREATE UNIQUE INDEX IF NOT EXISTS idx_after_sales_cases_feishu_record ON after_sales_cases(feishu_record_id) WHERE feishu_record_id IS NOT NULL;
    CREATE INDEX IF NOT EXISTS idx_after_sales_cases_order_no ON after_sales_cases(order_no);
    CREATE INDEX IF NOT EXISTS idx_after_sales_cases_status ON after_sales_cases(status);
    CREATE INDEX IF NOT EXISTS idx_after_sales_cases_created_at ON after_sales_cases(created_at);
    CREATE INDEX IF NOT EXISTS idx_after_sales_cases_assigned_to ON after_sales_cases(assigned_to);
  `);
  await pool.query(`
    UPDATE after_sales_cases
    SET items=jsonb_build_array(jsonb_build_object(
      'model',coalesce(product_sku,''),'productName',coalesce(product_name,product_sku,''),
      'productType','','quantity',greatest(1,coalesce(quantity,1)),'color',coalesce(color,'')))
    WHERE items='[]'::jsonb AND coalesce(product_sku,product_name,'')<>''
  `);
  const oldScans = await pool.query('SELECT tracking_no,created_by,created_at FROM package_scans');
  for (const scan of oldScans.rows) {
    await pool.query(
      `INSERT INTO scan_registry(tracking_hash,tracking_no,scan_type,carrier,created_by,created_at)
       VALUES($1,$2,'aneng','安能',$3,$4)
       ON CONFLICT(tracking_hash) DO UPDATE SET tracking_no=COALESCE(scan_registry.tracking_no,EXCLUDED.tracking_no)`,
      [trackingHash(normalizeAnengTracking(scan.tracking_no)), normalizeAnengTracking(scan.tracking_no), scan.created_by, scan.created_at]
    );
  }
  await pool.query(`UPDATE scan_registry SET carrier='安能' WHERE scan_type='aneng' AND carrier='未分类'`);
  await pool.query(`UPDATE scan_registry SET tracking_no=NULL WHERE scan_type='volume' AND tracking_no IS NOT NULL`);
  await pool.query(`
    INSERT INTO scan_batches(batch_id,batch_name,created_by,created_at)
    SELECT batch_id,'历史安能批次',min(created_by),min(created_at)
    FROM package_scans GROUP BY batch_id
    ON CONFLICT(batch_id) DO NOTHING
  `);
  const admin = await pool.query('SELECT id FROM users WHERE username=$1', ['admin']);
  if (!admin.rows[0]) {
    if (!process.env.ADMIN_PASSWORD) throw new Error('首次启动必须配置 ADMIN_PASSWORD');
    await pool.query(
      'INSERT INTO users(username,display_name,password_hash,role) VALUES($1,$2,$3,$4)',
      ['admin', '系统管理员', hashPassword(process.env.ADMIN_PASSWORD), 'admin']
    );
  }
  for (const item of seedCatalog) {
    await pool.query(
      `INSERT INTO product_catalog(model,product_type,aliases,colors,color_required)
       VALUES($1,$2,$3,$4,$5) ON CONFLICT(model) DO UPDATE SET
       aliases=(SELECT string_agg(DISTINCT trim(v),',') FROM unnest(string_to_array(product_catalog.aliases||','||EXCLUDED.aliases,',')) v WHERE trim(v)<>''),
       colors=COALESCE((SELECT string_agg(DISTINCT trim(v),',') FROM unnest(string_to_array(product_catalog.colors||','||EXCLUDED.colors,',')) v WHERE trim(v)<>''),''),
       color_required=product_catalog.color_required OR EXCLUDED.color_required,
       updated_at=now()`,
      [item.model, item.productType, item.aliases.join(','), item.colors.join(','), item.colorRequired]
    );
  }
}

async function notifyNewPrintTask(row) {
  if (!feishuService.enabled()) return;
  const bound = await pool.query(
    `SELECT feishu_open_id FROM users WHERE active=true AND role='printer' AND feishu_open_id<>''`
  );
  const boundPrinterIds = bound.rows.map((item) => item.feishu_open_id);
  // Once printer accounts are bound in the admin UI, they are authoritative.
  // Legacy environment IDs remain only as a fallback for older installations.
  const receivers = [...new Set(boundPrinterIds.length ? boundPrinterIds : feishuService.printerIds)];
  if (!receivers.length) return;
  const card = {
    config: { wide_screen_mode: true },
    header: {
      title: { tag: 'plain_text', content: '新补发待打单' },
      template: 'blue',
    },
    elements: [
      {
        tag: 'div',
        fields: [
          { is_short: true, text: { tag: 'lark_md', content: `**订单号**\n${row.order_no || '待补充'}` } },
          { is_short: true, text: { tag: 'lark_md', content: `**平台**\n${row.platform || '未知'}` } },
          { is_short: true, text: { tag: 'lark_md', content: `**商品**\n${row.product_name || row.product_sku || '-'}` } },
          { is_short: true, text: { tag: 'lark_md', content: `**数量**\n${Number(row.quantity) || 1}` } },
          { is_short: false, text: { tag: 'lark_md', content: `**补发原因**\n${row.reason || '-'}` } },
        ],
      },
      { tag: 'hr' },
      {
        tag: 'action',
        layout: 'bisected',
        actions: [
          {
            tag: 'button',
            text: { tag: 'plain_text', content: '前往打单中心' },
            type: 'primary',
            url: 'https://frao.cn',
          },
        ],
      },
    ],
  };
  const fallbackText = `你有一个新的补发待打单任务\n订单号：${row.order_no || '待补充'}\n商品：${row.product_name || row.product_sku || '-'}\n数量：${Number(row.quantity) || 1}\n请打开 https://frao.cn 进入打单中心处理。`;
  let result;
  try {
    result = await feishuService.sendCard(receivers, card);
  } catch (error) {
    console.error('飞书打单卡片全部发送失败，改发文字通知', error);
    await feishuService.sendText(receivers, fallbackText);
    return;
  }
  if (result.failed) {
    console.error('飞书打单卡片部分发送失败', result.failureDetails);
    const fallback = await feishuService.sendText(
      result.failedOpenIds,
      fallbackText
    );
    if (fallback.failed) {
      console.error('飞书打单文字补发失败', fallback.failureDetails);
    }
  }
}

async function notifyTrackingCompleted(row) {
  if (!feishuService.enabled()) return;
  const creator = row.created_by ? await pool.query('SELECT feishu_open_id FROM users WHERE id=$1', [row.created_by]) : { rows: [] };
  const bound = await pool.query(
    `SELECT feishu_open_id FROM users WHERE active=true AND role IN ('customer_service','operator','admin') AND feishu_open_id<>''`
  );
  const receivers = [...new Set([
    creator.rows[0]?.feishu_open_id,
    ...feishuService.customerServiceIds,
    ...feishuService.operatorIds,
    ...bound.rows.map((item) => item.feishu_open_id),
  ].filter(Boolean))];
  if (!receivers.length) return;
  const card = {
    config: { wide_screen_mode: true },
    header: {
      title: { tag: 'plain_text', content: '补发单已完成打单' },
      template: 'green',
    },
    elements: [
      {
        tag: 'div',
        fields: [
          { is_short: true, text: { tag: 'lark_md', content: `**订单号**\n${row.order_no || '-'}` } },
          { is_short: true, text: { tag: 'lark_md', content: `**快递公司**\n${row.shipping_carrier || '未填写'}` } },
          { is_short: false, text: { tag: 'lark_md', content: `**补发商品**\n${row.product_name || row.product_sku || '-'}` } },
          { is_short: false, text: { tag: 'lark_md', content: `**快递单号**\n${row.resend_tracking_no || '未填写'}` } },
        ],
      },
      { tag: 'hr' },
      {
        tag: 'action',
        layout: 'bisected',
        actions: [
          {
            tag: 'button',
            text: { tag: 'plain_text', content: '查看详情' },
            type: 'default',
            url: 'https://frao.cn',
          },
        ],
      },
    ],
  };
  await feishuService.sendCard(receivers, card);
}

async function catalogForParser() {
  const { rows } = await pool.query('SELECT * FROM product_catalog WHERE active=true ORDER BY length(model) DESC');
  return rows.map((x) => ({
    model: x.model,
    productType: x.product_type,
    aliases: x.aliases.split(',').map((v) => v.trim()).filter(Boolean),
    colors: x.colors.split(',').map((v) => v.trim()).filter(Boolean),
    colorRequired: x.color_required,
  }));
}

function normalizeCaseItems(value, fallback = {}) {
  const source = Array.isArray(value) && value.length ? value : [fallback];
  return source.slice(0, 20).map((item) => ({
    model: String(item.model || item.productSku || '').trim().slice(0, 100),
    productName: String(item.productName || item.model || item.productSku || '').trim().slice(0, 255),
    productType: String(item.productType || '').trim().slice(0, 100),
    quantity: Math.max(1, Math.min(999, Number(item.quantity) || 1)),
    color: String(item.color || '').trim().slice(0, 50),
  })).filter((item) => item.model || item.productName);
}

function summarizeCaseItems(items, fallback = {}) {
  if (!items.length) return {
    productSku: String(fallback.model || '').slice(0, 100),
    productName: String(fallback.productName || fallback.model || '').slice(0, 255),
    quantity: Math.max(1, Number(fallback.quantity) || 1),
    color: String(fallback.color || '').slice(0, 50),
  };
  const labels = items.map((item) => `${item.model || item.productName}${item.color ? ` ${item.color}` : ''} ×${item.quantity}`);
  return {
    productSku: [...new Set(items.map((item) => item.model).filter(Boolean))].join(' + ').slice(0, 100),
    productName: labels.join('；').slice(0, 255),
    quantity: items.reduce((sum, item) => sum + item.quantity, 0),
    color: [...new Set(items.map((item) => item.color).filter(Boolean))].join(' + ').slice(0, 50),
  };
}

function parsedCaseData(parsed) {
  const items = normalizeCaseItems(parsed.items, parsed);
  return { items, summary: summarizeCaseItems(items, parsed) };
}

function applyLegacyOverrides(parsed, overrides = {}) {
  const hasLegacyItem = ['model', 'productName', 'productType', 'quantity', 'color'].some((key) => overrides[key] !== undefined);
  if (!Array.isArray(overrides.items) && hasLegacyItem) {
    parsed.items = [{
      model: overrides.model ?? parsed.model,
      productName: overrides.productName ?? overrides.model ?? parsed.productName,
      productType: overrides.productType ?? parsed.productType,
      quantity: overrides.quantity ?? parsed.quantity,
      color: overrides.color ?? parsed.color,
    }];
  }
  return parsed;
}

function needsAi(parsed) {
  return parsed.needReview || !parsed.orderNo || !parsed.model || parsed.platform === '未知平台';
}

function mergeAiResult(local, ai, catalog) {
  const models = new Set(catalog.map((item) => item.model));
  const orderNo = String(ai.orderNo || '').trim();
  const validOrder = /^\d{5,8}-\d{10,24}$|^\d{12,22}$/.test(orderNo);
  const aiSourceItems = Array.isArray(ai.items) && ai.items.length ? ai.items : [ai];
  const aiItems = aiSourceItems.map((source) => {
    if (!models.has(source.model)) return null;
    const entry = catalog.find((candidate) => candidate.model === source.model);
    return {
      model: entry.model,
      productName: entry.model,
      productType: entry.productType,
      quantity: Math.max(1, Math.min(999, Number(source.quantity) || 1)),
      color: entry.colorRequired ? String(source.color || '').trim() : '',
      colorRequired: entry.colorRequired,
    };
  }).filter(Boolean);
  const items = aiItems.length ? aiItems : (local.items || []);
  const first = items[0] || local;
  const result = {
    ...local,
    platform: local.platform !== '未知平台' ? local.platform : (['拼多多','抖店','淘宝/天猫'].includes(ai.platform) ? ai.platform : local.platform),
    orderNo: local.orderNo || (validOrder ? orderNo : ''),
    type: ['补发','换货','退件'].includes(ai.type) ? ai.type : local.type,
    model: first.model || '',
    productName: first.productName || first.model || '',
    productType: first.productType || '',
    quantity: first.quantity || 1,
    color: first.color || '',
    colorRequired: Boolean(first.colorRequired),
    items,
  };
  const warnings = [];
  if (!result.orderNo) warnings.push('未识别订单号');
  if (result.platform === '未知平台') warnings.push('未识别平台');
  if (!result.model) warnings.push('未识别商品型号');
  result.items.forEach((item, index) => {
    if (item.colorRequired && !item.color) warnings.push(`第${index + 1}项“${item.model}”需要确认颜色`);
  });
  if (Number(ai.confidence || 0) < 0.75) warnings.push('AI 识别置信度较低，请人工确认');
  return { ...result, warnings, needReview: warnings.length > 0 };
}

async function parseWithDeepSeek(text, catalog) {
  if (!process.env.DEEPSEEK_API_KEY) throw Object.assign(new Error('尚未配置 DeepSeek API Key'), { status: 503 });
  const catalogText = catalog.map((item) =>
    `${item.model}|别名:${item.aliases.join('/') || item.model}|颜色:${item.colors.join('/') || '无'}|颜色必填:${item.colorRequired ? '是' : '否'}`
  ).join('\n');
  const promptVersion = 'after-sales-v2-items';
  const cacheKey = crypto.createHash('sha256').update(`${promptVersion}\n${catalogText}\n${String(text).trim()}`).digest('hex');
  const cached = await pool.query('SELECT result FROM ai_parse_cache WHERE cache_key=$1', [cacheKey]);
  if (cached.rows[0]) {
    await pool.query('UPDATE ai_parse_cache SET hit_count=hit_count+1,updated_at=now() WHERE cache_key=$1', [cacheKey]);
    return { result: cached.rows[0].result, cached: true, usage: null };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}` },
      signal: controller.signal,
      body: JSON.stringify({
        model: process.env.DEEPSEEK_MODEL || 'deepseek-v4-flash',
        thinking: { type: 'disabled' },
        response_format: { type: 'json_object' },
        max_tokens: 520,
        temperature: 0,
        messages: [
          { role: 'system', content: `你是网店售后信息提取器。只输出 JSON，不解释，不得编造订单号和商品。商品必须从目录选择。每种型号、颜色或配件分别放入 items。输出格式：{"platform":"","orderNo":"","type":"补发","items":[{"model":"","quantity":1,"color":""}],"confidence":0.0}\n商品目录：\n${catalogText}` },
          { role: 'user', content: `请从这句客服原话提取 json：${String(text).slice(0, 500)}` },
        ],
      }),
    });
    const payload = await response.json();
    if (!response.ok) throw Object.assign(new Error(payload.error?.message || 'DeepSeek 调用失败'), { status: 502 });
    const content = payload.choices?.[0]?.message?.content;
    if (!content) throw Object.assign(new Error('DeepSeek 返回内容为空'), { status: 502 });
    const result = JSON.parse(content);
    const usage = payload.usage || {};
    await pool.query(
      `INSERT INTO ai_parse_cache(cache_key,result,prompt_tokens,completion_tokens,cache_hit_tokens)
       VALUES($1,$2,$3,$4,$5)`,
      [cacheKey, result, usage.prompt_tokens || 0, usage.completion_tokens || 0, usage.prompt_cache_hit_tokens || 0]
    );
    return { result, cached: false, usage };
  } finally {
    clearTimeout(timer);
  }
}

async function auth(req, res, next) {
  const token = cookie(req, 'as_session');
  const session = token && sessions.get(token);
  if (!session || session.expires < Date.now()) return res.status(401).json({ error: '请先登录' });
  const { rows } = await pool.query('SELECT * FROM users WHERE id=$1 AND active=true', [session.userId]);
  if (!rows[0]) return res.status(401).json({ error: '账号不可用' });
  req.user = rows[0];
  next();
}
function integrationAuth(req, res, next) {
  const expected = String(process.env.FEISHU_INTEGRATION_TOKEN || '');
  if (!expected) return res.status(503).json({ error: '飞书集成尚未配置' });
  const authorization = String(req.headers.authorization || '');
  const provided = authorization.startsWith('Bearer ') ? authorization.slice(7).trim() : '';
  const expectedHash = crypto.createHash('sha256').update(expected).digest();
  const providedHash = crypto.createHash('sha256').update(provided).digest();
  if (!provided || !crypto.timingSafeEqual(expectedHash, providedHash)) {
    return res.status(401).json({ error: '飞书集成鉴权失败' });
  }
  next();
}
const allow = (...roles) => (req, res, next) => roles.includes(req.user.role) ? next() : res.status(403).json({ error: '没有操作权限' });
const run = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
async function audit(req, action, caseId, detail = '') {
  await pool.query('INSERT INTO audit_logs(case_id,user_id,action,detail) VALUES($1,$2,$3,$4)', [caseId || null, req.user.id, action, detail]);
}

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'after-sales-api', version: '1.12.8' }));
app.post('/api/auth/login', run(async (req, res) => {
  const username = String(req.body.username || '').trim();
  const clientIp = String(req.headers['x-forwarded-for'] || req.ip || '').split(',')[0].trim();
  const attemptKey = `${clientIp}:${username}`;
  const attempt = loginAttempts.get(attemptKey);
  if (attempt && attempt.count >= 10 && attempt.until > Date.now()) return res.status(429).json({ error: '登录失败次数过多，请15分钟后再试' });
  const { rows } = await pool.query('SELECT * FROM users WHERE username=$1 AND active=true', [username]);
  if (!rows[0] || !verifyPassword(req.body.password, rows[0].password_hash)) {
    loginAttempts.set(attemptKey, { count: (attempt?.until > Date.now() ? attempt.count : 0) + 1, until: Date.now() + 15 * 60 * 1000 });
    return res.status(401).json({ error: '账号或密码错误' });
  }
  loginAttempts.delete(attemptKey);
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { userId: rows[0].id, expires: Date.now() + 12 * 60 * 60 * 1000 });
  res.setHeader('Set-Cookie', `as_session=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=43200`);
  res.json(safeUser(rows[0]));
}));
app.post('/api/auth/logout', auth, (req, res) => {
  sessions.delete(cookie(req, 'as_session'));
  res.setHeader('Set-Cookie', 'as_session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0');
  res.json({ ok: true });
});
app.get('/api/auth/me', auth, (req, res) => res.json(safeUser(req.user)));
app.post('/api/auth/change-password', auth, run(async (req, res) => {
  if (!verifyPassword(req.body.oldPassword, req.user.password_hash)) return res.status(400).json({ error: '原密码不正确' });
  if (String(req.body.newPassword || '').length < 8) return res.status(400).json({ error: '新密码至少8位' });
  await pool.query('UPDATE users SET password_hash=$1,updated_at=now() WHERE id=$2', [hashPassword(req.body.newPassword), req.user.id]);
  await audit(req, '修改登录密码', null);
  res.json({ ok: true });
}));

app.post('/api/parse', auth, allow('admin', 'customer_service', 'operator'), run(async (req, res) => {
  const text = String(req.body.text || '').trim();
  const catalog = await catalogForParser();
  const local = parseAfterSalesText(text, catalog);
  const mode = req.query.ai || 'auto';
  const shouldCall = mode === 'force' || (mode === 'auto' && needsAi(local));
  if (!shouldCall || !process.env.DEEPSEEK_API_KEY) {
    return res.json({ ...local, source: 'rules', aiAvailable: Boolean(process.env.DEEPSEEK_API_KEY) });
  }
  try {
    const ai = await parseWithDeepSeek(text, catalog);
    res.json({ ...mergeAiResult(local, ai.result, catalog), source: ai.cached ? 'ai_cache' : 'ai', aiAvailable: true, aiUsage: ai.usage });
  } catch (error) {
    if (mode === 'force') throw error;
    res.json({ ...local, source: 'rules_fallback', aiAvailable: true, aiError: 'AI 暂时不可用，已使用本地规则' });
  }
}));

app.get('/api/dashboard', auth, allow('admin', 'customer_service', 'printer', 'operator'), run(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT count(*)::int total,
      count(*) FILTER (WHERE status='need_review')::int need_review,
      count(*) FILTER (WHERE status IN ('pending','processing'))::int pending,
      count(*) FILTER (WHERE status='done')::int done,
      count(*) FILTER (WHERE created_at::date=current_date)::int today,
      count(*) FILTER (WHERE due_at < now() AND status NOT IN ('done','cancelled'))::int overdue,
      count(*) FILTER (WHERE resend_tracking_no IS NULL OR resend_tracking_no='')::int no_tracking
    FROM after_sales_cases`);
  res.json(rows[0]);
}));

app.get('/api/cases', auth, allow('admin', 'customer_service', 'printer', 'operator'), run(async (req, res) => {
  const params = [];
  const where = [];
  if (req.query.status) { params.push(req.query.status); where.push(`c.status=$${params.length}`); }
  if (req.query.type) { params.push(req.query.type); where.push(`c.type=$${params.length}`); }
  if (req.query.platform) { params.push(req.query.platform); where.push(`c.platform=$${params.length}`); }
  if (req.query.priority) { params.push(req.query.priority); where.push(`c.priority=$${params.length}`); }
  if (req.query.createdBy) { params.push(req.query.createdBy); where.push(`c.created_by=$${params.length}`); }
  if (req.query.assignedTo) { params.push(req.query.assignedTo); where.push(`c.assigned_to=$${params.length}`); }
  if (req.query.dateFrom) { params.push(req.query.dateFrom); where.push(`c.created_at >= $${params.length}::date`); }
  if (req.query.dateTo) { params.push(req.query.dateTo); where.push(`c.created_at < ($${params.length}::date + interval '1 day')`); }
  if (req.query.tracking === 'missing') where.push(`coalesce(c.resend_tracking_no,'')=''`);
  if (req.query.tracking === 'filled') where.push(`coalesce(c.resend_tracking_no,'')<>''`);
  if (req.query.overdue === 'true') where.push(`c.due_at < now() AND c.status NOT IN ('done','cancelled')`);
  if (req.query.keyword) {
    params.push(`%${req.query.keyword}%`);
    where.push(`concat_ws(' ',c.order_no,c.platform,c.shop_name,c.customer_name,c.customer_phone,c.product_name,c.product_sku,c.color,c.resend_tracking_no,c.reason,c.remark,c.tags) ILIKE $${params.length}`);
  }
  const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 50));
  const page = Math.max(1, Number(req.query.page) || 1);
  const count = await pool.query(`SELECT count(*)::int total FROM after_sales_cases c ${where.length ? `WHERE ${where.join(' AND ')}` : ''}`, params);
  params.push(limit, (page - 1) * limit);
  const { rows } = await pool.query(
    `SELECT c.*,u.display_name created_by_name,a.display_name assigned_to_name
     FROM after_sales_cases c
     LEFT JOIN users u ON u.id=c.created_by LEFT JOIN users a ON a.id=c.assigned_to
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY CASE c.priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 ELSE 3 END,c.created_at DESC
     LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
  res.json({ rows, total: count.rows[0].total, page, pageSize: limit });
}));

app.get('/api/cases/export.csv', auth, allow('admin', 'customer_service', 'operator'), run(async (req, res) => {
  const params = [];
  const where = [];
  if (req.query.status) { params.push(req.query.status); where.push(`status=$${params.length}`); }
  if (req.query.type) { params.push(req.query.type); where.push(`type=$${params.length}`); }
  if (req.query.platform) { params.push(req.query.platform); where.push(`platform=$${params.length}`); }
  if (req.query.priority) { params.push(req.query.priority); where.push(`priority=$${params.length}`); }
  if (req.query.createdBy) { params.push(req.query.createdBy); where.push(`created_by=$${params.length}`); }
  if (req.query.assignedTo) { params.push(req.query.assignedTo); where.push(`assigned_to=$${params.length}`); }
  if (req.query.dateFrom) { params.push(req.query.dateFrom); where.push(`created_at >= $${params.length}::date`); }
  if (req.query.dateTo) { params.push(req.query.dateTo); where.push(`created_at < ($${params.length}::date + interval \'1 day\')`); }
  if (req.query.tracking === 'missing') where.push(`coalesce(resend_tracking_no,'')=''`);
  if (req.query.tracking === 'filled') where.push(`coalesce(resend_tracking_no,'')<>''`);
  if (req.query.overdue === 'true') where.push(`due_at < now() AND status NOT IN ('done','cancelled')`);
  if (req.query.keyword) {
    params.push(`%${req.query.keyword}%`);
    where.push(`concat_ws(' ',order_no,platform,shop_name,customer_name,customer_phone,product_name,product_sku,color,resend_tracking_no,reason,remark,tags) ILIKE $${params.length}`);
  }
  const allFields = [
    ['case_no','工单号'],['type','类型'],['status','状态'],['platform','平台'],
    ['shop_name','店铺'],['order_no','订单号'],['customer_name','客户姓名'],
    ['customer_phone','客户电话'],['product_name','商品名称'],['product_sku','商品型号'],
    ['quantity','数量'],['color','颜色'],['reason','补发原因'],['solution','处理方案'],
    ['resend_tracking_no','补发快递单号'],['shipping_carrier','快递公司'],
    ['priority','优先级'],['due_at','要求完成时间'],['remark','备注'],['tags','标签'],
    ['created_at','创建时间'],['completed_at','完成时间'],['created_by_name','创建人'],
    ['assigned_to_name','负责人'],
  ];
  const requested = Array.isArray(req.query.fields) ? req.query.fields : (req.query.fields ? String(req.query.fields).split(',') : []);
  const selected = requested.length ? allFields.filter(([key]) => requested.includes(key)) : allFields;
  const keys = selected.map(([key]) => key);
  const headers = selected.map(([, label]) => label);
  const { rows } = await pool.query(
    `SELECT c.*,u.display_name created_by_name,a.display_name assigned_to_name
     FROM after_sales_cases c
     LEFT JOIN users u ON u.id=c.created_by LEFT JOIN users a ON a.id=c.assigned_to
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY c.created_at DESC LIMIT 5000`, params);
  const esc = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;
  const csv = '\ufeff' + [headers.join(','), ...rows.map((r) => keys.map((f) => esc(r[f])).join(','))].join('\r\n');
  res.type('text/csv').set('Content-Disposition', 'attachment; filename=after-sales.csv').send(csv);
}));

app.get('/api/cases/:id', auth, allow('admin', 'customer_service', 'printer', 'operator'), run(async (req, res) => {
  const item = await pool.query('SELECT * FROM after_sales_cases WHERE id=$1', [req.params.id]);
  if (!item.rows[0]) return res.status(404).json({ error: '记录不存在' });
  const logs = await pool.query('SELECT l.*,u.display_name FROM audit_logs l LEFT JOIN users u ON u.id=l.user_id WHERE case_id=$1 ORDER BY l.created_at DESC', [req.params.id]);
  res.json({ case: item.rows[0], logs: logs.rows });
}));

app.get('/api/integrations/feishu/cases/by-order/:orderNo', integrationAuth, run(async (req, res) => {
  const orderNo = normalizeOrderNo(req.params.orderNo);
  if (!orderNo) return res.status(400).json({ error: '订单号格式不正确' });
  const { rows } = await pool.query(
    `SELECT id,case_no,type,status,platform,order_no,product_name,product_sku,quantity,color,items,
      resend_tracking_no,reason,solution,remark,created_at,updated_at,completed_at
     FROM after_sales_cases
     WHERE order_no=$1
     ORDER BY CASE WHEN status='cancelled' THEN 1 ELSE 0 END,created_at DESC
     LIMIT 10`,
    [orderNo]
  );
  res.json({ orderNo, found: rows.length > 0, case: safeCase(rows[0]), cases: rows.map(safeCase) });
}));

app.get('/api/integrations/feishu/users/by-open-id/:openId', integrationAuth, run(async (req, res) => {
  const openId = String(req.params.openId || '').trim();
  const { rows } = await pool.query(
    `SELECT id,username,display_name,role
     FROM users
     WHERE active=true AND feishu_open_id=$1
     LIMIT 1`,
    [openId]
  );
  res.json({
    found: Boolean(rows[0]),
    user: rows[0] || null,
  });
}));

app.post('/api/integrations/feishu/parse', integrationAuth, run(async (req, res) => {
  const text = String(req.body.text || '').trim();
  if (!text) return res.status(400).json({ error: '请输入客服原话' });
  const parsed = parseAfterSalesText(text, await catalogForParser());
  res.json(parsed);
}));

app.post('/api/integrations/feishu/cases', integrationAuth, run(async (req, res) => {
  const text = String(req.body.text || '').trim();
  const openId = String(req.body.openId || '').trim();
  const overrides = req.body.overrides || {};
  if (!text) return res.status(400).json({ error: '请输入客服原话' });
  if (!openId) return res.status(400).json({ error: '缺少用户标识' });
  const userResult = await pool.query('SELECT * FROM users WHERE active=true AND feishu_open_id=$1 LIMIT 1', [openId]);
  if (!userResult.rows[0]) return res.status(404).json({ error: '未找到绑定的客服账号，请先在管理后台绑定飞书 open_id' });
  const user = userResult.rows[0];
  if (!['admin', 'customer_service', 'operator'].includes(user.role)) {
    return res.status(403).json({ error: '该账号没有建单权限' });
  }
  const parsed = applyLegacyOverrides({ ...parseAfterSalesText(text, await catalogForParser()), ...overrides }, overrides);
  const { items, summary } = parsedCaseData(parsed);
  const duplicate = parsed.orderNo
    ? await pool.query("SELECT case_no FROM after_sales_cases WHERE order_no=$1 AND status<>'cancelled' LIMIT 1", [parsed.orderNo])
    : { rows: [] };
  if (duplicate.rows[0] && !req.body.allowDuplicate) {
    return res.status(409).json({ error: `该订单已有售后单 ${duplicate.rows[0].case_no}`, duplicate: true, parsed });
  }
  const caseNo = `AS${new Date().toISOString().slice(0,10).replaceAll('-','')}${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
  const warnings = parsed.warnings || [];
  const { rows } = await pool.query(
    `INSERT INTO after_sales_cases(case_no,type,status,platform,shop_name,order_no,customer_name,customer_phone,
      product_name,product_sku,quantity,color,reason,solution,parsed_raw_text,parse_warnings,remark,created_by,source,items)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,'feishu',$19::jsonb) RETURNING *`,
    [caseNo,parsed.type,parsed.needReview?'need_review':'pending',parsed.platform,req.body.shopName||'',parsed.orderNo,
      req.body.customerName||'',req.body.customerPhone||'',summary.productName,summary.productSku,summary.quantity,summary.color,
      req.body.reason||text,req.body.solution||parsed.type,text,warnings.join('；'),req.body.remark||'',user.id,JSON.stringify(items)]
  );
  const fakeReq = { user, ip: () => 'feishu' };
  await audit(fakeReq, '飞书建单', rows[0].id, text);
  if (rows[0].status === 'pending') notifyNewPrintTask(rows[0]).catch((error) => console.error('飞书建单通知失败', error));
  res.status(201).json({ case: safeCase(rows[0]), parsed, createdBy: user.display_name });
}));

app.post('/api/cases/from-text', auth, allow('admin', 'customer_service', 'operator'), run(async (req, res) => {
  const text = String(req.body.text || '').trim();
  if (!text) return res.status(400).json({ error: '请输入客服原话' });
  const overrides = req.body.overrides || {};
  const parsed = applyLegacyOverrides({ ...parseAfterSalesText(text, await catalogForParser()), ...overrides }, overrides);
  const { items, summary } = parsedCaseData(parsed);
  const duplicate = parsed.orderNo ? await pool.query("SELECT case_no FROM after_sales_cases WHERE order_no=$1 AND status<>'cancelled' LIMIT 1", [parsed.orderNo]) : { rows: [] };
  if (duplicate.rows[0] && !req.body.allowDuplicate) return res.status(409).json({ error: `该订单已有售后单 ${duplicate.rows[0].case_no}`, duplicate: true, parsed });
  const caseNo = `AS${new Date().toISOString().slice(0,10).replaceAll('-','')}${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
  const warnings = parsed.warnings || [];
  const { rows } = await pool.query(
    `INSERT INTO after_sales_cases(case_no,type,status,platform,shop_name,order_no,customer_name,customer_phone,
      product_name,product_sku,quantity,color,reason,solution,parsed_raw_text,parse_warnings,remark,created_by,items)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19::jsonb) RETURNING *`,
    [caseNo,parsed.type,parsed.needReview?'need_review':'pending',parsed.platform,req.body.shopName||'',parsed.orderNo,
      req.body.customerName||'',req.body.customerPhone||'',summary.productName,summary.productSku,summary.quantity,summary.color,
      req.body.reason||text,req.body.solution||parsed.type,text,warnings.join('；'),req.body.remark||'',req.user.id,JSON.stringify(items)]
  );
  await audit(req, '创建售后单', rows[0].id, text);
  if (rows[0].status === 'pending') notifyNewPrintTask(rows[0]).catch((error) => console.error('飞书新任务通知失败', error));
  res.status(201).json({ case: rows[0], parsed });
}));

app.patch('/api/cases/:id', auth, allow('admin', 'customer_service', 'operator'), run(async (req, res) => {
  const body = { ...req.body };
  if (body.status !== undefined && !['need_review','pending','processing','done','cancelled'].includes(body.status)) return res.status(400).json({ error: '工单状态不正确' });
  if (body.type !== undefined && !['补发','换货','退件'].includes(body.type)) return res.status(400).json({ error: '售后类型不正确' });
  if (body.priority !== undefined && !['normal','high','urgent'].includes(body.priority)) return res.status(400).json({ error: '优先级不正确' });
  if (body.items !== undefined) {
    const items = normalizeCaseItems(body.items);
    if (!items.length) return res.status(400).json({ error: '至少需要一条商品明细' });
    const summary = summarizeCaseItems(items);
    Object.assign(body, { items: JSON.stringify(items), product_sku: summary.productSku, product_name: summary.productName, quantity: summary.quantity, color: summary.color });
  }
  const allowed = ['type','status','platform','shop_name','order_no','customer_name','customer_phone','product_name','product_sku','quantity','color','reason','solution','remark','priority','due_at','tags','assigned_to','items'];
  const entries = Object.entries(body).filter(([key]) => allowed.includes(key));
  if (!entries.length) return res.status(400).json({ error: '没有可修改内容' });
  const before = await pool.query('SELECT status FROM after_sales_cases WHERE id=$1', [req.params.id]);
  if (!before.rows[0]) return res.status(404).json({ error: '记录不存在' });
  const values = entries.map(([, value]) => value);
  values.push(req.params.id);
  const set = entries.map(([key], i) => `${key}=$${i + 1}${key === 'items' ? '::jsonb' : ''}`).join(',');
  const { rows } = await pool.query(`UPDATE after_sales_cases SET ${set},updated_at=now() WHERE id=$${values.length} RETURNING *`, values);
  if (!rows[0]) return res.status(404).json({ error: '记录不存在' });
  await audit(req, '修改售后单', rows[0].id, entries.map(([k]) => k).join(','));
  if (before.rows[0].status !== 'pending' && rows[0].status === 'pending') {
    notifyNewPrintTask(rows[0]).catch((error) => console.error('飞书待打单通知失败', error));
  }
  res.json(rows[0]);
}));

app.delete('/api/cases/:id', auth, allow('admin', 'customer_service', 'operator'), run(async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM after_sales_cases WHERE id=$1', [req.params.id]);
  const row = rows[0];
  if (!row) return res.status(404).json({ error: '记录不存在' });
  if (row.status === 'done') return res.status(409).json({ error: '已完成工单不能取消或删除' });
  if (row.status === 'cancelled') {
    await audit(req, '删除已取消售后单', row.id, `订单号：${row.order_no || '-'}；商品：${row.product_sku || row.product_name || '-'}`);
    await pool.query('DELETE FROM after_sales_cases WHERE id=$1', [row.id]);
    return res.json({ ok: true, action: 'deleted' });
  }
  await audit(req, '取消售后单', row.id, `订单号：${row.order_no || '-'}；商品：${row.product_sku || row.product_name || '-'}`);
  await pool.query("UPDATE after_sales_cases SET status='cancelled',updated_at=now() WHERE id=$1", [row.id]);
  res.json({ ok: true, action: 'cancelled' });
}));

app.patch('/api/cases/:id/tracking', auth, allow('admin', 'printer', 'operator'), run(async (req, res) => {
  const trackingNo = String(req.body.trackingNo || '').trim().replace(/\s+/g, '');
  if (!/^[A-Za-z0-9-]{6,40}$/.test(trackingNo)) return res.status(400).json({ error: '快递单号格式不正确' });
  const requestedCarrier = String(req.body.shippingCarrier || '').trim().slice(0, 50);
  const detected = detectCarrier(trackingNo);
  const shippingCarrier = !requestedCarrier || requestedCarrier === '自动识别' ? detected.carrier : requestedCarrier;
  const { rows } = await pool.query(
    `UPDATE after_sales_cases SET resend_tracking_no=$1,shipping_carrier=COALESCE(NULLIF($2,''),shipping_carrier),
      status='done',completed_at=now(),updated_at=now() WHERE id=$3 AND status IN ('pending','processing') RETURNING *`,
    [trackingNo, shippingCarrier, req.params.id]);
  if (!rows[0]) {
    const existing = await pool.query('SELECT status FROM after_sales_cases WHERE id=$1', [req.params.id]);
    return res.status(existing.rows[0] ? 409 : 404).json({ error: existing.rows[0] ? '该工单尚未确认或已经结束，不能完成打单' : '记录不存在' });
  }
  await audit(req, '填写快递单号', rows[0].id, trackingNo);
  notifyTrackingCompleted(rows[0]).catch((error) => console.error('飞书打单通知失败', error));
  res.json(rows[0]);
}));

app.get('/api/package-scans', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const params = [];
  const where = [];
  if (req.query.batchId) { params.push(req.query.batchId); where.push(`s.batch_id=$${params.length}`); }
  if (req.query.date) { params.push(req.query.date); where.push(`s.created_at::date=$${params.length}::date`); }
  const { rows } = await pool.query(
    `SELECT s.*,u.display_name created_by_name FROM package_scans s LEFT JOIN users u ON u.id=s.created_by
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY s.created_at DESC LIMIT 2000`, params);
  res.json(rows);
}));

app.post('/api/package-scans/daily-spec', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const cartonSpec = String(req.body.cartonSpec || '').trim().slice(0, 100);
  if (!cartonSpec) return res.status(400).json({ error: '请先选择纸箱规格' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await activateDailySpec(client, cartonSpec, req.user.id);
    await client.query('COMMIT');
    res.json(result);
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}));

app.post('/api/package-scans', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const originalTrackingNo = normalizeTracking(req.body.trackingNo);
  const trackingNo = normalizeAnengTracking(originalTrackingNo);
  const cartonSpec = String(req.body.cartonSpec || '').trim().slice(0, 100);
  if (!isAnengTracking(trackingNo)) return res.status(400).json({ error: '不是有效的安能单号：仅支持 74 或 75 开头的 12 位数字' });
  if (!cartonSpec) return res.status(400).json({ error: '请先选择纸箱规格' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const unique = await client.query(
      `INSERT INTO scan_registry(tracking_hash,tracking_no,scan_type,carrier,created_by) VALUES($1,$2,'aneng','安能',$3)
       ON CONFLICT DO NOTHING RETURNING tracking_hash`,
      [trackingHash(trackingNo), trackingNo, req.user.id]);
    if (!unique.rows[0]) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: '该单号已经扫描过，不能重复保存', duplicate: true });
    }
    const daily = await activateDailySpec(client, cartonSpec, req.user.id);
    const batchId = daily.batch.batch_id;
    const { rows } = await client.query(
      'INSERT INTO package_scans(tracking_no,carton_spec,batch_id,created_by) VALUES($1,$2,$3,$4) RETURNING *',
      [trackingNo, cartonSpec, batchId, req.user.id]);
    await client.query('UPDATE scan_batches SET copied_at=NULL,updated_at=now() WHERE batch_id=$1', [batchId]);
    await client.query('COMMIT');
    audit(req, '安能扫码', null, `纸箱规格：${cartonSpec}；批次：${batchId}`).catch(console.error);
    res.status(201).json({ ...rows[0], batch_id: batchId, normalized_from: originalTrackingNo !== trackingNo ? originalTrackingNo : null });
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}));

app.delete('/api/package-scans/:id', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const { rows } = await pool.query('DELETE FROM package_scans WHERE id=$1 RETURNING tracking_no,batch_id', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: '扫码记录不存在' });
  await Promise.all([
    pool.query('DELETE FROM scan_registry WHERE tracking_hash=$1 AND scan_type=$2', [trackingHash(normalizeAnengTracking(rows[0].tracking_no)), 'aneng']),
    pool.query('UPDATE scan_batches SET copied_at=NULL,updated_at=now() WHERE batch_id=$1', [rows[0].batch_id])
  ]);
  audit(req, '删除安能扫码', null, `批次：${rows[0].batch_id}`).catch(console.error);
  res.json({ ok: true });
}));

app.patch('/api/package-scans/:id/spec', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const cartonSpec = String(req.body.cartonSpec || '').trim().slice(0, 100);
  if (!cartonSpec) return res.status(400).json({ error: '纸箱规格不能为空' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const changed = await client.query(
      'UPDATE package_scans SET carton_spec=$1 WHERE id=$2 RETURNING *',
      [cartonSpec, req.params.id]
    );
    if (!changed.rows[0]) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: '扫码记录不存在' });
    }
    const oldBatchId = changed.rows[0].batch_id;
    const daily = await activateDailySpec(client, cartonSpec, req.user.id);
    await client.query('UPDATE scan_batches SET copied_at=NULL,updated_at=now() WHERE batch_id=$1', [oldBatchId]);
    await client.query(
      `DELETE FROM scan_batches b WHERE b.batch_id=$1
       AND NOT EXISTS(SELECT 1 FROM package_scans s WHERE s.batch_id=b.batch_id)`,
      [oldBatchId]
    );
    const row = await client.query('SELECT * FROM package_scans WHERE id=$1', [req.params.id]);
    await client.query('COMMIT');
    audit(req, '修改纸箱规格', null, `今日规格：${cartonSpec}`).catch(console.error);
    res.json(row.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}));

app.get('/api/scan-batches', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT b.batch_id,b.batch_name,b.copied_at,b.created_at,
      count(s.id)::int total,
      string_agg(DISTINCT s.carton_spec, '、' ORDER BY s.carton_spec) specs
    FROM scan_batches b
    LEFT JOIN package_scans s ON s.batch_id=b.batch_id
    GROUP BY b.batch_id,b.batch_name,b.copied_at,b.created_at
    ORDER BY b.created_at DESC LIMIT 100`);
  res.json(rows);
}));

app.patch('/api/scan-batches/:batchId', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const fields = [];
  const values = [];
  if (req.body.batchName !== undefined) { values.push(String(req.body.batchName).trim().slice(0, 150)); fields.push(`batch_name=$${values.length}`); }
  if (req.body.copied === true) fields.push('copied_at=now()');
  if (req.body.copied === false) fields.push('copied_at=NULL');
  if (!fields.length) return res.status(400).json({ error: '没有可修改内容' });
  values.push(req.params.batchId);
  const { rows } = await pool.query(
    `UPDATE scan_batches SET ${fields.join(',')},updated_at=now() WHERE batch_id=$${values.length} RETURNING *`, values);
  if (!rows[0]) return res.status(404).json({ error: '批次不存在' });
  res.json(rows[0]);
}));

app.delete('/api/scan-batches/:batchId', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const batch = await client.query('SELECT batch_id,batch_name FROM scan_batches WHERE batch_id=$1 FOR UPDATE', [req.params.batchId]);
    if (!batch.rows[0]) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: '批次不存在' });
    }
    const scans = await client.query('SELECT tracking_no FROM package_scans WHERE batch_id=$1', [req.params.batchId]);
    for (const scan of scans.rows) {
      await client.query(
        'DELETE FROM scan_registry WHERE tracking_hash=$1 AND scan_type=$2',
        [trackingHash(normalizeAnengTracking(scan.tracking_no)), 'aneng']
      );
    }
    await client.query('DELETE FROM package_scans WHERE batch_id=$1', [req.params.batchId]);
    await client.query('DELETE FROM scan_batches WHERE batch_id=$1', [req.params.batchId]);
    await client.query('COMMIT');
    audit(req, '删除安能批次', null, `批次：${batch.rows[0].batch_name}；数量：${scans.rows.length}`).catch(console.error);
    res.json({ ok: true, deleted: scans.rows.length });
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}));

app.get('/api/shipment-volume/today', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT count(*)::int total FROM scan_registry WHERE created_at::date=current_date`);
  res.json(rows[0]);
}));

app.post('/api/shipment-volume/scan', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const trackingNo = normalizeAnengTracking(normalizeTracking(req.body.trackingNo));
  if (!/^[A-Z0-9-]{6,40}$/.test(trackingNo)) return res.status(400).json({ error: '未识别到有效快递单号' });
  const requestedCarrier = String(req.body.carrier || '').trim().slice(0, 50);
  const detected = detectCarrier(trackingNo);
  const carrier = !requestedCarrier || requestedCarrier === '自动识别' ? detected.carrier : requestedCarrier;
  const { rows } = await pool.query(
    `INSERT INTO scan_registry(tracking_hash,tracking_no,scan_type,carrier,created_by) VALUES($1,NULL,'volume',$2,$3)
     ON CONFLICT DO NOTHING RETURNING tracking_hash`,
    [trackingHash(trackingNo), carrier, req.user.id]);
  if (!rows[0]) return res.status(409).json({ error: '该单号已经扫描过，不能重复统计', duplicate: true });
  audit(req, '统计发货量', null, `快递公司：${carrier}`).catch(console.error);
  const total = await pool.query('SELECT count(*)::int total FROM scan_registry WHERE created_at::date=current_date');
  res.status(201).json({ ok: true, total: total.rows[0].total, carrier });
}));

app.get('/api/return-receipts', auth, allow('admin', 'customer_service', 'warehouse', 'operator'), run(async (req, res) => {
  const params = [];
  const where = [];
  if (req.query.keyword) {
    params.push(`%${String(req.query.keyword).trim()}%`);
    where.push(`concat_ws(' ',r.tracking_no,r.carrier,r.return_type,r.remark,u.display_name) ILIKE $${params.length}`);
  }
  if (req.query.carrier) { params.push(req.query.carrier); where.push(`r.carrier=$${params.length}`); }
  if (req.query.returnType) { params.push(req.query.returnType); where.push(`r.return_type=$${params.length}`); }
  if (req.query.dateFrom) { params.push(req.query.dateFrom); where.push(`r.received_at >= $${params.length}::date`); }
  if (req.query.dateTo) { params.push(req.query.dateTo); where.push(`r.received_at < ($${params.length}::date + interval '1 day')`); }
  const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 100));
  const page = Math.max(1, Number(req.query.page) || 1);
  const count = await pool.query(
    `SELECT count(*)::int total FROM return_receipts r LEFT JOIN users u ON u.id=r.created_by ${where.length ? `WHERE ${where.join(' AND ')}` : ''}`,
    params
  );
  params.push(limit, (page - 1) * limit);
  const { rows } = await pool.query(
    `SELECT r.*,coalesce(u.display_name,'未知人员') created_by_name
     FROM return_receipts r LEFT JOIN users u ON u.id=r.created_by
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY r.received_at DESC,r.id DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );
  res.json({ rows, total: count.rows[0].total, page, pageSize: limit });
}));

app.post('/api/return-receipts', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const rawTrackingNo = normalizeTracking(req.body.trackingNo);
  const trackingNo = isAnengTracking(rawTrackingNo) ? normalizeAnengTracking(rawTrackingNo) : rawTrackingNo;
  if (!/^[A-Z0-9-]{6,40}$/.test(trackingNo)) return res.status(400).json({ error: '未识别到有效快递单号' });
  const returnType = ['退件', '拦截件'].includes(req.body.returnType) ? req.body.returnType : '退件';
  const detected = detectCarrier(trackingNo);
  const { rows } = await pool.query(
    `INSERT INTO return_receipts(tracking_no,carrier,carrier_confidence,return_type,remark,created_by)
     VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(tracking_no) DO NOTHING RETURNING *`,
    [trackingNo, detected.carrier, detected.confidence, returnType, String(req.body.remark || '').trim().slice(0, 500), req.user.id]
  );
  if (!rows[0]) return res.status(409).json({ error: '该退件单号已经入库，不能重复记录', duplicate: true });
  await audit(req, '退件扫码入库', null, `单号：${trackingNo}；快递：${detected.carrier}；类型：${returnType}`);
  res.status(201).json({ ...rows[0], created_by_name: req.user.display_name });
}));

app.patch('/api/return-receipts/:id', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const fields = [];
  const values = [];
  if (req.body.carrier !== undefined) {
    values.push(String(req.body.carrier || '待确认').trim().slice(0, 50) || '待确认');
    fields.push(`carrier=$${values.length}`, 'carrier_confidence=1');
  }
  if (req.body.returnType !== undefined) {
    if (!['退件', '拦截件'].includes(req.body.returnType)) return res.status(400).json({ error: '退件类型不正确' });
    values.push(req.body.returnType);
    fields.push(`return_type=$${values.length}`);
  }
  if (req.body.remark !== undefined) {
    values.push(String(req.body.remark || '').trim().slice(0, 500));
    fields.push(`remark=$${values.length}`);
  }
  if (!fields.length) return res.status(400).json({ error: '没有可修改内容' });
  values.push(req.params.id);
  const { rows } = await pool.query(
    `UPDATE return_receipts SET ${fields.join(',')},updated_at=now() WHERE id=$${values.length} RETURNING *`,
    values
  );
  if (!rows[0]) return res.status(404).json({ error: '退件记录不存在' });
  await audit(req, '修改退件记录', null, `单号：${rows[0].tracking_no}`);
  res.json(rows[0]);
}));

app.delete('/api/return-receipts/:id', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const { rows } = await pool.query('DELETE FROM return_receipts WHERE id=$1 RETURNING tracking_no', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: '退件记录不存在' });
  await audit(req, '删除退件记录', null, `单号：${rows[0].tracking_no}`);
  res.json({ ok: true });
}));

app.get('/api/shipping-stats', auth, allow('admin', 'warehouse', 'operator'), run(async (req, res) => {
  const validDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(String(value || '')) ? String(value) : '';
  const today = new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Shanghai' });
  const legacyDate = validDate(req.query.date);
  const dateFrom = validDate(req.query.dateFrom) || legacyDate || today;
  const dateTo = validDate(req.query.dateTo) || legacyDate || dateFrom;
  const start = new Date(`${dateFrom}T00:00:00Z`);
  const end = new Date(`${dateTo}T00:00:00Z`);
  const days = Math.floor((end - start) / 86400000) + 1;
  if (!Number.isFinite(days) || days < 1) return res.status(400).json({ error: '开始日期不能晚于结束日期' });
  if (days > 92) return res.status(400).json({ error: '单次查询最多支持 92 天' });
  const params = [dateFrom, dateTo];
  const scanFilter = `r.created_at >= $1::date AND r.created_at < ($2::date + interval '1 day')`;
  const packageFilter = `p.created_at >= $1::date AND p.created_at < ($2::date + interval '1 day')`;
  const returnFilter = `rr.received_at >= $1::date AND rr.received_at < ($2::date + interval '1 day')`;
  const [summary, carriers, people, cartons, shipments, returnSummary, returnCarriers, returns, daily] = await Promise.all([
    pool.query(`SELECT count(*)::int total,
      count(*) FILTER(WHERE r.scan_type='aneng')::int aneng,
      count(*) FILTER(WHERE r.scan_type='volume')::int volume,
      count(*) FILTER(WHERE r.carrier='待确认')::int pending_carrier
      FROM scan_registry r WHERE ${scanFilter}`, params),
    pool.query(`SELECT coalesce(nullif(r.carrier,''),'未分类') name,count(*)::int total
      FROM scan_registry r WHERE ${scanFilter} GROUP BY 1 ORDER BY total DESC,name`, params),
    pool.query(`SELECT coalesce(u.display_name,'未知人员') name,count(*)::int total
      FROM scan_registry r LEFT JOIN users u ON u.id=r.created_by
      WHERE ${scanFilter} GROUP BY 1 ORDER BY total DESC,name`, params),
    pool.query(`SELECT p.carton_spec name,count(*)::int total
      FROM package_scans p WHERE ${packageFilter} GROUP BY p.carton_spec ORDER BY total DESC,name`, params),
    pool.query(`SELECT r.tracking_no,r.carrier,r.scan_type,r.created_at,
        coalesce(u.display_name,'未知人员') created_by_name
      FROM scan_registry r LEFT JOIN users u ON u.id=r.created_by
      WHERE ${scanFilter} AND r.scan_type='aneng' ORDER BY r.created_at DESC LIMIT 2000`, params),
    pool.query(`SELECT count(*)::int total,
      count(*) FILTER(WHERE rr.return_type='退件')::int returned,
      count(*) FILTER(WHERE rr.return_type='拦截件')::int intercepted,
      count(*) FILTER(WHERE rr.carrier='待确认')::int pending_carrier
      FROM return_receipts rr WHERE ${returnFilter}`, params),
    pool.query(`SELECT rr.carrier name,count(*)::int total FROM return_receipts rr
      WHERE ${returnFilter} GROUP BY rr.carrier ORDER BY total DESC,name`, params),
    pool.query(`SELECT rr.*,coalesce(u.display_name,'未知人员') created_by_name
      FROM return_receipts rr LEFT JOIN users u ON u.id=rr.created_by
      WHERE ${returnFilter} ORDER BY rr.received_at DESC LIMIT 500`, params),
    pool.query(`WITH date_range AS (
        SELECT generate_series($1::date,$2::date,interval '1 day')::date AS stat_date
      ), shipments AS (
        SELECT r.created_at::date AS stat_date,count(*)::int total FROM scan_registry r
        WHERE ${scanFilter} GROUP BY r.created_at::date
      ), returned AS (
        SELECT rr.received_at::date AS stat_date,count(*)::int total FROM return_receipts rr
        WHERE ${returnFilter} GROUP BY rr.received_at::date
      )
      SELECT to_char(d.stat_date,'YYYY-MM-DD') date,coalesce(s.total,0)::int shipments,coalesce(rt.total,0)::int returns
      FROM date_range d
      LEFT JOIN shipments s ON s.stat_date=d.stat_date
      LEFT JOIN returned rt ON rt.stat_date=d.stat_date
      ORDER BY d.stat_date`, params)
  ]);
  res.json({
    dateFrom,
    dateTo,
    days,
    total: summary.rows[0].total,
    summary: summary.rows[0],
    returnsSummary: returnSummary.rows[0],
    carriers: carriers.rows,
    returnCarriers: returnCarriers.rows,
    people: people.rows,
    cartons: cartons.rows,
    shipments: shipments.rows,
    returns: returns.rows,
    daily: daily.rows,
  });
}));

app.get('/api/catalog', auth, run(async (req, res) => res.json((await pool.query('SELECT * FROM product_catalog ORDER BY model')).rows)));
app.post('/api/catalog', auth, allow('admin'), run(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO product_catalog(model,product_type,aliases,colors,color_required) VALUES($1,$2,$3,$4,$5) RETURNING *`,
    [b.model,b.productType||'',b.aliases||b.model,b.colors||'',Boolean(b.colorRequired)]);
  res.status(201).json(rows[0]);
}));
app.patch('/api/catalog/:id', auth, allow('admin'), run(async (req, res) => {
  const b = req.body;
  if (!String(b.model || '').trim()) return res.status(400).json({ error: '商品型号不能为空' });
  const { rows } = await pool.query(
    `UPDATE product_catalog SET model=$1,product_type=$2,aliases=$3,colors=$4,color_required=$5,active=$6,updated_at=now() WHERE id=$7 RETURNING *`,
    [String(b.model).trim(),b.product_type||'',b.aliases||'',b.colors||'',Boolean(b.color_required),b.active!==false,req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: '商品规则不存在' });
  await audit(req, '修改商品规则', null, `${rows[0].model} · ${rows[0].active ? '启用' : '停用'}`);
  res.json(rows[0]);
}));

app.get('/api/staff-options', auth, allow('admin', 'customer_service', 'printer', 'operator'), run(async (req, res) => {
  const { rows } = await pool.query(
    'SELECT id,display_name,role FROM users WHERE active=true ORDER BY display_name,id'
  );
  res.json(rows);
}));

app.get('/api/users', auth, allow('admin'), run(async (req, res) => {
  const { rows } = await pool.query('SELECT id,username,display_name,role,active,feishu_open_id,created_at FROM users ORDER BY id');
  res.json(rows);
}));
app.post('/api/users', auth, allow('admin'), run(async (req, res) => {
  const b = req.body;
  const roles = ['customer_service', 'printer', 'warehouse', 'operator', 'admin'];
  if (!b.username || String(b.password || '').length < 8) return res.status(400).json({ error: '账号必填，密码至少 8 位' });
  if (!roles.includes(b.role)) return res.status(400).json({ error: '账号角色不正确' });
  const feishuOpenId = String(b.feishuOpenId || '').trim();
  if (feishuOpenId) {
    const bound = await pool.query('SELECT display_name FROM users WHERE feishu_open_id=$1 LIMIT 1', [feishuOpenId]);
    if (bound.rows[0]) return res.status(409).json({ error: `该飞书 ID 已绑定给“${bound.rows[0].display_name}”` });
  }
  const { rows } = await pool.query(
    'INSERT INTO users(username,display_name,password_hash,role,feishu_open_id) VALUES($1,$2,$3,$4,$5) RETURNING *',
    [b.username,b.displayName||b.username,hashPassword(b.password),b.role||'customer_service',feishuOpenId]);
  res.status(201).json(safeUser(rows[0]));
}));
app.patch('/api/users/:id', auth, allow('admin'), run(async (req, res) => {
  const b = req.body;
  if (!['customer_service', 'printer', 'warehouse', 'operator', 'admin'].includes(b.role)) return res.status(400).json({ error: '账号角色不正确' });
  if (String(req.params.id) === String(req.user.id) && b.active === false) return res.status(400).json({ error: '不能停用当前登录账号' });
  const feishuOpenId = String(b.feishuOpenId || '').trim();
  if (feishuOpenId) {
    const bound = await pool.query(
      'SELECT display_name FROM users WHERE feishu_open_id=$1 AND id<>$2 LIMIT 1',
      [feishuOpenId, req.params.id]
    );
    if (bound.rows[0]) return res.status(409).json({ error: `该飞书 ID 已绑定给“${bound.rows[0].display_name}”` });
  }
  const password = b.password ? ',password_hash=$5' : '';
  const params = b.password
    ? [b.displayName,b.role,b.active,feishuOpenId,hashPassword(b.password),req.params.id]
    : [b.displayName,b.role,b.active,feishuOpenId,req.params.id];
  const idPos = params.length;
  const { rows } = await pool.query(`UPDATE users SET display_name=$1,role=$2,active=$3,feishu_open_id=$4${password},updated_at=now() WHERE id=$${idPos} RETURNING *`, params);
  res.json(safeUser(rows[0]));
}));

app.get('/api/integrations/feishu/status', auth, allow('admin'), run(async (req, res) => {
  const bound = await pool.query(
    `SELECT role,count(*)::int total FROM users
     WHERE active=true AND feishu_open_id<>'' GROUP BY role`
  );
  res.json({
    appEnabled: feishuService.enabled(),
    printerCount: feishuService.printerIds.length,
    customerServiceCount: feishuService.customerServiceIds.length,
    operatorCount: feishuService.operatorIds.length,
    boundUsers: Object.fromEntries(bound.rows.map((item) => [item.role, item.total])),
  });
}));

app.post('/api/users/:id/reset-password', auth, allow('admin'), run(async (req, res) => {
  const password = String(req.body.password || '');
  if (password.length < 8) return res.status(400).json({ error: '新密码至少 8 位' });
  const { rows } = await pool.query(
    'UPDATE users SET password_hash=$1,updated_at=now() WHERE id=$2 RETURNING *',
    [hashPassword(password), req.params.id]
  );
  if (!rows[0]) return res.status(404).json({ error: '账号不存在' });
  await audit(req, '管理员重置密码', null, `账号：${rows[0].username}`);
  res.json({ ok: true });
}));

app.get('/api/admin/overview', auth, allow('admin'), run(async (req, res) => {
  const [users, cases, scans, ai] = await Promise.all([
    pool.query(`SELECT count(*)::int total,count(*) FILTER(WHERE active)::int active FROM users`),
    pool.query(`SELECT count(*)::int total,
      count(*) FILTER(WHERE created_at::date=current_date)::int today,
      count(*) FILTER(WHERE status NOT IN ('done','cancelled'))::int open,
      count(*) FILTER(WHERE due_at<now() AND status NOT IN ('done','cancelled'))::int overdue
      FROM after_sales_cases`),
    pool.query(`SELECT count(*)::int total,count(*) FILTER(WHERE created_at::date=current_date)::int today FROM scan_registry`),
    pool.query(`SELECT count(*)::int cache_entries,coalesce(sum(hit_count),0)::int cache_hits,
      coalesce(sum(prompt_tokens),0)::int prompt_tokens,coalesce(sum(completion_tokens),0)::int completion_tokens
      FROM ai_parse_cache`)
  ]);
  res.json({ users: users.rows[0], cases: cases.rows[0], scans: scans.rows[0], ai: ai.rows[0] });
}));

app.get('/api/admin/audit-logs', auth, allow('admin'), run(async (req, res) => {
  const params = [];
  const where = [];
  if (req.query.userId) { params.push(req.query.userId); where.push(`l.user_id=$${params.length}`); }
  if (req.query.action) { params.push(req.query.action); where.push(`l.action=$${params.length}`); }
  if (req.query.dateFrom) { params.push(req.query.dateFrom); where.push(`l.created_at >= $${params.length}::date`); }
  if (req.query.dateTo) { params.push(req.query.dateTo); where.push(`l.created_at < ($${params.length}::date + interval \'1 day\')`); }
  if (req.query.keyword) {
    params.push(`%${req.query.keyword}%`);
    where.push(`(u.display_name ILIKE $${params.length} OR u.username ILIKE $${params.length} OR l.action ILIKE $${params.length} OR l.detail ILIKE $${params.length} OR c.order_no ILIKE $${params.length})`);
  }
  const limit = Math.min(500, Math.max(1, Number(req.query.limit) || 200));
  const { rows } = await pool.query(
    `SELECT l.*,u.display_name,u.username,c.order_no
     FROM audit_logs l LEFT JOIN users u ON u.id=l.user_id LEFT JOIN after_sales_cases c ON c.id=l.case_id
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY l.created_at DESC LIMIT ${limit}`, params);
  res.json(rows);
}));

app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === '23505') return res.status(409).json({ error: '数据重复，请检查账号、型号或单号' });
  if (err.status && err.status < 500) return res.status(err.status).json({ error: err.message || '请求处理失败' });
  res.status(500).json({ error: '服务器处理失败，请稍后重试' });
});

async function start() {
  await migrate();
  app.listen(3000, () => console.log('After-sales API 1.12.8 running on port 3000'));
  if (feishuService.enabled()) {
    console.log('飞书消息通知已启用');
  } else {
    console.log('飞书消息通知未启用：请检查 FEISHU_APP_ID 和 FEISHU_APP_SECRET');
  }
}

setInterval(() => {
  const now = Date.now();
  for (const [token, session] of sessions) if (session.expires < now) sessions.delete(token);
  for (const [key, attempt] of loginAttempts) if (attempt.until < now) loginAttempts.delete(key);
}, 10 * 60 * 1000).unref();
start().catch((err) => { console.error(err); process.exit(1); });
