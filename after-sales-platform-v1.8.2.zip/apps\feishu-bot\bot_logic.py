import re


ORDER_TOKEN = r"[A-Za-z0-9][A-Za-z0-9_-]{5,39}"
QUERY_PATTERN = re.compile(
    rf"^(?:查询|查一下|查|订单查询|查订单|进度|状态)\s*[:：]?\s*({ORDER_TOKEN})$",
    re.IGNORECASE,
)
PLAIN_PATTERN = re.compile(rf"^({ORDER_TOKEN})$", re.IGNORECASE)

STATUS_NAMES = {
    "need_review": "待确认",
    "pending": "待处理",
    "processing": "处理中",
    "done": "已完成",
    "cancelled": "已取消",
}
PLATFORM_NAMES = {
    "pinduoduo": "拼多多",
    "douyin": "抖音",
    "taobao": "淘宝/天猫",
    "jd": "京东",
    "kuaishou": "快手",
    "xiaohongshu": "小红书",
    "wechat": "视频号",
}


def extract_order_query(text):
    value = str(text or "").strip()
    for pattern in (QUERY_PATTERN, PLAIN_PATTERN):
        match = pattern.fullmatch(value)
        if match:
            return match.group(1)
    return ""


def format_case_reply(payload):
    order_no = str(payload.get("orderNo") or "")
    item = payload.get("case")
    if not payload.get("found") or not item:
        return "\n".join([
            "没有查询到这笔售后记录。",
            f"订单号：{order_no}",
            "请确认订单号是否完整，或联系管理员检查系统记录。",
        ])

    product = item.get("productSku") or item.get("productName") or "未记录"
    color = item.get("color") or ""
    quantity = item.get("quantity") or 0
    product_text = f"{product}{color}"
    if quantity:
        product_text += f" × {quantity}"

    lines = [
        "订单查询结果",
        f"订单号：{item.get('orderNo') or order_no}",
        f"平台：{PLATFORM_NAMES.get(item.get('platform'), item.get('platform') or '未记录')}",
        f"状态：{STATUS_NAMES.get(item.get('status'), item.get('status') or '未知')}",
        f"售后类型：{item.get('type') or '未记录'}",
        f"补发内容：{product_text}",
        f"补发原因：{item.get('reason') or '未记录'}",
        f"补发快递单号：{item.get('resendTrackingNo') or '未填写'}",
    ]
    case_count = len(payload.get("cases") or [])
    if case_count > 1:
        lines.append(f"提示：该订单共有 {case_count} 条售后记录，当前显示最新有效记录。")
    return "\n".join(lines)
