const assert = require('assert');
const {
  splitIds,
  quantityNumber,
  statusFromFeishu,
  mapBitableRecord,
  caseToBitableFields,
} = require('./feishu-service');

assert.deepStrictEqual(splitIds('ou_1, ou_2,,ou_1'), ['ou_1', 'ou_2', 'ou_1']);
assert.strictEqual(quantityNumber('两把'), 2);
assert.strictEqual(quantityNumber('3个'), 3);
assert.strictEqual(statusFromFeishu('待打单'), 'pending');
assert.strictEqual(statusFromFeishu('待确认'), 'need_review');
assert.strictEqual(statusFromFeishu('待打单', 'YT123'), 'done');

const mapped = mapBitableRecord({
  record_id: 'rec_1',
  fields: {
    平台: '拼多多',
    订单号: '260627-227897567592037',
    补发商品: '6600天空蓝',
    数量说明: '两把',
    补发原因: '漏发',
    状态: '待打单',
  },
});
assert.strictEqual(mapped.orderNo, '260627-227897567592037');
assert.strictEqual(mapped.quantity, 2);
assert.strictEqual(mapped.status, 'pending');

const fields = caseToBitableFields({ order_no: '1001', status: 'done', quantity: 2, resend_tracking_no: 'YT123' });
assert.strictEqual(fields['状态'], '已完成');
assert.strictEqual(fields['数量说明'], '2');

console.log('Feishu service helpers passed');
