import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque

from bot_logic import extract_order_query, format_case_reply


FEISHU_API = "https://open.feishu.cn/open-apis"
APP_ID = os.environ.get("FEISHU_APP_ID", "").strip()
APP_SECRET = os.environ.get("FEISHU_APP_SECRET", "").strip()
INTEGRATION_TOKEN = os.environ.get("FEISHU_INTEGRATION_TOKEN", "").strip()
AFTER_SALES_API_URL = os.environ.get("AFTER_SALES_API_URL", "http://api:3000").rstrip("/")
ALLOWED_OPEN_IDS = {
    value.strip()
    for value in os.environ.get("FEISHU_ALLOWED_OPEN_IDS", "").split(",")
    if value.strip()
}

_tenant_token = {"value": "", "expires_at": 0}
_token_lock = threading.Lock()
_processed_ids = set()
_processed_order = deque()
_processed_lock = threading.Lock()


def log(message, **fields):
    suffix = " ".join(f"{key}={value}" for key, value in fields.items())
    print(f"[feishu-bot] {message}{' ' + suffix if suffix else ''}", flush=True)


def json_request(url, method="GET", body=None, headers=None, timeout=12):
    request_headers = {"Content-Type": "application/json"}
    request_headers.update(headers or {})
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers=request_headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            detail = json.loads(raw).get("error") or raw
        except json.JSONDecodeError:
            detail = raw
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc


def tenant_access_token():
    with _token_lock:
        if _tenant_token["value"] and _tenant_token["expires_at"] > time.time() + 60:
            return _tenant_token["value"]
        result = json_request(
            f"{FEISHU_API}/auth/v3/tenant_access_token/internal",
            method="POST",
            body={"app_id": APP_ID, "app_secret": APP_SECRET},
        )
        token = result.get("tenant_access_token")
        if not token:
            raise RuntimeError(f"获取飞书 tenant_access_token 失败：{result.get('msg') or result}")
        _tenant_token["value"] = token
        _tenant_token["expires_at"] = time.time() + int(result.get("expire") or 7200)
        return token


def reply_text(message_id, text):
    token = tenant_access_token()
    return json_request(
        f"{FEISHU_API}/im/v1/messages/{urllib.parse.quote(message_id, safe='')}/reply",
        method="POST",
        headers={"Authorization": f"Bearer {token}"},
        body={"msg_type": "text", "content": json.dumps({"text": text}, ensure_ascii=False)},
    )


def query_case(order_no):
    return json_request(
        f"{AFTER_SALES_API_URL}/api/integrations/feishu/cases/by-order/"
        f"{urllib.parse.quote(order_no, safe='')}",
        headers={"Authorization": f"Bearer {INTEGRATION_TOKEN}"},
    )


def extract_text(content):
    try:
        return str(json.loads(content or "{}").get("text") or "").strip()
    except json.JSONDecodeError:
        return ""


def sender_open_id(event):
    sender_id = ((event.get("sender") or {}).get("sender_id") or {})
    return str(sender_id.get("open_id") or "")


def mark_once(message_id):
    with _processed_lock:
        if message_id in _processed_ids:
            return False
        _processed_ids.add(message_id)
        _processed_order.append(message_id)
        while len(_processed_order) > 5000:
            _processed_ids.discard(_processed_order.popleft())
        return True


def handle_message_event(data):
    event = data.get("event") or {}
    message = event.get("message") or {}
    message_id = str(message.get("message_id") or "")
    if not message_id or not mark_once(message_id):
        return None

    open_id = sender_open_id(event)
    if ALLOWED_OPEN_IDS and open_id not in ALLOWED_OPEN_IDS:
        reply_text(message_id, "当前账号没有订单查询权限，请联系管理员。")
        return None
    if message.get("message_type") != "text":
        reply_text(message_id, "请直接发送订单号，或发送“查询 + 订单号”。")
        return None

    text = extract_text(message.get("content"))
    order_no = extract_order_query(text)
    if not order_no:
        reply_text(message_id, "订单查询已上线。\n请直接发送订单号，或发送“查询 + 订单号”。")
        return None

    try:
        reply_text(message_id, format_case_reply(query_case(order_no)))
        log("订单查询完成", order_no=order_no, open_id=open_id)
    except Exception as exc:
        log("订单查询失败", order_no=order_no, error=exc)
        reply_text(message_id, "订单查询暂时失败，请稍后重试；如果持续失败，请联系管理员。")
    return None


def main():
    missing = [
        name
        for name, value in {
            "FEISHU_APP_ID": APP_ID,
            "FEISHU_APP_SECRET": APP_SECRET,
            "FEISHU_INTEGRATION_TOKEN": INTEGRATION_TOKEN,
        }.items()
        if not value
    ]
    if missing:
        raise SystemExit("缺少配置：" + ", ".join(missing))

    import lark_oapi as lark

    def on_message(data):
        payload = json.loads(lark.JSON.marshal(data))
        return handle_message_event(payload)

    log("正在启动飞书长连接", api=AFTER_SALES_API_URL)
    event_handler = (
        lark.EventDispatcherHandler.builder("", "")
        .register_p2_im_message_receive_v1(on_message)
        .build()
    )
    client = lark.ws.Client(
        APP_ID,
        APP_SECRET,
        event_handler=event_handler,
        log_level=lark.LogLevel.INFO,
    )
    client.start()


if __name__ == "__main__":
    main()
