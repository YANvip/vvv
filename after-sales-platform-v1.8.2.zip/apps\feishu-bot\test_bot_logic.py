import unittest

from bot_logic import extract_order_query, format_case_reply
import main


class BotLogicTests(unittest.TestCase):
    def test_extracts_plain_and_explicit_queries(self):
        self.assertEqual(extract_order_query("6927550207970082166"), "6927550207970082166")
        self.assertEqual(extract_order_query("查询 260627-227897567592037"), "260627-227897567592037")
        self.assertEqual(extract_order_query("你好"), "")

    def test_formats_completed_case(self):
        reply = format_case_reply({
            "orderNo": "6927550207970082166",
            "found": True,
            "case": {
                "orderNo": "6927550207970082166",
                "platform": "douyin",
                "status": "done",
                "type": "resend",
                "productSku": "7001",
                "productName": "",
                "color": "大象灰",
                "quantity": 1,
                "reason": "漏发",
                "resendTrackingNo": "YT123456789",
            },
            "cases": [{}],
        })
        self.assertIn("状态：已完成", reply)
        self.assertIn("补发内容：7001大象灰 × 1", reply)
        self.assertIn("补发快递单号：YT123456789", reply)

    def test_formats_missing_case(self):
        reply = format_case_reply({"orderNo": "1234567890", "found": False, "case": None, "cases": []})
        self.assertIn("没有查询到", reply)

    def test_message_event_queries_api_and_replies(self):
        replies = []
        original_query = main.query_case
        original_reply = main.reply_text
        try:
            main.query_case = lambda order_no: {
                "orderNo": order_no,
                "found": False,
                "case": None,
                "cases": [],
            }
            main.reply_text = lambda message_id, text: replies.append((message_id, text))
            main.handle_message_event({
                "event": {
                    "sender": {"sender_id": {"open_id": "ou_test"}},
                    "message": {
                        "message_id": "om_test_query",
                        "message_type": "text",
                        "content": '{"text":"查询 6927550207970082166"}',
                    },
                },
            })
        finally:
            main.query_case = original_query
            main.reply_text = original_reply
        self.assertEqual(replies[0][0], "om_test_query")
        self.assertIn("6927550207970082166", replies[0][1])


if __name__ == "__main__":
    unittest.main()
