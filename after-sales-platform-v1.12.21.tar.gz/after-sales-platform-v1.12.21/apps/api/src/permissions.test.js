const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const server = fs.readFileSync(path.join(__dirname, 'server.js'), 'utf8');
const web = fs.readFileSync(path.join(__dirname, '../../web/index.html'), 'utf8');
const adminWeb = fs.readFileSync(path.join(__dirname, '../../web/admin/index.html'), 'utf8');
const pdaWeb = fs.readFileSync(path.join(__dirname, '../../web/pda/index.html'), 'utf8');
assert.ok(server.includes('该飞书 ID 已绑定给'), 'duplicate Feishu binding protection missing');
assert.ok(
  server.includes("app.get('/api/integrations/feishu/users/by-open-id/:openId', integrationAuth"),
  'Feishu bound-user permission lookup missing'
);
assert.ok(!web.includes('id="loginUser" value="admin"'), 'login page must not prefill the admin account');
assert.ok(web.includes('function clearLoginForm()'), 'login fields must be cleared for shared devices');

const operatorRoutes = [
  "app.post('/api/parse', auth, allow('admin', 'customer_service', 'operator')",
  "app.post('/api/cases/from-text', auth, allow('admin', 'customer_service', 'operator')",
  "app.patch('/api/cases/:id', auth, allow('admin', 'customer_service', 'operator')",
  "app.delete('/api/cases/:id', auth, allow('admin', 'customer_service', 'operator')",
  "app.patch('/api/cases/:id/tracking', auth, allow('admin', 'printer', 'operator')",
  "app.post('/api/package-scans', auth, allow('admin', 'warehouse', 'operator')",
  "app.post('/api/package-scans/daily-spec', auth, allow('admin', 'warehouse', 'operator')",
  "app.post('/api/shipment-volume/scan', auth, allow('admin', 'warehouse', 'operator')",
  "app.get('/api/shipping-stats', auth, allow('admin', 'warehouse', 'operator')",
  "app.post('/api/return-receipts', auth, allow('admin', 'warehouse', 'operator')",
  "app.patch('/api/return-receipts/:id', auth, allow('admin', 'warehouse', 'operator')",
  "app.delete('/api/return-receipts/:id', auth, allow('admin', 'warehouse', 'operator')",
];

for (const route of operatorRoutes) {
  assert.ok(server.includes(route), `operator permission missing: ${route}`);
}

assert.ok(
  server.includes("app.get('/api/return-receipts', auth, allow('admin', 'customer_service', 'warehouse', 'operator')"),
  'return receipt lookup roles missing'
);

const adminOnlyRoutes = [
  "app.get('/api/users', auth, allow('admin')",
  "app.post('/api/users', auth, allow('admin')",
  "app.post('/api/catalog', auth, allow('admin')",
  "app.patch('/api/catalog/:id', auth, allow('admin')",
  "app.get('/api/integrations/feishu/status', auth, allow('admin')",
  "app.get('/api/admin/overview', auth, allow('admin')",
  "app.get('/api/admin/audit-logs', auth, allow('admin')",
];

for (const route of adminOnlyRoutes) {
  assert.ok(server.includes(route), `admin boundary changed: ${route}`);
}

assert.ok(web.includes('data-roles="admin,printer,operator"'), 'operator printing menu missing');
assert.ok(web.includes('data-roles="admin,warehouse,operator"'), 'operator scanner menu missing');
assert.ok(web.includes('data-page="tearoff" data-roles="admin,customer_service,warehouse,operator"'), 'direct tear-off menu missing');
assert.ok(web.includes('function showTearOffPage()'), 'direct tear-off navigation action missing');
assert.ok(web.includes('data-page="returns"'), 'return receipt menu missing');
assert.ok(web.includes("selectScanMode('return')"), 'return receipt scan mode missing');
assert.ok(web.includes("['自动识别','圆通'"), 'automatic carrier option missing');
assert.ok(web.includes("['admin','printer','operator'].includes(me.role)"), 'operator tracking UI missing');
assert.ok(web.includes("['admin','customer_service','operator'].includes(me.role)"), 'operator case editor missing');
assert.ok(web.includes("me.role!=='admin'"), 'admin menu visibility boundary missing');
assert.ok(server.includes('if (days > 92)'), 'data center range limit missing');
assert.ok(server.includes('returnCarriers: returnCarriers.rows'), 'return carrier statistics missing');
assert.ok(server.includes('daily: daily.rows'), 'daily trend statistics missing');
assert.ok(server.includes('AS stat_date'), 'daily trend must avoid reserved day alias');
assert.ok(!server.includes('::date day'), 'reserved day alias reintroduced');
assert.ok(web.includes('id="shippingDateFrom"'), 'data center start date missing');
assert.ok(web.includes('id="dailyTrend"'), 'data center daily trend missing');
assert.ok(web.includes('id="shippingRecordRows"'), 'paginated data center scan details missing');
assert.ok(web.includes('function loadShippingRecords('), 'data center scan filtering missing');
assert.ok(web.includes('function confirmShippingCarrier('), 'pending carrier confirmation UI missing');
assert.ok(server.includes("app.get('/api/shipping-records'"), 'paginated shipping records API missing');
assert.ok(server.includes("app.get('/api/shipping-records/export.csv'"), 'shipping records export API missing');
assert.ok(web.includes('function exportShippingRecords('), 'shipping records export action missing');
assert.ok(web.includes('导出当前明细'), 'shipping records export button missing');
assert.ok(server.includes('where.push(`c.created_at >= $${params.length}::date`)'), 'case export date filter must qualify created_at');
assert.ok(server.includes("coalesce(c.resend_tracking_no,'')"), 'case export tracking filter must qualify case fields');
assert.ok(server.includes("error: '导出日期格式不正确'"), 'case export must reject invalid dates cleanly');
assert.ok(server.includes("app.patch('/api/shipping-records/:recordId/carrier'"), 'shipping carrier confirmation API missing');
assert.ok(server.includes("app.delete('/api/shipping-records/:recordId'"), 'invalid shipping scan deletion API missing');
assert.ok(server.includes("VALUES($1,$2,'volume',$3,$4)"), 'shipment volume must retain tracking number');
assert.ok(server.includes("WHERE scan_type='volume' AND created_at::date=current_date"), 'shipment total must exclude carton and return scans');
assert.ok(server.includes('carrier, trackingNo'), 'shipment scan response must return normalized tracking number');
assert.ok(!server.includes("VALUES($1,NULL,'volume'"), 'shipment volume still discards tracking number');
assert.ok(!server.includes("SET tracking_no=NULL WHERE scan_type='volume'"), 'startup migration still erases tracking numbers');
assert.ok(server.includes('automatic && !detected.matched && isLikelyRetailBarcode(trackingNo)'), 'automatic scans must reject likely retail barcodes');
assert.ok(server.includes('const carrier = automatic ? detected.carrier : requestedCarrier'), 'unrecognized automatic scans must be retained as pending confirmation');
assert.ok(server.includes("code: 'carrier_confirmation_required'"), 'PDA carrier confirmation response missing');
assert.ok(pdaWeb.includes('requireCarrierConfirmation:true'), 'PDA scans must require carrier confirmation before saving');
assert.ok(web.includes('function printingReason('), 'printing center reason cleanup missing');
assert.ok(web.includes('function copyReason('), 'printing center reason copy action missing');
assert.ok(web.includes('title="复制订单号"'), 'printing center order copy action missing');
assert.ok(web.includes('title="复制补发原因"'), 'printing center reason copy button missing');
assert.ok(web.includes('id="printingKeyword"'), 'printing center keyword filter missing');
assert.ok(web.includes('id="printingPlatform"'), 'printing center platform filter missing');
assert.ok(web.includes('id="printingDateFrom"'), 'printing center start date filter missing');
assert.ok(web.includes('id="printingDateTo"'), 'printing center end date filter missing');
assert.ok(web.includes('function resetPrintingFilters('), 'printing center filter reset missing');
assert.ok(adminWeb.includes('function saveCatalog(id)'), 'catalog edit action missing');
assert.ok(adminWeb.includes("document.getElementById('ce'+id).checked"), 'catalog enable/disable control missing');
assert.ok(server.includes('ALTER TABLE scan_registry ADD COLUMN IF NOT EXISTS scan_type'), 'legacy scan registry migration missing');
assert.ok(server.includes('ALTER TABLE return_receipts ADD COLUMN IF NOT EXISTS received_at'), 'legacy return receipt migration missing');
assert.ok(server.includes('CREATE TABLE IF NOT EXISTS interception_records'), 'interception record migration missing');
assert.ok(server.includes("app.get('/api/interceptions'"), 'interception list API missing');
assert.ok(server.includes("app.post('/api/interceptions'"), 'interception create API missing');
assert.ok(server.includes('const parseInterceptionText ='), 'interception natural-language parser missing');
assert.ok(server.includes("parsedText?.carrier || req.body.carrier || detected.carrier"), 'interception carrier auto detection missing');
assert.ok(
  server.includes("app.post('/api/integrations/feishu/interceptions', integrationAuth"),
  'Feishu interception command API missing'
);
assert.ok(server.includes("'飞书登记拦截件'"), 'Feishu interception audit missing');
assert.ok(server.includes('CREATE TABLE IF NOT EXISTS tear_off_tasks'), 'tear-off task migration missing');
assert.ok(server.includes("app.post('/api/tear-off-tasks'"), 'tear-off create API missing');
assert.ok(server.includes("app.patch('/api/tear-off-tasks/:id/warehouse'"), 'warehouse tear-off confirmation API missing');
assert.ok(server.includes("app.post('/api/integrations/feishu/tear-off-tasks'"), 'Feishu tear-off create API missing');
assert.ok(server.includes("roleOpenIds(['warehouse'])"), 'warehouse notification must use bound roles');
assert.ok(server.includes("roleOpenIds(['printer'])"), 'printer notification must use bound roles');
assert.ok(web.includes('id="exceptionTearPanel"'), 'tear-off workspace tab missing');
assert.ok(web.includes('function resolveTearOff('), 'warehouse tear-off action missing');
assert.ok(web.includes('仓库确认后才算完成撕单'), 'tear-off authority explanation missing');
assert.ok(server.includes("LEFT JOIN return_receipts r ON r.tracking_no=i.tracking_no"), 'interception return matching missing');
assert.ok(web.includes('id="page-interceptions"'), 'interception workspace page missing');
assert.ok(web.includes('id="interceptionText"'), 'interception natural-language input missing');
assert.ok(web.includes('function createInterceptionFromText('), 'interception natural-language submit action missing');
assert.ok(web.includes("const typeClass={补发:'resend',换货:'exchange',退件:'return'}"), 'case type color mapping missing');
assert.ok(server.includes('pg_advisory_xact_lock'), 'daily carton specification concurrency lock missing');
assert.ok(server.includes('await activateDailySpec(client, cartonSpec, req.user.id)'), 'daily carton specification merge missing');
assert.ok(server.includes('74、75 或 76'), 'Aneng 76-prefix validation message missing');
assert.ok(web.includes('id="customSpecButtons"'), 'custom carton specification shortcuts missing');
assert.ok(web.includes("localStorage.getItem('scanSpecDate')!==scannerToday"), 'scanner selection must reset on a new day');
assert.ok(web.includes("JSON.stringify({date:scannerToday,specs:customSpecs})"), 'custom carton specifications must be date scoped');
assert.ok(web.includes('replace(/[xX*＊✕✖]/g'), 'carton specification separators must be normalized');
assert.ok(web.includes('frameRate:{ideal:24,max:30}'), 'camera frame-rate limit missing');
assert.ok(web.includes('setTimeout(detectLoop,180)'), 'native barcode detector throttle missing');
assert.ok(web.includes("focusMode:'continuous'"), 'continuous camera focus optimization missing');
assert.ok(web.includes("request('/package-scans/daily-spec'"), 'daily carton specification activation missing');
assert.ok(!web.includes('onclick="newScanBatch()"'), 'legacy new batch action should be removed');
assert.ok(!web.includes('第一批'), 'legacy numbered carton batches should be removed');

assert.ok(pdaWeb.includes('new XMLHttpRequest()'), 'PDA page must use legacy-compatible XHR');
assert.ok(pdaWeb.includes("new ActiveXObject('Microsoft.XMLHTTP')"), 'PDA legacy XHR fallback missing');
assert.ok(pdaWeb.includes("location.host+'/api'+url"), 'PDA API origin routing missing');
assert.ok(pdaWeb.includes("setTimeout(function()"), 'PDA request timeout handling missing');
assert.ok(!pdaWeb.includes('fetch('), 'PDA page must not depend on Fetch API');
assert.ok(!pdaWeb.includes('async function'), 'PDA page must not require async functions');
assert.ok(pdaWeb.includes("event.keyCode===13"), 'PDA scanner Enter submission missing');
assert.ok(pdaWeb.includes("url='/shipment-volume/scan'"), 'PDA shipment counting endpoint missing');
assert.ok(pdaWeb.includes("url='/package-scans'"), 'PDA carton scanning endpoint missing');
assert.ok(pdaWeb.includes("url='/return-receipts'"), 'PDA return scanning endpoint missing');
assert.ok(pdaWeb.includes('modeCounts={volume:0,aneng:0,return:0}'), 'PDA mode counters must be isolated');
assert.ok(pdaWeb.includes('result.tracking_no||result.trackingNo||number'), 'PDA must display server-normalized tracking number');

console.log('Operator permissions tests passed');
