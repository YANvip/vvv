from bot_logic import (
    build_existing_case_card,
    build_parse_card,
    extract_interception_command,
    is_my_id_request,
)


def test_interception_commands():
    assert extract_interception_command("JT5515830658872 拦截") == {
        "trackingNo": "JT5515830658872", "command": "拦截"
    }
    assert extract_interception_command("退回 750100983882") == {
        "trackingNo": "750100983882", "command": "退回"
    }
    assert extract_interception_command("订单退回后补发一个7001") is None
    assert extract_interception_command("JT5515830658872 补发") is None


def test_my_id_commands():
    accepted = (
        "我的id",
        "我的 ID",
        "我的飞书ID",
        "获取ID",
        "查询 open_id",
        "查看用户ID？",
    )
    rejected = (
        "",
        "订单ID",
        "我的订单",
        "查询260708-560380003972903",
    )

    for value in accepted:
        assert is_my_id_request(value), value
    for value in rejected:
        assert not is_my_id_request(value), value


def test_existing_case_card_is_not_labeled_as_query():
    card = build_existing_case_card({
        "found": True,
        "orderNo": "6954683200173249559",
        "case": {
            "orderNo": "6954683200173249559",
            "status": "pending",
            "platform": "douyin",
            "items": [{"model": "7001", "color": "大象灰", "quantity": 2}],
        },
    })
    assert card["header"]["title"]["content"] == "该订单已有售后工单"
    assert "未重复创建" in card["elements"][0]["text"]["content"]


def test_parse_card_contains_recoverable_action_context():
    text = "260725-684321687053207补发 50cm蛋卷桌桌面原木色一个"
    card = build_parse_card({
        "orderNo": "260725-684321687053207",
        "type": "补发",
        "platform": "拼多多",
        "items": [{"model": "50cm蛋卷桌桌面原木色", "quantity": 1}],
    }, text)
    actions = card["elements"][3]["actions"]
    assert actions[0]["value"]["text"] == text
    assert actions[0]["value"]["order_no"] == "260725-684321687053207"
    assert actions[1]["value"]["text"] == text


if __name__ == "__main__":
    test_interception_commands()
    test_my_id_commands()
    test_existing_case_card_is_not_labeled_as_query()
    test_parse_card_contains_recoverable_action_context()
    print("Feishu identity command tests passed")
