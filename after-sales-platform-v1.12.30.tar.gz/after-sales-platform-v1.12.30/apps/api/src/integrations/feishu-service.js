const FEISHU_API = 'https://open.feishu.cn/open-apis';
const crypto = require('crypto');

const splitIds = (value) => String(value || '')
  .split(',')
  .map((item) => item.trim())
  .filter(Boolean);

function createFeishuService(env = process.env, fetchImpl = global.fetch) {
  const appId = String(env.FEISHU_APP_ID || '').trim();
  const appSecret = String(env.FEISHU_APP_SECRET || '').trim();
  let cachedToken = '';
  let expiresAt = 0;
  let cachedJsapiTicket = '';
  let jsapiTicketExpiresAt = 0;

  const enabled = () => Boolean(appId && appSecret);

  const token = async () => {
    if (!enabled()) throw new Error('飞书应用配置不完整');
    if (cachedToken && Date.now() < expiresAt) return cachedToken;
    const response = await fetchImpl(`${FEISHU_API}/auth/v3/tenant_access_token/internal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ app_id: appId, app_secret: appSecret }),
    });
    const data = await response.json();
    if (!response.ok || data.code) throw new Error(data.msg || '获取飞书访问令牌失败');
    cachedToken = data.tenant_access_token;
    expiresAt = Date.now() + Math.max(60, Number(data.expire || 7200) - 120) * 1000;
    return cachedToken;
  };

  const request = async (path, options = {}) => {
    const accessToken = await token();
    const response = await fetchImpl(`${FEISHU_API}${path}`, {
      ...options,
      headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json', ...(options.headers || {}) },
    });
    const data = await response.json();
    if (!response.ok || data.code) throw new Error(data.msg || `飞书接口失败：${response.status}`);
    return data.data || {};
  };

  const sendText = async (openIds, text) => {
    const receivers = [...new Set(openIds)].filter(Boolean);
    const results = await Promise.allSettled(
      receivers.map((openId) => request('/im/v1/messages?receive_id_type=open_id', {
      method: 'POST',
      body: JSON.stringify({ receive_id: openId, msg_type: 'text', content: JSON.stringify({ text }) }),
      }))
    );
    const failureDetails = results.flatMap((item, index) => (
      item.status === 'rejected'
        ? [{ openId: receivers[index], error: item.reason?.message || String(item.reason) }]
        : []
    ));
    const failures = failureDetails;
    if (receivers.length && failures.length === receivers.length) {
      throw new Error(`飞书消息全部发送失败：${failures[0].error}`);
    }
    return {
      sent: receivers.length - failures.length,
      failed: failures.length,
      failedOpenIds: failureDetails.map((item) => item.openId),
      failureDetails,
    };
  };

  const sendCard = async (openIds, card) => {
    const receivers = [...new Set(openIds)].filter(Boolean);
    const cardJson = typeof card === 'string' ? card : JSON.stringify(card);
    const results = await Promise.allSettled(
      receivers.map((openId) => request('/im/v1/messages?receive_id_type=open_id', {
        method: 'POST',
        body: JSON.stringify({ receive_id: openId, msg_type: 'interactive', content: cardJson }),
      }))
    );
    const failureDetails = results.flatMap((item, index) => (
      item.status === 'rejected'
        ? [{ openId: receivers[index], error: item.reason?.message || String(item.reason) }]
        : []
    ));
    const failures = failureDetails;
    if (receivers.length && failures.length === receivers.length) {
      throw new Error(`飞书卡片全部发送失败：${failures[0].reason?.message || failures[0].reason}`);
    }
    const messageIds = results.map((item, i) => (
      item.status === 'fulfilled' ? item.value?.message_id : null
    )).filter(Boolean);
    return {
      sent: receivers.length - failures.length,
      failed: failures.length,
      failedOpenIds: failureDetails.map((item) => item.openId),
      failureDetails,
      messageIds,
    };
  };

  const updateCard = async (messageId, card) => {
    const cardJson = typeof card === 'string' ? card : JSON.stringify(card);
    return request(`/im/v1/messages/${encodeURIComponent(messageId)}`, {
      method: 'PATCH',
      body: JSON.stringify({ content: cardJson }),
    });
  };

  const exchangeUserCode = async (code) => {
    if (!enabled()) throw new Error('飞书应用配置不完整');
    const tokenResponse = await fetchImpl(`${FEISHU_API}/authen/v2/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        grant_type: 'authorization_code',
        client_id: appId,
        client_secret: appSecret,
        code,
      }),
    });
    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok || tokenData.code || !tokenData.access_token) {
      throw new Error(tokenData.error_description || tokenData.msg || '飞书免登录授权失败');
    }
    const userResponse = await fetchImpl(`${FEISHU_API}/authen/v1/user_info`, {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const userData = await userResponse.json();
    if (!userResponse.ok || userData.code) {
      throw new Error(userData.msg || '获取飞书用户信息失败');
    }
    return userData.data || userData;
  };

  const jsapiSignature = async (url) => {
    if (!enabled()) throw new Error('飞书应用配置不完整');
    if (!cachedJsapiTicket || Date.now() >= jsapiTicketExpiresAt) {
      const data = await request('/jssdk/ticket/get', { method: 'POST', body: '{}' });
      cachedJsapiTicket = data.ticket;
      if (!cachedJsapiTicket) throw new Error('获取飞书 JSAPI ticket 失败');
      jsapiTicketExpiresAt = Date.now() + Math.max(60, Number(data.expire_in || 7200) - 120) * 1000;
    }
    const timestamp = Date.now();
    const nonceStr = crypto.randomBytes(16).toString('hex');
    const source = `jsapi_ticket=${cachedJsapiTicket}&noncestr=${nonceStr}&timestamp=${timestamp}&url=${url}`;
    const signature = crypto.createHash('sha1').update(source).digest('hex');
    return { appId, timestamp, nonceStr, signature };
  };

  const paginate = async (path, itemKey = 'items', pageSize = 100) => {
    const items = [];
    let pageToken = '';
    do {
      const joiner = path.includes('?') ? '&' : '?';
      const data = await request(`${path}${joiner}page_size=${pageSize}${pageToken ? `&page_token=${encodeURIComponent(pageToken)}` : ''}`);
      items.push(...(data[itemKey] || []));
      pageToken = data.has_more ? String(data.page_token || '') : '';
    } while (pageToken);
    return items;
  };

  const listDirectoryUsers = async () => {
    const scopeUserIds = new Set();
    const scopeDepartmentIds = new Set();
    let scopePageToken = '';
    do {
      const data = await request(`/contact/v3/scopes?user_id_type=open_id&department_id_type=open_department_id&page_size=100${scopePageToken ? `&page_token=${encodeURIComponent(scopePageToken)}` : ''}`);
      for (const id of data.user_ids || []) scopeUserIds.add(id);
      for (const id of data.department_ids || []) scopeDepartmentIds.add(id);
      scopePageToken = data.has_more ? String(data.page_token || '') : '';
    } while (scopePageToken);

    const users = new Map();
    const visitedDepartments = new Set();
    const addUser = (item) => {
      const openId = String(item.open_id || item.user_id || '').trim();
      if (!openId || item.status?.is_resigned) return;
      users.set(openId, {
        openId,
        name: String(item.name || item.en_name || openId),
        avatarUrl: item.avatar?.avatar_72 || item.avatar?.avatar_240 || item.avatar?.avatar_origin || '',
        departmentIds: item.department_ids || [],
        active: item.status?.is_activated !== false,
      });
    };

    const loadDepartment = async (departmentId) => {
      if (!departmentId || visitedDepartments.has(departmentId)) return;
      visitedDepartments.add(departmentId);
      const query = `department_id=${encodeURIComponent(departmentId)}&department_id_type=open_department_id&user_id_type=open_id`;
      const directUsers = await paginate(`/contact/v3/users/find_by_department?${query}`);
      directUsers.forEach(addUser);
      const children = await paginate(`/contact/v3/departments/${encodeURIComponent(departmentId)}/children?department_id_type=open_department_id&user_id_type=open_id`);
      for (const child of children) await loadDepartment(child.open_department_id || child.department_id);
    };

    for (const id of scopeUserIds) {
      try {
        const data = await request(`/contact/v3/users/${encodeURIComponent(id)}?user_id_type=open_id&department_id_type=open_department_id`);
        addUser(data.user || data);
      } catch (_) {
        // A stale scope entry should not block the rest of the directory.
      }
    }
    for (const id of scopeDepartmentIds) await loadDepartment(id);
    return [...users.values()].sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'));
  };

  const parseBitableReference = (value) => {
    const raw = String(value || '').trim();
    const tokenMatch = raw.match(/\/base\/([A-Za-z0-9_-]+)/) || raw.match(/^([A-Za-z0-9_-]{12,})$/);
    if (!tokenMatch) throw new Error('请输入正确的飞书多维表格链接');
    const tableMatch = raw.match(/[?&]table=(tbl[A-Za-z0-9_-]+)/);
    return { appToken: tokenMatch[1], tableId: tableMatch?.[1] || '' };
  };

  const listBitableRecords = async (appToken, tableId) => paginate(
    `/bitable/v1/apps/${encodeURIComponent(appToken)}/tables/${encodeURIComponent(tableId)}/records?user_id_type=open_id`,
    'items',
    500
  );

  const bitableText = (value) => {
    if (Array.isArray(value)) return value.map((item) => item?.text || item?.name || item || '').join('');
    if (value && typeof value === 'object') return String(value.text || value.name || value.value || '');
    return String(value ?? '');
  };

  const csvItems = (value) => bitableText(value)
    .split(/[，,]/)
    .map((item) => item.trim())
    .filter(Boolean);

  const mergeCsv = (...values) => [...new Set(values.flatMap(csvItems))].join(',');

  const seedFields = (item) => ({
    '商品型号': String(item.model || '').trim(),
    '商品类型': String(item.product_type || item.productType || '').trim(),
    '识别别名': mergeCsv(item.aliases || item.model),
    '可选颜色': mergeCsv(item.colors || ''),
    '必须识别颜色': Boolean(item.color_required ?? item.colorRequired),
    '启用': item.active !== false,
  });

  const ensureProductKnowledgeBase = async (reference, seedRecords = [], options = {}) => {
    const authoritativeModels = new Set(
      (options.authoritativeModels || []).map((model) => String(model).trim().toLowerCase())
    );
    const parsed = parseBitableReference(reference);
    const requiredFields = [
      { field_name: '商品型号', type: 1 },
      { field_name: '商品类型', type: 1 },
      { field_name: '识别别名', type: 1 },
      { field_name: '可选颜色', type: 1 },
      { field_name: '必须识别颜色', type: 7 },
      { field_name: '启用', type: 7 },
    ];
    const tables = await paginate(`/bitable/v1/apps/${encodeURIComponent(parsed.appToken)}/tables`);
    let table = parsed.tableId
      ? tables.find((item) => item.table_id === parsed.tableId)
      : tables.find((item) => item.name === '商品知识库');
    if (parsed.tableId && !table) throw new Error('链接中的数据表不存在，或机器人没有访问权限');
    if (!table) {
      const created = await request(`/bitable/v1/apps/${encodeURIComponent(parsed.appToken)}/tables`, {
        method: 'POST',
        body: JSON.stringify({
          table: {
            name: '商品知识库',
            default_view_name: '全部商品',
            fields: requiredFields,
          },
        }),
      });
      table = created.table || created;
    }
    const fields = await paginate(`/bitable/v1/apps/${encodeURIComponent(parsed.appToken)}/tables/${encodeURIComponent(table.table_id)}/fields`);
    const fieldNames = new Set(fields.map((item) => item.field_name));
    for (const field of requiredFields) {
      if (fieldNames.has(field.field_name)) continue;
      await request(`/bitable/v1/apps/${encodeURIComponent(parsed.appToken)}/tables/${encodeURIComponent(table.table_id)}/fields`, {
        method: 'POST',
        body: JSON.stringify(field),
      });
    }
    let records = await listBitableRecords(parsed.appToken, table.table_id);
    const byModel = new Map(records.map((record) => [
      bitableText(record.fields?.['商品型号']).trim().toLowerCase(),
      record,
    ]).filter(([model]) => model));
    const creates = [];
    const updates = [];
    for (const seed of seedRecords.map(seedFields).filter((item) => item['商品型号'])) {
      const existing = byModel.get(seed['商品型号'].toLowerCase());
      if (!existing) {
        creates.push({ fields: seed });
        continue;
      }
      const current = existing.fields || {};
      const fieldsToSave = {
        '商品型号': bitableText(current['商品型号']).trim() || seed['商品型号'],
        '商品类型': bitableText(current['商品类型']).trim() || seed['商品类型'],
        '识别别名': mergeCsv(current['识别别名'], seed['识别别名'], seed['商品型号']),
        '可选颜色': authoritativeModels.has(seed['商品型号'].toLowerCase())
          ? seed['可选颜色']
          : mergeCsv(current['可选颜色'], seed['可选颜色']),
        '必须识别颜色': Boolean(current['必须识别颜色']) || seed['必须识别颜色'],
        '启用': current['启用'] === undefined ? seed['启用'] : Boolean(current['启用']),
      };
      const changed = Object.entries(fieldsToSave).some(([name, value]) => {
        const oldValue = typeof value === 'boolean' ? Boolean(current[name]) : bitableText(current[name]).trim();
        return oldValue !== value;
      });
      if (changed) updates.push({ record_id: existing.record_id, fields: fieldsToSave });
    }
    for (let index = 0; index < creates.length; index += 500) {
        await request(`/bitable/v1/apps/${encodeURIComponent(parsed.appToken)}/tables/${encodeURIComponent(table.table_id)}/records/batch_create`, {
          method: 'POST',
          body: JSON.stringify({ records: creates.slice(index, index + 500) }),
        });
    }
    for (let index = 0; index < updates.length; index += 500) {
      await request(`/bitable/v1/apps/${encodeURIComponent(parsed.appToken)}/tables/${encodeURIComponent(table.table_id)}/records/batch_update`, {
        method: 'POST',
        body: JSON.stringify({ records: updates.slice(index, index + 500) }),
      });
    }
    if (creates.length || updates.length) {
      records = await listBitableRecords(parsed.appToken, table.table_id);
    }
    return {
      appToken: parsed.appToken,
      tableId: table.table_id,
      tableName: table.name || '商品知识库',
      records,
      created: creates.length,
      updated: updates.length,
    };
  };

  return {
    enabled,
    appId,
    printerIds: splitIds(env.FEISHU_PRINTER_OPEN_IDS),
    customerServiceIds: splitIds(env.FEISHU_CUSTOMER_SERVICE_OPEN_IDS),
    operatorIds: splitIds(env.FEISHU_OPERATOR_OPEN_IDS),
    sendText,
    sendCard,
    updateCard,
    exchangeUserCode,
    jsapiSignature,
    listDirectoryUsers,
    ensureProductKnowledgeBase,
  };
}

module.exports = { createFeishuService, splitIds };
