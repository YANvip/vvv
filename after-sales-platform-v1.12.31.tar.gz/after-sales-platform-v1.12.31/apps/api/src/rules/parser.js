const { catalog: defaultCatalog } = require('./catalog');

const chineseNumbers = { 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 };
const accessoryNames = ['脚垫', '防滑垫', '凳脚垫', '凳面', '凳子面', '座框', '螺丝钉', '螺丝', '杆子', '桌面'];
const modelColorAliases = {
  '6600': {
    西瓜红: '红色', 天空蓝: '蓝色', 抹茶绿: '绿色', 火焰橙: '橙色',
    高级灰: '灰色', 青象灰: '灰色', 淡雅灰: '灰色',
  },
  '033': {
    浅蓝色: '蓝色', 浅蓝: '蓝色', 抹茶绿: '绿色',
    浅啡色: '啡色', 深啡色: '啡色', 咖啡色: '啡色', 咖色: '啡色',
    旋风橙黄色: '橙色', 橙黄色: '橙色',
  },
};

function detectOrderNo(text) {
  const compact = text.replace(/\s+/g, '');
  const pdd = compact.match(/\d{5,8}-\d{10,24}/);
  if (pdd) return { orderNo: pdd[0], platform: '拼多多' };
  const douyin = compact.match(/(?<!\d)\d{16,22}(?!\d)/);
  if (douyin) return { orderNo: douyin[0], platform: '抖店' };
  const taobao = compact.match(/(?<!\d)\d{12,15}(?!\d)/);
  if (taobao) return { orderNo: taobao[0], platform: '淘宝/天猫' };
  return { orderNo: '', platform: '未知平台' };
}

function detectExplicitType(text) {
  if (/换货|换新|更换|(^|[^补])换\s*\d/.test(text)) return '换货';
  if (/退件|退回|退货/.test(text)) return '退件';
  if (/补发|少发|漏发|发错|破损|缺少|补(?:一个|两个|\d)/.test(text)) return '补发';
  return '';
}

function detectType(text) {
  return detectExplicitType(text) || '补发';
}

function numberValue(value) {
  if (/^\d+$/.test(value)) return Number(value);
  return chineseNumbers[value] || 1;
}

function detectQuantity(text) {
  const matches = [...text.matchAll(/(\d{1,3}|[一二两三四五六七八九十])\s*(?:个|件|只|套|张|把|吧|根)/g)];
  if (!matches.length) return 1;
  const match = matches.find((item) => !/^\d{4}$/.test(item[1])) || matches[0];
  return Math.max(1, Math.min(999, numberValue(match[1])));
}

function normalizeInput(value) {
  return String(value || '')
    .replace(/[＋➕]/g, '+')
    .replace(/da['’]?xiang['’]?(?:huo|hui)/gi, '大象灰')
    .replace(/橙黄(?!色)/g, '橙黄色')
    .replace(/青象灰/g, '青象灰');
}

function normalizeColor(color) {
  return ({ 灰: '灰色', 高灰: '高级灰', 蓝: '蓝色', 绿: '绿色', 红: '红色', 军绿: '军绿色', 卡其: '卡其色', 橙: '橙色' })[color] || color || '';
}

function colorCandidates(item) {
  const direct = (item?.colors || []).map((color) => [color, color]);
  const aliases = Object.entries(modelColorAliases[item?.model] || {});
  return [...direct, ...aliases].sort((a, b) => b[0].length - a[0].length);
}

function canonicalColor(item, color) {
  const mapped = colorCandidates(item).find(([alias]) => alias === color)?.[1];
  return mapped || normalizeColor(color);
}

function normalizedCatalog(catalog) {
  return catalog.map((item) => ({
    ...item,
    aliases: Array.isArray(item.aliases) ? item.aliases : String(item.aliases || '').split(',').filter(Boolean),
    colors: Array.isArray(item.colors) ? item.colors : String(item.colors || '').split(',').filter(Boolean),
  }));
}

function findCatalogItem(text, catalog) {
  const compact = text.replace(/\s+/g, '');
  return catalog
    .map((item) => ({
      item,
      matchLength: Math.max(0, ...item.aliases
        .map((alias) => alias.replace(/\s+/g, ''))
        .filter((alias) => alias && compact.includes(alias))
        .map((alias) => alias.length)),
    }))
    .filter((candidate) => candidate.matchLength > 0)
    .sort((a, b) => b.matchLength - a.matchLength)[0]?.item;
}

function findBaseModel(text) {
  const compact = text.replace(/\s+/g, '');
  if (/6600/.test(compact)) return '6600';
  if (/7001/.test(compact)) return '7001';
  if (/7002/.test(compact)) return '7002';
  if (/210|蛋白皮|蛋壳椅/.test(compact)) return '210';
  if (/033|33旋风|旋风凳/.test(compact)) return '033';
  return '';
}

function accessoryModel(baseModel, text) {
  if (/脚垫|防滑垫|凳脚垫/.test(text)) return baseModel ? `${baseModel}脚垫` : '';
  if (/凳面|凳子面/.test(text)) return baseModel ? `${baseModel}凳面` : '';
  if (/座框/.test(text)) return baseModel === '210' ? '210座框' : '';
  if (/螺丝/.test(text)) return baseModel === '210' ? '210螺丝' : '';
  return '';
}

function findColor(text, item) {
  if (!item?.colorRequired) return '';
  const exact = colorCandidates(item).find(([alias]) => text.includes(alias));
  if (exact) return exact[1];
  const short = text.match(/(?:型号|\d|软包|旋风)?\s*(灰|蓝|绿|红|卡其|橙)(?=\s*(?:\d|[一二两三四五六七八九十])?\s*(?:个|把|吧|$))/);
  return canonicalColor(item, short?.[1]);
}

function makeItem(model, quantity, color, catalog) {
  const entry = catalog.find((item) => item.model === model);
  return {
    model,
    productName: model,
    productType: entry?.productType || '其他',
    quantity: Math.max(1, Math.min(999, Number(quantity) || 1)),
    color: entry?.colorRequired ? canonicalColor(entry, color) : '',
    colorRequired: Boolean(entry?.colorRequired),
  };
}

function makeFreeTextItem(segment) {
  const originalText = String(segment || '').trim().replace(/^[，,；;+\s]+|[，,；;+\s]+$/g, '');
  if (!originalText) return null;
  return {
    model: originalText,
    productName: originalText,
    productType: '客服原话',
    quantity: detectQuantity(originalText),
    color: '',
    colorRequired: false,
    catalogMatched: false,
  };
}

function colorQuantityItems(segment, entry, catalog) {
  if (!entry?.colorRequired) return [];
  const aliases = [...new Set([...colorCandidates(entry).map(([alias]) => alias), '灰', '蓝', '绿', '红', '卡其', '橙'])]
    .sort((a, b) => b.length - a.length)
    .map((value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const colorPattern = aliases.join('|');
  const matches = [...segment.matchAll(new RegExp(`(${colorPattern})\\s*(\\d{1,3}|[一二两三四五六七八九十])\\s*(?:个|把|吧|件|只)`, 'g'))];
  if (matches.length < 2) return [];
  return matches.map((match) => makeItem(entry.model, numberValue(match[2]), match[1], catalog));
}

function parseItemSegment(segment, catalog, inheritedBase) {
  const baseModel = findBaseModel(segment) || inheritedBase;
  const accessory = accessoryModel(baseModel, segment);
  const hasUncataloguedAccessory = accessoryNames.some((name) => segment.includes(name))
    && (!accessory || !catalog.some((item) => item.model === accessory));
  if (hasUncataloguedAccessory) {
    const freeTextItem = makeFreeTextItem(segment);
    return { items: freeTextItem ? [freeTextItem] : [], baseModel };
  }
  let entry = accessory ? catalog.find((item) => item.model === accessory) : findCatalogItem(segment, catalog);
  if (!entry && baseModel) {
    const fullModel = baseModel === '210' ? '210蛋白皮' : baseModel;
    entry = catalog.find((item) => item.model === fullModel);
  }
  if (!entry) {
    const freeTextItem = makeFreeTextItem(segment);
    return { items: freeTextItem ? [freeTextItem] : [], baseModel };
  }
  const variants = colorQuantityItems(segment, entry, catalog);
  return {
    items: variants.length ? variants : [makeItem(entry.model, detectQuantity(segment), findColor(segment, entry), catalog)],
    baseModel: findBaseModel(segment) || inheritedBase,
  };
}

function splitSegments(text) {
  return text
    .replace(/共\s*(?:\d{1,3}|[一二两三四五六七八九十])\s*(?:个|把|吧|件|只|套)/g, '')
    .split(/\s*(?:[+，,；;]|以及|并且|和(?=\s*(?:\d|[一二两三四五六七八九十])))\s*/)
    .map((part) => part.trim())
    .filter(Boolean);
}

function parseItems(text, catalog) {
  const segments = splitSegments(text);
  const items = [];
  let inheritedBase = '';
  for (const segment of segments) {
    const parsed = parseItemSegment(segment, catalog, inheritedBase);
    inheritedBase = parsed.baseModel || inheritedBase;
    items.push(...parsed.items);
  }
  return items;
}

function parseAfterSalesText(input, customCatalog = defaultCatalog) {
  const rawText = String(input || '').trim();
  const normalized = normalizeInput(rawText);
  const order = detectOrderNo(normalized);
  const businessText = order.orderNo ? normalized.replace(order.orderNo, ' ') : normalized;
  const catalog = normalizedCatalog(customCatalog);
  const items = parseItems(businessText, catalog);
  const first = items[0] || { model: '', productName: '', productType: '', quantity: detectQuantity(businessText), color: '', colorRequired: false };
  const result = { rawText, ...order, type: detectType(businessText), ...first, items };
  const warnings = [];
  if (!result.orderNo) warnings.push('未识别订单号');
  if (result.platform === '未知平台') warnings.push('未识别平台');
  if (!items.length) warnings.push(accessoryNames.some((name) => businessText.includes(name)) ? '配件缺少商品型号' : '未填写商品内容');
  items.forEach((item, index) => {
    if (item.colorRequired && !item.color) warnings.push(`第${index + 1}项“${item.model}”需要确认颜色`);
    if (item.color === '灰色') warnings.push(`第${index + 1}项“灰色”可能对应多个色号，请人工确认`);
  });
  const quantityText = businessText.replace(/共\s*(?:\d{1,3}|[一二两三四五六七八九十])\s*(?:个|把|吧|件|只|套)/g, '');
  const quantityMentions = [...quantityText.matchAll(/(?:\d{1,3}|[一二两三四五六七八九十])\s*(?:个|件|只|套|张|把|吧|根)/g)].length;
  if (quantityMentions > items.length) warnings.push('检测到多个商品数量，但部分商品未能拆分，请人工确认');
  return { ...result, needReview: warnings.length > 0, warnings };
}

module.exports = { parseAfterSalesText, detectExplicitType };
