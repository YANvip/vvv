const assert = require('assert');
const { catalog } = require('./catalog');

const expectedColors = {
  '033': ['白色', '卡其色', '绿色', '蓝色', '黑色', '红色', '啡色', '粉色', '橙色', '灰色'],
  '6600': ['红色', '蓝色', '绿色', '橙色', '灰色'],
  '7001': ['冰河灰', '大象灰', '雨林绿'],
  '033软包': ['白色', '黑色', '灰色', '卡其色', '红色', '浅蓝色', '咖啡色', '橙色'],
};

for (const [model, colors] of Object.entries(expectedColors)) {
  const item = catalog.find((record) => record.model === model);
  assert.ok(item, `missing catalog item: ${model}`);
  assert.deepStrictEqual(item.colors, colors, `incorrect colors for ${model}`);
  assert.strictEqual(item.authoritativeColors, true, `${model} colors must be authoritative`);
}

console.log('Catalog color rules passed');
