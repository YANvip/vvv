// Normalized from 店铺规格导出103015226272.xlsx.
// Packaging suffixes such as "*8" are intentionally excluded: after-sales
// quantity must always come from the current customer-service message.
const erpCatalog = [
  {
    model: '6600',
    aliases: ['6600', '套凳6600', '6600套凳'],
    productType: '塑料凳',
    colors: ['红色', '蓝色', '绿色', '橙色', '灰色'],
    colorRequired: true,
    authoritativeColors: true,
  },
  { model: '7001', aliases: ['7001'], productType: '塑料凳', colors: ['冰河灰', '大象灰', '雨林绿'], colorRequired: true, authoritativeColors: true },
  { model: '033', aliases: ['033', '33旋风', '033旋风'], productType: '塑料凳', colors: ['白色', '卡其色', '绿色', '蓝色', '黑色', '红色', '啡色', '粉色', '橙色', '灰色'], colorRequired: true, authoritativeColors: true },
  { model: '033软包', aliases: ['033软包', '033 软包'], productType: '软包凳', colors: ['白色', '黑色', '灰色', '卡其色', '红色', '浅蓝色', '咖啡色', '橙色'], colorRequired: true, authoritativeColors: true },
  { model: '210蛋白皮', aliases: ['210蛋白皮', '210 蛋白皮', '210'], productType: '软包凳', colors: ['卡其色', '橙色', '混色', '灰色', '白色', '红色', '绿色', '黑色'], colorRequired: true },
  { model: '小马扎', aliases: ['小马扎', '小号马扎', '小马扎黑'], productType: '折叠凳', colors: ['军绿', '果绿', '红色', '蓝色', '黑色'], colorRequired: true },
  { model: '中马扎', aliases: ['中马扎', '中号马扎', '中马扎黑'], productType: '折叠凳', colors: ['军绿', '果绿', '红色', '蓝色', '黑色'], colorRequired: true },
  { model: '大马扎', aliases: ['大马扎', '大号马扎', '大马扎黑', '大马扎大'], productType: '折叠凳', colors: ['军绿', '果绿', '红色', '蓝色', '黑色'], colorRequired: true },
  { model: '50蛋卷桌', aliases: ['50蛋卷桌', '50cm蛋卷桌', '蛋卷桌50cm'], productType: '蛋卷桌', colors: ['原木色', '黄色', '黑色'], colorRequired: true },
  { model: '95蛋卷桌', aliases: ['95蛋卷桌', '95cm蛋卷桌', '蛋卷桌95cm'], productType: '蛋卷桌', colors: ['原木色', '黄色', '黑色'], colorRequired: true },
  { model: '120蛋卷桌', aliases: ['120蛋卷桌', '120cm蛋卷桌', '蛋卷桌120cm'], productType: '蛋卷桌', colors: ['原木色', '黄色', '黑色'], colorRequired: true },
  { model: '50蛋卷桌+2把月亮椅', aliases: ['50蛋卷桌+2把月亮椅', '50蛋卷桌两椅', '50桌2椅'], productType: '桌椅组合', colors: ['卡其色', '黑色'], colorRequired: true },
  { model: '95蛋卷桌+2把月亮椅', aliases: ['95蛋卷桌+2把月亮椅', '95蛋卷桌两椅', '95桌2椅'], productType: '桌椅组合', colors: ['卡其色', '黑色'], colorRequired: true },
  { model: '95蛋卷桌+4把月亮椅', aliases: ['95蛋卷桌+4把月亮椅', '95蛋卷桌四椅', '95桌4椅'], productType: '桌椅组合', colors: ['卡其色', '黑色'], colorRequired: true },
  { model: '95蛋卷桌+6把月亮椅', aliases: ['95蛋卷桌+6把月亮椅', '95蛋卷桌六椅', '95桌6椅'], productType: '桌椅组合', colors: ['黑色'], colorRequired: true },
  { model: '120蛋卷桌+2把月亮椅', aliases: ['120蛋卷桌+2把月亮椅', '120蛋卷桌两椅', '120桌2椅'], productType: '桌椅组合', colors: ['卡其色', '黑色'], colorRequired: true },
  { model: '120蛋卷桌+4把月亮椅', aliases: ['120蛋卷桌+4把月亮椅', '120蛋卷桌四椅', '120桌4椅'], productType: '桌椅组合', colors: ['黑色'], colorRequired: true },
  { model: '120蛋卷桌+6把月亮椅', aliases: ['120蛋卷桌+6把月亮椅', '120蛋卷桌六椅', '120桌6椅'], productType: '桌椅组合', colors: ['卡其色', '黑色'], colorRequired: true },
  { model: 'B49', aliases: ['B49', 'b49'], productType: '椅子', colors: [], colorRequired: false },
  { model: 'B49条纹', aliases: ['B49条纹', 'b49条纹'], productType: '椅子', colors: ['红条', '黑条'], colorRequired: true },
  { model: 'B49雪呢绒', aliases: ['B49雪呢绒', 'b49雪呢绒'], productType: '椅子', colors: ['全黑', '黑米', '黑绿', '黑黄'], colorRequired: true },
  { model: 'B49小花树枝', aliases: ['B49小花树枝', 'b49小花树枝'], productType: '椅子', colors: ['小花', '树枝'], colorRequired: true },
  { model: 'ZM8002', aliases: ['ZM8002', 'zm8002'], productType: '凳子', colors: ['白色', '红色', '黑色'], colorRequired: true },
  { model: '9058', aliases: ['9058'], productType: '凳子', colors: ['白色', '粉色', '红色', '绿色', '蓝色', '黑色'], colorRequired: true },
  { model: '5Y-83', aliases: ['5Y-83', 'Y-83', 'Y83'], productType: '椅子', colors: ['白大象'], colorRequired: true },
];

module.exports = { erpCatalog };
