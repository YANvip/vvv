import json
import re
import urllib.error
import urllib.request


ALLOWED_INTENTS = {
    "query",
    "create",
    "scanner",
    "interception",
    "tear_off",
    "help",
    "unknown",
}


def _json_object(text):
    value = str(text or "").strip()
    value = re.sub(r"^```(?:json)?\s*", "", value, flags=re.IGNORECASE)
    value = re.sub(r"\s*```$", "", value)
    start = value.find("{")
    end = value.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("AI 没有返回 JSON")
    return json.loads(value[start:end + 1])


def interpret_with_bailian(
    text,
    context,
    api_key,
    base_url,
    model,
    timeout=12,
    opener=None,
):
    """Use Bailian to understand intent. Business validation stays in the API."""
    if not api_key or not base_url or not model:
        return None

    previous_order = str((context or {}).get("last_order_no") or "")
    previous_text = str((context or {}).get("last_text") or "")[:300]
    system_prompt = (
        "你是网店售后机器人的意图路由器，只输出一个 JSON 对象，不解释。"
        "你不能编造订单号、快递单号、商品或执行结果。"
        "intent 只能是 query/create/scanner/interception/tear_off/help/unknown。"
        "query 表示查询已有售后工单，包括询问是否补发、什么时候补发、补发到哪里、"
        "当前状态、快递单号、商品或处理详情；即使消息中出现‘补发’或‘换货’，"
        "只要是在询问已有记录，也必须判断为 query。"
        "create 只表示用户明确要求新建或登记一笔补发、换货等售后任务，"
        "通常同时包含商品和数量，不能把询问句判断为 create。"
        "scanner 表示打开仓库扫码；interception 表示登记快递拦截或退回；"
        "tear_off 表示退款撕单；help 表示询问使用方法。"
        "若用户说‘刚才那单/上一单’，可使用上下文订单号。"
        "create 的 resolved_text 必须是包含完整订单号的原话；无法补全则留空。"
        "query_focus 只能是 time/status/tracking/detail/general；"
        "询问‘什么时候/几点/日期’用 time，询问进度或是否完成用 status，"
        "询问快递单号用 tracking，询问商品或处理内容用 detail，其余用 general。"
        "示例：‘260808-214203112991120这个订单是什么时候补发的’"
        "应返回 query 和 time；"
        "‘260808-214203112991120补发2把7001大象灰’应返回 create；"
        "‘260808-214203112991120补发到哪里了’应返回 query 和 status；"
        "‘260808-214203112991120补发单号是什么’应返回 query 和 tracking。"
        "不要把‘取消刚才的已建工单’当成自动取消，只返回 unknown 并提示到网站处理。"
        "输出字段："
        '{"intent":"unknown","query_focus":"general","order_no":"","resolved_text":"",'
        '"tracking_no":"","command":"","product_info":"","reply":""}'
    )
    user_prompt = (
        f"上下文订单号：{previous_order or '无'}\n"
        f"上一句话：{previous_text or '无'}\n"
        f"当前用户消息：{str(text or '')[:600]}"
    )
    body = {
        "model": model,
        "temperature": 0,
        "max_tokens": 260,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    }
    request = urllib.request.Request(
        f"{base_url.rstrip('/')}/chat/completions",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    open_request = opener or urllib.request.urlopen
    try:
        with open_request(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:500]
        raise RuntimeError(f"阿里云 AI HTTP {exc.code}: {detail}") from exc

    content = (((payload.get("choices") or [{}])[0].get("message") or {}).get("content"))
    result = _json_object(content)
    intent = str(result.get("intent") or "unknown").strip()
    result["intent"] = intent if intent in ALLOWED_INTENTS else "unknown"
    query_focus = str(result.get("query_focus") or "general").strip()
    result["query_focus"] = (
        query_focus
        if query_focus in {"time", "status", "tracking", "detail", "general"}
        else "general"
    )
    for field in ("order_no", "resolved_text", "tracking_no", "command", "product_info", "reply"):
        result[field] = str(result.get(field) or "").strip()
    return result
