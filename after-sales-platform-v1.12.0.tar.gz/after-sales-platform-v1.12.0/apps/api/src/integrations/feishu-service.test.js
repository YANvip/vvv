const assert = require('assert');
const { splitIds, createFeishuService } = require('./feishu-service');

assert.deepStrictEqual(splitIds('ou_1, ou_2,,ou_1'), ['ou_1', 'ou_2', 'ou_1']);
assert.deepStrictEqual(splitIds(''), []);
assert.deepStrictEqual(splitIds(undefined), []);

const service = createFeishuService({
  FEISHU_APP_ID: 'cli_test',
  FEISHU_APP_SECRET: 'secret_test',
  FEISHU_PRINTER_OPEN_IDS: 'ou_p1, ou_p2',
  FEISHU_CUSTOMER_SERVICE_OPEN_IDS: 'ou_cs1',
  FEISHU_OPERATOR_OPEN_IDS: '',
});
assert.strictEqual(service.enabled(), true);
assert.deepStrictEqual(service.printerIds, ['ou_p1', 'ou_p2']);
assert.deepStrictEqual(service.customerServiceIds, ['ou_cs1']);
assert.deepStrictEqual(service.operatorIds, []);

const disabled = createFeishuService({});
assert.strictEqual(disabled.enabled(), false);

console.log('Feishu service helpers passed');
