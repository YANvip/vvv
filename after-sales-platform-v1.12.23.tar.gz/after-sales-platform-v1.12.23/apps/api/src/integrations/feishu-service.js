const FEISHU_API = 'https://open.feishu.cn/open-apis';
const crypto = require('crypto');

const splitIds = (value) => String(value || '')
  .split(',')
  .map((item) => item.trim())
  .filter(Boolean);

function createFeishuService(env = process.env, fetchImpl = global.fetch) {
  const appId = String(env.FEISHU_APP_ID || '').trim();
  const appSecret = String(env.FEISHU_APP_SECRET || '').trim();
  let cachedToken = '';
  let expiresAt = 0;
  let cachedJsapiTicket = '';
  let jsapiTicketExpiresAt = 0;

  const enabled = () => Boolean(appId && appSecret);

  const token = async () => {
    if (!enabled()) throw new Error('飞书应用配置不完整');
    if (cachedToken && Date.now() < expiresAt) return cachedToken;
    const response = await fetchImpl(`${FEISHU_API}/auth/v3/tenant_access_token/internal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ app_id: appId, app_secret: appSecret }),
    });
    const data = await response.json();
    if (!response.ok || data.code) throw new Error(data.msg || '获取飞书访问令牌失败');
    cachedToken = data.tenant_access_token;
    expiresAt = Date.now() + Math.max(60, Number(data.expire || 7200) - 120) * 1000;
    return cachedToken;
  };

  const request = async (path, options = {}) => {
    const accessToken = await token();
    const response = await fetchImpl(`${FEISHU_API}${path}`, {
      ...options,
      headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json', ...(options.headers || {}) },
    });
    const data = await response.json();
    if (!response.ok || data.code) throw new Error(data.msg || `飞书接口失败：${response.status}`);
    return data.data || {};
  };

  const sendText = async (openIds, text) => {
    const receivers = [...new Set(openIds)].filter(Boolean);
    const results = await Promise.allSettled(
      receivers.map((openId) => request('/im/v1/messages?receive_id_type=open_id', {
      method: 'POST',
      body: JSON.stringify({ receive_id: openId, msg_type: 'text', content: JSON.stringify({ text }) }),
      }))
    );
    const failureDetails = results.flatMap((item, index) => (
      item.status === 'rejected'
        ? [{ openId: receivers[index], error: item.reason?.message || String(item.reason) }]
        : []
    ));
    const failures = failureDetails;
    if (receivers.length && failures.length === receivers.length) {
      throw new Error(`飞书消息全部发送失败：${failures[0].reason?.message || failures[0].reason}`);
    }
    return {
      sent: receivers.length - failures.length,
      failed: failures.length,
      failedOpenIds: failureDetails.map((item) => item.openId),
      failureDetails,
    };
  };

  const sendCard = async (openIds, card) => {
    const receivers = [...new Set(openIds)].filter(Boolean);
    const cardJson = typeof card === 'string' ? card : JSON.stringify(card);
    const results = await Promise.allSettled(
      receivers.map((openId) => request('/im/v1/messages?receive_id_type=open_id', {
        method: 'POST',
        body: JSON.stringify({ receive_id: openId, msg_type: 'interactive', content: cardJson }),
      }))
    );
    const failureDetails = results.flatMap((item, index) => (
      item.status === 'rejected'
        ? [{ openId: receivers[index], error: item.reason?.message || String(item.reason) }]
        : []
    ));
    const failures = failureDetails;
    if (receivers.length && failures.length === receivers.length) {
      throw new Error(`飞书卡片全部发送失败：${failures[0].reason?.message || failures[0].reason}`);
    }
    const messageIds = results.map((item, i) => (
      item.status === 'fulfilled' ? item.value?.message_id : null
    )).filter(Boolean);
    return {
      sent: receivers.length - failures.length,
      failed: failures.length,
      failedOpenIds: failureDetails.map((item) => item.openId),
      failureDetails,
      messageIds,
    };
  };

  const updateCard = async (messageId, card) => {
    const cardJson = typeof card === 'string' ? card : JSON.stringify(card);
    return request(`/im/v1/messages/${encodeURIComponent(messageId)}`, {
      method: 'PATCH',
      body: JSON.stringify({ content: cardJson }),
    });
  };

  const exchangeUserCode = async (code) => {
    if (!enabled()) throw new Error('飞书应用配置不完整');
    const tokenResponse = await fetchImpl(`${FEISHU_API}/authen/v2/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        grant_type: 'authorization_code',
        client_id: appId,
        client_secret: appSecret,
        code,
      }),
    });
    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok || tokenData.code || !tokenData.access_token) {
      throw new Error(tokenData.error_description || tokenData.msg || '飞书免登录授权失败');
    }
    const userResponse = await fetchImpl(`${FEISHU_API}/authen/v1/user_info`, {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const userData = await userResponse.json();
    if (!userResponse.ok || userData.code) {
      throw new Error(userData.msg || '获取飞书用户信息失败');
    }
    return userData.data || userData;
  };

  const jsapiSignature = async (url) => {
    if (!enabled()) throw new Error('飞书应用配置不完整');
    if (!cachedJsapiTicket || Date.now() >= jsapiTicketExpiresAt) {
      const data = await request('/jssdk/ticket/get', { method: 'POST', body: '{}' });
      cachedJsapiTicket = data.ticket;
      if (!cachedJsapiTicket) throw new Error('获取飞书 JSAPI ticket 失败');
      jsapiTicketExpiresAt = Date.now() + Math.max(60, Number(data.expire_in || 7200) - 120) * 1000;
    }
    const timestamp = Date.now();
    const nonceStr = crypto.randomBytes(16).toString('hex');
    const source = `jsapi_ticket=${cachedJsapiTicket}&noncestr=${nonceStr}&timestamp=${timestamp}&url=${url}`;
    const signature = crypto.createHash('sha1').update(source).digest('hex');
    return { appId, timestamp, nonceStr, signature };
  };

  return {
    enabled,
    appId,
    printerIds: splitIds(env.FEISHU_PRINTER_OPEN_IDS),
    customerServiceIds: splitIds(env.FEISHU_CUSTOMER_SERVICE_OPEN_IDS),
    operatorIds: splitIds(env.FEISHU_OPERATOR_OPEN_IDS),
    sendText,
    sendCard,
    updateCard,
    exchangeUserCode,
    jsapiSignature,
  };
}

module.exports = { createFeishuService, splitIds };
