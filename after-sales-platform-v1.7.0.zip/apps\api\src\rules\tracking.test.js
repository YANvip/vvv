const assert = require('assert');
const { normalizeAnengTracking } = require('./tracking');

assert.strictEqual(normalizeAnengTracking('741011448638'), '741011448638');
assert.strictEqual(normalizeAnengTracking('7410114486380001'), '741011448638');
assert.strictEqual(normalizeAnengTracking('74101144863800010001'), '741011448638');
assert.strictEqual(normalizeAnengTracking('SF123456789012'), 'SF123456789012');
assert.strictEqual(normalizeAnengTracking('1234567890129999'), '1234567890129999');

console.log('Tracking normalization tests passed');
