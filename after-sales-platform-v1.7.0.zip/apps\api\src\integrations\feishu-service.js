const FEISHU_API = 'https://open.feishu.cn/open-apis';

const splitIds = (value) => String(value || '')
  .split(',')
  .map((item) => item.trim())
  .filter(Boolean);

const fieldText = (value) => {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string' || typeof value === 'number') return String(value);
  if (Array.isArray(value)) return value.map(fieldText).join('');
  if (typeof value === 'object') return String(value.text || value.name || value.value || value.link || '');
  return '';
};

const quantityNumber = (value) => {
  const text = fieldText(value);
  const digit = text.match(/\d+/);
  if (digit) return Math.max(1, Number(digit[0]));
  const chinese = { 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 };
  const match = text.match(/[一二两三四五六七八九十]/);
  return match ? chinese[match[0]] : 1;
};

const statusFromFeishu = (value, trackingNo = '') => {
  const status = fieldText(value).trim();
  if (trackingNo || /已完成|已打单|已发货/.test(status)) return 'done';
  if (/取消|作废/.test(status)) return 'cancelled';
  if (/异常|疑似重复|待补充|待确认|待审核|待运营/.test(status)) return 'need_review';
  if (/处理中|待仓库/.test(status)) return 'processing';
  return 'pending';
};

const mapBitableRecord = (record) => {
  const fields = record.fields || {};
  const trackingNo = fieldText(fields['快递单号']).trim();
  return {
    feishuRecordId: String(record.record_id || ''),
    platform: fieldText(fields['平台']).trim(),
    orderNo: fieldText(fields['订单号']).trim(),
    type: fieldText(fields['售后类型'] || fields['处理方式']).trim() || '补发',
    productName: fieldText(fields['补发商品'] || fields['商品明细']).trim(),
    quantity: quantityNumber(fields['数量说明'] || fields['数量']),
    reason: fieldText(fields['补发原因'] || fields['原始消息']).trim(),
    trackingNo,
    carrier: fieldText(fields['快递公司']).trim(),
    status: statusFromFeishu(fields['状态'] || fields['审核状态'], trackingNo),
    remark: fieldText(fields['备注']).trim(),
  };
};

const caseToBitableFields = (row) => ({
  平台: row.platform || '',
  订单号: row.order_no || '',
  补发原因: row.reason || '',
  补发商品: [row.product_sku, row.product_name, row.color].filter(Boolean).join(' '),
  商品明细: [row.product_sku || row.product_name, row.color].filter(Boolean).join(' '),
  数量说明: String(Number(row.quantity) || 1),
  原始消息: row.parsed_raw_text || row.reason || '',
  状态: row.status === 'done' ? '已完成' : row.status === 'need_review' ? '待确认' : row.status === 'cancelled' ? '已取消' : '待打单',
  审核状态: row.status === 'done' ? '已打单' : '待打单',
  快递单号: row.resend_tracking_no || '',
  快递公司: row.shipping_carrier || '',
  备注: row.remark || '',
});

function createFeishuService(env = process.env, fetchImpl = global.fetch) {
  const appId = String(env.FEISHU_APP_ID || '').trim();
  const appSecret = String(env.FEISHU_APP_SECRET || '').trim();
  const appToken = String(env.FEISHU_BITABLE_APP_TOKEN || '').trim();
  const tableId = String(env.FEISHU_BITABLE_TABLE_ID || '').trim();
  let cachedToken = '';
  let expiresAt = 0;

  const enabled = () => Boolean(appId && appSecret);
  const bitableEnabled = () => enabled() && Boolean(appToken && tableId);

  const token = async () => {
    if (!enabled()) throw new Error('飞书应用配置不完整');
    if (cachedToken && Date.now() < expiresAt) return cachedToken;
    const response = await fetchImpl(`${FEISHU_API}/auth/v3/tenant_access_token/internal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ app_id: appId, app_secret: appSecret }),
    });
    const data = await response.json();
    if (!response.ok || data.code) throw new Error(data.msg || '获取飞书访问令牌失败');
    cachedToken = data.tenant_access_token;
    expiresAt = Date.now() + Math.max(60, Number(data.expire || 7200) - 120) * 1000;
    return cachedToken;
  };

  const request = async (path, options = {}) => {
    const accessToken = await token();
    const response = await fetchImpl(`${FEISHU_API}${path}`, {
      ...options,
      headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json', ...(options.headers || {}) },
    });
    const data = await response.json();
    if (!response.ok || data.code) throw new Error(data.msg || `飞书接口失败：${response.status}`);
    return data.data || {};
  };

  const sendText = async (openIds, text) => {
    const receivers = [...new Set(openIds)].filter(Boolean);
    const results = await Promise.allSettled(
      receivers.map((openId) => request('/im/v1/messages?receive_id_type=open_id', {
      method: 'POST',
      body: JSON.stringify({ receive_id: openId, msg_type: 'text', content: JSON.stringify({ text }) }),
      }))
    );
    const failures = results.filter((item) => item.status === 'rejected');
    if (receivers.length && failures.length === receivers.length) {
      throw new Error(`飞书消息全部发送失败：${failures[0].reason?.message || failures[0].reason}`);
    }
    return { sent: receivers.length - failures.length, failed: failures.length };
  };

  const listRecords = async () => {
    if (!bitableEnabled()) return [];
    const records = [];
    let pageToken = '';
    do {
      const query = new URLSearchParams({ page_size: '500' });
      if (pageToken) query.set('page_token', pageToken);
      const data = await request(`/bitable/v1/apps/${appToken}/tables/${tableId}/records?${query}`);
      records.push(...(data.items || []));
      pageToken = data.has_more ? String(data.page_token || '') : '';
    } while (pageToken);
    return records;
  };

  const createRecord = async (fields) => request(`/bitable/v1/apps/${appToken}/tables/${tableId}/records`, {
    method: 'POST',
    body: JSON.stringify({ fields }),
  });

  const updateRecord = async (recordId, fields) => request(`/bitable/v1/apps/${appToken}/tables/${tableId}/records/${recordId}`, {
    method: 'PUT',
    body: JSON.stringify({ fields }),
  });

  return {
    enabled,
    bitableEnabled,
    printerIds: splitIds(env.FEISHU_PRINTER_OPEN_IDS),
    customerServiceIds: splitIds(env.FEISHU_CUSTOMER_SERVICE_OPEN_IDS),
    operatorIds: splitIds(env.FEISHU_OPERATOR_OPEN_IDS),
    sendText,
    listRecords,
    createRecord,
    updateRecord,
  };
}

module.exports = {
  splitIds,
  fieldText,
  quantityNumber,
  statusFromFeishu,
  mapBitableRecord,
  caseToBitableFields,
  createFeishuService,
};
