import unittest

from bot_logic import (
    extract_order_query,
    format_case_reply,
    is_confirm,
    is_cancel,
    looks_like_create_request,
    format_parse_result,
    format_create_success,
    build_query_card,
    build_parse_card,
    build_create_success_card,
    build_result_card,
)
import main


class BotLogicTests(unittest.TestCase):
    def test_extracts_plain_and_explicit_queries(self):
        self.assertEqual(extract_order_query("6927550207970082166"), "6927550207970082166")
        self.assertEqual(extract_order_query("查询 260627-227897567592037"), "260627-227897567592037")
        self.assertEqual(extract_order_query("你好"), "")

    def test_formats_completed_case(self):
        reply = format_case_reply({
            "orderNo": "6927550207970082166",
            "found": True,
            "case": {
                "orderNo": "6927550207970082166",
                "platform": "douyin",
                "status": "done",
                "type": "resend",
                "productSku": "7001",
                "productName": "",
                "color": "大象灰",
                "quantity": 1,
                "reason": "漏发",
                "resendTrackingNo": "YT123456789",
            },
            "cases": [{}],
        })
        self.assertIn("状态：已完成", reply)
        self.assertIn("补发内容：7001大象灰 × 1", reply)
        self.assertIn("补发快递单号：YT123456789", reply)

    def test_formats_missing_case(self):
        reply = format_case_reply({"orderNo": "1234567890", "found": False, "case": None, "cases": []})
        self.assertIn("没有查询到", reply)

    def test_confirm_and_cancel_patterns(self):
        self.assertTrue(is_confirm("确认"))
        self.assertTrue(is_confirm("是的"))
        self.assertTrue(is_confirm("好的"))
        self.assertTrue(is_confirm("建单"))
        self.assertFalse(is_confirm("查询 123"))
        self.assertTrue(is_cancel("取消"))
        self.assertTrue(is_cancel("不用"))
        self.assertTrue(is_cancel("不要"))
        self.assertFalse(is_cancel("确认"))

    def test_looks_like_create_request(self):
        self.assertTrue(looks_like_create_request("260708-560380003972903 补发两个6600灰"))
        self.assertTrue(looks_like_create_request("订单123456789012 少发一件"))
        self.assertFalse(looks_like_create_request("6927550207970082166"))
        self.assertFalse(looks_like_create_request("查询 123"))

    def test_build_query_card_found(self):
        card = build_query_card({
            "orderNo": "6927550207970082166",
            "found": True,
            "case": {
                "orderNo": "6927550207970082166",
                "platform": "pinduoduo",
                "status": "done",
                "type": "补发",
                "productSku": "6600",
                "color": "灰",
                "quantity": 2,
                "reason": "漏发",
                "resendTrackingNo": "YT999",
                "caseNo": "AS20260725123456",
            },
            "cases": [{}],
        })
        self.assertEqual(card["header"]["title"]["content"], "订单查询结果")
        self.assertEqual(card["header"]["template"], "green")
        self.assertTrue(any("6927550207970082166" in str(f["text"]["content"]) for f in card["elements"][0]["fields"]))
        self.assertTrue(any("6600" in str(f["text"]["content"]) for f in card["elements"][0]["fields"]))

    def test_build_query_card_not_found(self):
        card = build_query_card({"orderNo": "123", "found": False, "case": None, "cases": []})
        self.assertEqual(card["header"]["template"], "grey")
        self.assertIn("未查询到", card["header"]["title"]["content"])

    def test_build_parse_card(self):
        card = build_parse_card({
            "type": "补发",
            "platform": "拼多多",
            "orderNo": "260708-560380003972903",
            "model": "6600",
            "productName": "xxx",
            "quantity": 2,
            "color": "灰",
            "warnings": ["未识别到客户电话"],
        })
        self.assertEqual(card["header"]["title"]["content"], "请确认建单信息")
        buttons = [a for a in card["elements"] if a["tag"] == "action"][0]["actions"]
        self.assertEqual(len(buttons), 2)
        self.assertEqual(buttons[0]["value"]["action"], "confirm_create")
        self.assertEqual(buttons[1]["value"]["action"], "cancel_create")

    def test_build_create_success_card(self):
        card = build_create_success_card({
            "case": {"caseNo": "AS20260725123456", "orderNo": "123", "type": "补发", "status": "pending"},
            "createdBy": "客服小王",
        })
        self.assertEqual(card["header"]["template"], "green")
        self.assertIn("已创建", card["header"]["title"]["content"])

    def test_build_result_card(self):
        card = build_result_card("测试标题", "测试内容", "blue")
        self.assertEqual(card["header"]["title"]["content"], "测试标题")
        self.assertEqual(card["header"]["template"], "blue")

    def test_format_parse_result(self):
        reply = format_parse_result({
            "type": "补发",
            "platform": "拼多多",
            "orderNo": "260708-560380003972903",
            "model": "6600",
            "productName": "xxx",
            "quantity": 2,
            "color": "灰",
            "warnings": ["未识别到客户电话"],
        })
        self.assertIn("识别结果", reply)
        self.assertIn("260708-560380003972903", reply)
        self.assertIn("确认", reply)
        self.assertIn("未识别到客户电话", reply)

    def test_format_create_success(self):
        reply = format_create_success({
            "case": {"caseNo": "AS20260725123456", "orderNo": "123", "type": "补发", "status": "pending"},
            "createdBy": "客服小王",
        })
        self.assertIn("已创建", reply)
        self.assertIn("AS20260725123456", reply)
        self.assertIn("客服小王", reply)

    def test_message_event_queries_api_and_replies(self):
        replies = []
        original_query = main.query_case
        original_reply_card = main.reply_card
        original_reply_text = main.reply_text
        try:
            main.query_case = lambda order_no: {
                "orderNo": order_no,
                "found": False,
                "case": None,
                "cases": [],
            }
            main.reply_card = lambda message_id, card: replies.append((message_id, card, "card"))
            main.reply_text = lambda message_id, text: replies.append((message_id, text, "text"))
            main.handle_message_event({
                "event": {
                    "sender": {"sender_id": {"open_id": "ou_test"}},
                    "message": {
                        "message_id": "om_test_query",
                        "message_type": "text",
                        "content": '{"text":"查询 6927550207970082166"}',
                    },
                },
            })
        finally:
            main.query_case = original_query
            main.reply_card = original_reply_card
            main.reply_text = original_reply_text
        self.assertEqual(replies[0][0], "om_test_query")
        self.assertEqual(replies[0][2], "card")  # 用卡片回复

    def test_create_flow_parse_and_confirm(self):
        replies = []
        original_parse = main.parse_text
        original_create = main.create_case
        original_reply_card = main.reply_card
        original_reply_text = main.reply_text
        original_query = main.query_case
        original_update = main.update_card
        try:
            main.parse_text = lambda text: {
                "type": "补发",
                "platform": "拼多多",
                "orderNo": "260708-560380003972903",
                "model": "6600",
                "productName": "6600",
                "quantity": 2,
                "color": "灰",
                "warnings": [],
            }
            main.query_case = lambda order_no: {"orderNo": order_no, "found": False, "case": None, "cases": []}
            main.reply_card = lambda message_id, card: (
                replies.append((message_id, card, "card")),
                {"message_id": "om_card_1"},
            )[-1]
            main.reply_text = lambda message_id, text: replies.append((message_id, text, "text"))
            main.create_case = lambda text, open_id, overrides=None, allow_duplicate=False: {
                "case": {"caseNo": "AS20260725123456", "orderNo": "260708-560380003972903",
                         "type": "补发", "status": "pending"},
                "createdBy": "测试客服",
            }
            main.update_card = lambda message_id, card: replies.append((message_id, card, "update"))
            # 第一步：发售后信息，触发解析
            main.handle_message_event({
                "event": {
                    "sender": {"sender_id": {"open_id": "ou_create"}},
                    "message": {
                        "message_id": "om_create_1",
                        "message_type": "text",
                        "content": '{"text":"260708-560380003972903 补发两个6600灰"}',
                    },
                },
            })
            # 第二步：确认建单（通过卡片按钮回调）
            main.handle_card_action({
                "event": {
                    "operator": {"open_id": "ou_create"},
                    "action": {"value": {"action": "confirm_create"}},
                    "token": "om_card_1",
                },
            })
        finally:
            main.parse_text = original_parse
            main.create_case = original_create
            main.reply_card = original_reply_card
            main.reply_text = original_reply_text
            main.query_case = original_query
            main.update_card = original_update
            main.clear_pending("ou_create")
        # 第一条是确认卡片
        self.assertEqual(replies[0][2], "card")
        self.assertEqual(replies[0][1]["header"]["title"]["content"], "请确认建单信息")
        # 最后一条是更新卡片为成功
        last = replies[-1]
        self.assertEqual(last[2], "update")
        self.assertIn("已创建", last[1]["header"]["title"]["content"])

    def test_create_flow_cancel_via_button(self):
        replies = []
        original_parse = main.parse_text
        original_reply_card = main.reply_card
        original_reply_text = main.reply_text
        original_query = main.query_case
        original_update = main.update_card
        try:
            main.parse_text = lambda text: {
                "type": "补发", "platform": "拼多多", "orderNo": "260708-111111111111",
                "model": "6600", "productName": "6600", "quantity": 1, "color": "", "warnings": [],
            }
            main.query_case = lambda order_no: {"orderNo": order_no, "found": False, "case": None, "cases": []}
            main.reply_card = lambda message_id, card: (
                replies.append((message_id, card, "card")),
                {"message_id": "om_card_cancel"},
            )[-1]
            main.reply_text = lambda message_id, text: replies.append((message_id, text, "text"))
            main.update_card = lambda message_id, card: replies.append((message_id, card, "update"))
            main.handle_message_event({
                "event": {
                    "sender": {"sender_id": {"open_id": "ou_cancel"}},
                    "message": {
                        "message_id": "om_cancel_1",
                        "message_type": "text",
                        "content": '{"text":"260708-111111111111 补发6600"}',
                    },
                },
            })
            main.handle_card_action({
                "event": {
                    "operator": {"open_id": "ou_cancel"},
                    "action": {"value": {"action": "cancel_create"}},
                    "token": "om_card_cancel",
                },
            })
        finally:
            main.parse_text = original_parse
            main.reply_card = original_reply_card
            main.reply_text = original_reply_text
            main.query_case = original_query
            main.update_card = original_update
            main.clear_pending("ou_cancel")
        last = replies[-1]
        self.assertEqual(last[2], "update")
        self.assertIn("取消", last[1]["header"]["title"]["content"])


if __name__ == "__main__":
    unittest.main()
