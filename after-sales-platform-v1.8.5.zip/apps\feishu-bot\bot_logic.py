import re


ORDER_TOKEN = r"[A-Za-z0-9][A-Za-z0-9_-]{5,39}"
QUERY_PATTERN = re.compile(
    rf"^(?:查询|查一下|查|订单查询|查订单|进度|状态)\s*[:：]?\s*({ORDER_TOKEN})$",
    re.IGNORECASE,
)
PLAIN_PATTERN = re.compile(rf"^({ORDER_TOKEN})$", re.IGNORECASE)
CONFIRM_PATTERN = re.compile(r"^(确认|是的|是|对|好的|好|建单|提交|确定)\s*$", re.IGNORECASE)
CANCEL_PATTERN = re.compile(r"^(取消|不|不用|算了|不要)\s*$", re.IGNORECASE)

CREATE_KEYWORDS = ("补发", "换货", "退件", "退货", "少发", "漏发", "发错", "破损", "缺少", "补一个", "补两个")

STATUS_NAMES = {
    "need_review": "待确认",
    "pending": "待处理",
    "processing": "处理中",
    "done": "已完成",
    "cancelled": "已取消",
}
STATUS_COLORS = {
    "need_review": "orange",
    "pending": "blue",
    "processing": "turquoise",
    "done": "green",
    "cancelled": "grey",
}
PLATFORM_NAMES = {
    "pinduoduo": "拼多多",
    "douyin": "抖音",
    "taobao": "淘宝/天猫",
    "jd": "京东",
    "kuaishou": "快手",
    "xiaohongshu": "小红书",
    "wechat": "视频号",
}


def extract_order_query(text):
    value = str(text or "").strip()
    for pattern in (QUERY_PATTERN, PLAIN_PATTERN):
        match = pattern.fullmatch(value)
        if match:
            return match.group(1)
    return ""


def is_confirm(text):
    return bool(CONFIRM_PATTERN.match(str(text or "").strip()))


def is_cancel(text):
    return bool(CANCEL_PATTERN.match(str(text or "").strip()))


def looks_like_create_request(text):
    value = str(text or "").strip()
    if not value:
        return False
    if extract_order_query(value):
        return False
    if any(keyword in value for keyword in CREATE_KEYWORDS):
        return True
    return bool(re.search(r"\d{6,}[- ]?\d{10,}", value)) and len(value) > 15


def _platform(payload):
    item = payload.get("case") or {}
    raw = item.get("platform") or "未记录"
    return PLATFORM_NAMES.get(raw, raw)


def _status(payload):
    item = payload.get("case") or {}
    raw = item.get("status") or "未知"
    return STATUS_NAMES.get(raw, raw)


def _status_color(payload):
    item = payload.get("case") or {}
    return STATUS_COLORS.get(item.get("status"), "blue")


def _product_text(payload):
    item = payload.get("case") or {}
    product = item.get("productSku") or item.get("productName") or "未记录"
    color = item.get("color") or ""
    quantity = item.get("quantity") or 0
    text = f"{product}{color}"
    if quantity:
        text += f" × {quantity}"
    return text


def format_case_reply(payload):
    """纯文本版查询结果（兜底用）"""
    order_no = str(payload.get("orderNo") or "")
    item = payload.get("case")
    if not payload.get("found") or not item:
        return "\n".join([
            "没有查询到这笔售后记录。",
            f"订单号：{order_no}",
            "请确认订单号是否完整，或联系管理员检查系统记录。",
        ])
    lines = [
        "订单查询结果",
        f"订单号：{item.get('orderNo') or order_no}",
        f"平台：{_platform(payload)}",
        f"状态：{_status(payload)}",
        f"售后类型：{item.get('type') or '未记录'}",
        f"补发内容：{_product_text(payload)}",
        f"补发原因：{item.get('reason') or '未记录'}",
        f"补发快递单号：{item.get('resendTrackingNo') or '未填写'}",
    ]
    case_count = len(payload.get("cases") or [])
    if case_count > 1:
        lines.append(f"提示：该订单共有 {case_count} 条售后记录，当前显示最新有效记录。")
    return "\n".join(lines)


def build_query_card(payload):
    """查询结果卡片"""
    order_no = str(payload.get("orderNo") or "")
    item = payload.get("case") or {}
    if not payload.get("found") or not item:
        return {
            "config": {"wide_screen_mode": True},
            "header": {
                "title": {"tag": "plain_text", "content": "未查询到售后记录"},
                "template": "grey",
            },
            "elements": [
                {
                    "tag": "div",
                    "text": {"tag": "lark_md", "content": f"**订单号**\n{order_no}\n\n请确认订单号是否完整，或联系管理员检查系统记录。"},
                },
            ],
        }
    case_count = len(payload.get("cases") or [])
    extra_note = f"\n> 该订单共有 {case_count} 条售后记录，当前显示最新有效记录。" if case_count > 1 else ""
    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": "订单查询结果"},
            "template": _status_color(payload),
        },
        "elements": [
            {
                "tag": "div",
                "fields": [
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**订单号**\n{item.get('orderNo') or order_no}"}},
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**平台**\n{_platform(payload)}"}},
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**状态**\n{_status(payload)}"}},
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**售后类型**\n{item.get('type') or '未记录'}"}},
                    {"is_short": False, "text": {"tag": "lark_md", "content": f"**补发内容**\n{_product_text(payload)}"}},
                    {"is_short": False, "text": {"tag": "lark_md", "content": f"**补发原因**\n{item.get('reason') or '未记录'}"}},
                    {"is_short": False, "text": {"tag": "lark_md", "content": f"**补发快递单号**\n{item.get('resendTrackingNo') or '未填写'}"}},
                ],
            },
            {"tag": "hr"},
            {
                "tag": "note",
                "elements": [{"tag": "plain_text", "content": f"工单号：{item.get('caseNo') or item.get('case_no') or '-'}{extra_note}"}],
            },
        ],
    }


def build_parse_card(parsed, text=""):
    """建单确认卡片"""
    warnings = parsed.get("warnings") or []
    warning_text = "".join(f"⚠️ {w}\n" for w in warnings)
    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": "请确认建单信息"},
            "template": "blue",
        },
        "elements": [
            {
                "tag": "div",
                "fields": [
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**类型**\n{parsed.get('type') or '未识别'}"}},
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**平台**\n{parsed.get('platform') or '未识别'}"}},
                    {"is_short": False, "text": {"tag": "lark_md", "content": f"**订单号**\n{parsed.get('orderNo') or '未识别'}"}},
                    {"is_short": False, "text": {"tag": "lark_md", "content": f"**商品型号**\n{parsed.get('model') or parsed.get('productSku') or '未识别'}"}},
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**商品名称**\n{parsed.get('productName') or '未识别'}"}},
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**数量**\n{parsed.get('quantity') or 1}"}},
                    {"is_short": False, "text": {"tag": "lark_md", "content": f"**颜色**\n{parsed.get('color') or '未填写'}"}},
                ],
            },
            {"tag": "hr"},
            {"tag": "div", "text": {"tag": "lark_md", "content": warning_text if warning_text else "确认无误后点击下方按钮创建售后单。"}},
            {
                "tag": "action",
                "layout": "bisected",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "确认建单"},
                        "type": "primary",
                        "value": {"action": "confirm_create"},
                    },
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "取消"},
                        "type": "default",
                        "value": {"action": "cancel_create"},
                    },
                ],
            },
            {
                "tag": "note",
                "elements": [{"tag": "plain_text", "content": "也可以直接回复「确认」或「取消」"}],
            },
        ],
    }


def build_create_success_card(result):
    """建单成功卡片"""
    item = result.get("case") or {}
    status = item.get("status") or "pending"
    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": "售后单已创建"},
            "template": "green",
        },
        "elements": [
            {
                "tag": "div",
                "fields": [
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**工单号**\n{item.get('caseNo') or item.get('case_no') or '-'}"}
                    },
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**状态**\n{STATUS_NAMES.get(status, status)}"}},
                    {"is_short": False, "text": {"tag": "lark_md", "content": f"**订单号**\n{item.get('orderNo') or item.get('order_no') or '-'}"}
                    },
                    {"is_short": True, "text": {"tag": "lark_md", "content": f"**类型**\n{item.get('type') or '-'}"}},
                ],
            },
            {"tag": "hr"},
            {"tag": "div", "text": {"tag": "lark_md", "content": "打单员会收到通知并尽快处理。"}},
            {
                "tag": "action",
                "layout": "bisected",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "在网站查看"},
                        "type": "default",
                        "url": "https://frao.cn",
                    },
                ],
            },
        ],
    }


def build_result_card(title, content, template="blue"):
    """通用结果卡片"""
    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": title},
            "template": template,
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": content}},
        ],
    }


def format_parse_result(parsed, text=""):
    """纯文本版兜底（保留兼容）"""
    lines = ["识别结果（请确认）："]
    lines.append(f"类型：{parsed.get('type') or '未识别'}")
    lines.append(f"平台：{parsed.get('platform') or '未识别'}")
    lines.append(f"订单号：{parsed.get('orderNo') or '未识别'}")
    lines.append(f"商品型号：{parsed.get('model') or parsed.get('productSku') or '未识别'}")
    lines.append(f"商品名称：{parsed.get('productName') or '未识别'}")
    lines.append(f"数量：{parsed.get('quantity') or 1}")
    lines.append(f"颜色：{parsed.get('color') or '未填写'}")
    warnings = parsed.get("warnings") or []
    if warnings:
        lines.append("⚠️ 提示：" + "；".join(warnings))
    lines.append("")
    lines.append("回复「确认」创建售后单，回复「取消」放弃。")
    return "\n".join(lines)


def format_create_success(result):
    """纯文本版兜底（保留兼容）"""
    item = result.get("case") or {}
    lines = [
        "✅ 售后单已创建",
        f"工单号：{item.get('caseNo') or item.get('case_no') or '-'}",
        f"订单号：{item.get('orderNo') or item.get('order_no') or '-'}",
        f"类型：{item.get('type') or '-'}",
        f"状态：{STATUS_NAMES.get(item.get('status'), item.get('status') or '-')}",
    ]
    created_by = result.get("createdBy") or ""
    if created_by:
        lines.append(f"创建人：{created_by}")
    lines.append("打单员会收到通知并尽快处理。")
    return "\n".join(lines)
