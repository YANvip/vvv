import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque

from bot_logic import (
    extract_order_query,
    format_case_reply,
    format_parse_result,
    format_create_success,
    is_confirm,
    is_cancel,
    looks_like_create_request,
    build_query_card,
    build_parse_card,
    build_create_success_card,
    build_result_card,
)


FEISHU_API = "https://open.feishu.cn/open-apis"
APP_ID = os.environ.get("FEISHU_APP_ID", "").strip()
APP_SECRET = os.environ.get("FEISHU_APP_SECRET", "").strip()
INTEGRATION_TOKEN = os.environ.get("FEISHU_INTEGRATION_TOKEN", "").strip()
AFTER_SALES_API_URL = os.environ.get("AFTER_SALES_API_URL", "http://api:3000").rstrip("/")
ALLOWED_OPEN_IDS = {
    value.strip()
    for value in os.environ.get("FEISHU_ALLOWED_OPEN_IDS", "").split(",")
    if value.strip()
}

_tenant_token = {"value": "", "expires_at": 0}
_token_lock = threading.Lock()
_processed_ids = set()
_processed_order = deque()
_processed_lock = threading.Lock()

# 待确认的建单会话：{open_id: {"text": "...", "parsed": {...}, "card_message_id": "..."}}
_pending_create = {}
_pending_lock = threading.Lock()
MAX_PENDING = 200
PENDING_TTL_SECONDS = 10 * 60


def log(message, **fields):
    suffix = " ".join(f"{key}={value}" for key, value in fields.items())
    print(f"[feishu-bot] {message}{' ' + suffix if suffix else ''}", flush=True)


def json_request(url, method="GET", body=None, headers=None, timeout=15):
    request_headers = {"Content-Type": "application/json"}
    request_headers.update(headers or {})
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers=request_headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            detail = json.loads(raw).get("error") or raw
        except json.JSONDecodeError:
            detail = raw
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc


def tenant_access_token():
    with _token_lock:
        if _tenant_token["value"] and _tenant_token["expires_at"] > time.time() + 60:
            return _tenant_token["value"]
        result = json_request(
            f"{FEISHU_API}/auth/v3/tenant_access_token/internal",
            method="POST",
            body={"app_id": APP_ID, "app_secret": APP_SECRET},
        )
        token = result.get("tenant_access_token")
        if not token:
            raise RuntimeError(f"获取飞书 tenant_access_token 失败：{result.get('msg') or result}")
        _tenant_token["value"] = token
        _tenant_token["expires_at"] = time.time() + int(result.get("expire") or 7200)
        return token


def reply_text(message_id, text):
    token = tenant_access_token()
    return json_request(
        f"{FEISHU_API}/im/v1/messages/{urllib.parse.quote(message_id, safe='')}/reply",
        method="POST",
        headers={"Authorization": f"Bearer {token}"},
        body={"msg_type": "text", "content": json.dumps({"text": text}, ensure_ascii=False)},
    )


def reply_card(message_id, card):
    token = tenant_access_token()
    card_json = card if isinstance(card, str) else json.dumps(card, ensure_ascii=False)
    return json_request(
        f"{FEISHU_API}/im/v1/messages/{urllib.parse.quote(message_id, safe='')}/reply",
        method="POST",
        headers={"Authorization": f"Bearer {token}"},
        body={"msg_type": "interactive", "content": card_json},
    )


def send_card_to_user(open_id, card):
    token = tenant_access_token()
    card_json = card if isinstance(card, str) else json.dumps(card, ensure_ascii=False)
    return json_request(
        f"{FEISHU_API}/im/v1/messages?receive_id_type=open_id",
        method="POST",
        headers={"Authorization": f"Bearer {token}"},
        body={"receive_id": open_id, "msg_type": "interactive", "content": card_json},
    )


def update_card(message_id, card):
    token = tenant_access_token()
    card_json = card if isinstance(card, str) else json.dumps(card, ensure_ascii=False)
    return json_request(
        f"{FEISHU_API}/im/v1/messages/{urllib.parse.quote(message_id, safe='')}",
        method="PATCH",
        headers={"Authorization": f"Bearer {token}"},
        body={"content": card_json},
    )


def query_case(order_no):
    return json_request(
        f"{AFTER_SALES_API_URL}/api/integrations/feishu/cases/by-order/"
        f"{urllib.parse.quote(order_no, safe='')}",
        headers={"Authorization": f"Bearer {INTEGRATION_TOKEN}"},
    )


def parse_text(text):
    return json_request(
        f"{AFTER_SALES_API_URL}/api/integrations/feishu/parse",
        method="POST",
        headers={"Authorization": f"Bearer {INTEGRATION_TOKEN}"},
        body={"text": text},
    )


def create_case(text, open_id, overrides=None, allow_duplicate=False):
    body = {"text": text, "openId": open_id, "allowDuplicate": allow_duplicate}
    if overrides:
        body["overrides"] = overrides
    return json_request(
        f"{AFTER_SALES_API_URL}/api/integrations/feishu/cases",
        method="POST",
        headers={"Authorization": f"Bearer {INTEGRATION_TOKEN}"},
        body=body,
    )


def extract_text(content):
    try:
        return str(json.loads(content or "{}").get("text") or "").strip()
    except json.JSONDecodeError:
        return ""


def sender_open_id(event):
    sender_id = ((event.get("sender") or {}).get("sender_id") or {})
    return str(sender_id.get("open_id") or "")


def mark_once(message_id):
    with _processed_lock:
        if message_id in _processed_ids:
            return False
        _processed_ids.add(message_id)
        _processed_order.append(message_id)
        while len(_processed_order) > 5000:
            _processed_ids.discard(_processed_order.popleft())
        return True


def set_pending(open_id, text, parsed, card_message_id=""):
    with _pending_lock:
        _pending_create[open_id] = {
            "text": text,
            "parsed": parsed,
            "card_message_id": card_message_id,
            "created_at": time.time(),
        }
        while len(_pending_create) > MAX_PENDING:
            oldest_key = min(
                _pending_create, key=lambda k: _pending_create[k]["created_at"]
            )
            _pending_create.pop(oldest_key, None)


def get_pending(open_id):
    with _pending_lock:
        entry = _pending_create.get(open_id)
        if not entry:
            return None
        if time.time() - entry["created_at"] > PENDING_TTL_SECONDS:
            _pending_create.pop(open_id, None)
            return None
        return entry


def clear_pending(open_id):
    with _pending_lock:
        return _pending_create.pop(open_id, None)


def handle_create_request(message_id, open_id, text):
    """处理建单请求：解析 -> 发送确认卡片 -> 等待按钮点击"""
    try:
        parsed = parse_text(text)
    except Exception as exc:
        log("解析失败", error=exc, open_id=open_id)
        reply_text(message_id, f"解析失败：{exc}\n请稍后再试，或联系管理员。")
        return

    order_no = parsed.get("orderNo") or ""
    if not order_no:
        reply_text(
            message_id,
            "没有识别到订单号。\n"
            "请确保消息中包含完整的订单号，例如：\n"
            "260708-560380003972903 补发两个6600灰",
        )
        return

    # 先查一下是否已有记录，有就直接返回卡片查询结果
    try:
        existing = query_case(order_no)
        if existing.get("found"):
            reply_card(message_id, build_query_card(existing))
            return
    except Exception:
        pass  # 查询失败不阻塞建单流程

    try:
        card_result = reply_card(message_id, build_parse_card(parsed, text))
        card_message_id = card_result.get("message_id") or ""
    except Exception:
        # 卡片发送失败就用纯文本兜底
        reply_text(message_id, format_parse_result(parsed, text))
        card_message_id = ""

    set_pending(open_id, text, parsed, card_message_id)


def handle_confirm(message_id, open_id, trigger_from_card=False):
    """处理确认建单"""
    pending = get_pending(open_id)
    if not pending:
        reply_card(
            message_id,
            build_result_card(
                "没有待确认的建单请求",
                "请直接发送售后信息，例如：\n260708-560380003972903 补发两个6600灰",
                "grey",
            ),
        ) if not trigger_from_card else reply_text(
            message_id, "没有待确认的建单请求。\n请直接发送售后信息，例如：\n260708-560380003972903 补发两个6600灰"
        )
        return

    card_message_id = pending.get("card_message_id") or ""

    try:
        result = create_case(pending["text"], open_id)
        clear_pending(open_id)

        # 优先更新确认卡片为成功卡片
        if card_message_id:
            try:
                update_card(card_message_id, build_create_success_card(result))
                log("飞书建单成功（卡片已更新）", open_id=open_id,
                    case_no=(result.get("case") or {}).get("caseNo") or "-")
                return
            except Exception as exc:
                log("更新卡片失败，改用回复", error=exc)

        # 兜底：用新消息回复成功
        reply_card(message_id, build_create_success_card(result))
        log("飞书建单成功", open_id=open_id,
            case_no=(result.get("case") or {}).get("caseNo") or "-")
    except RuntimeError as exc:
        # 409 重复订单
        if "HTTP 409" in str(exc):
            clear_pending(open_id)
            if card_message_id:
                try:
                    update_card(
                        card_message_id,
                        build_result_card(
                            "该订单已有售后单",
                            "不能重复创建。\n你可以直接发送订单号查询进度，或联系管理员确认。",
                            "red",
                        ),
                    )
                    return
                except Exception:
                    pass
            reply_text(
                message_id,
                "该订单已有售后单，不能重复创建。\n"
                "你可以直接发送订单号查询进度，或联系管理员确认。",
            )
            return
        log("建单失败", error=exc, open_id=open_id)
        reply_text(message_id, f"建单失败：{exc}\n请稍后再试，或联系管理员。")
    except Exception as exc:
        log("建单异常", error=exc, open_id=open_id)
        reply_text(message_id, f"建单失败：{exc}\n请稍后再试，或联系管理员。")


def handle_cancel(open_id, card_message_id=""):
    """处理取消建单"""
    pending = clear_pending(open_id)
    if not pending:
        return "没有待确认的建单请求。"

    if card_message_id:
        try:
            update_card(
                card_message_id,
                build_result_card("已取消建单", "如有需要，可以重新发送售后信息。", "grey"),
            )
            return None
        except Exception:
            pass
    return "已取消建单。"


def handle_message_event(data):
    event = data.get("event") or {}
    message = event.get("message") or {}
    message_id = str(message.get("message_id") or "")
    if not message_id or not mark_once(message_id):
        return None

    open_id = sender_open_id(event)
    if ALLOWED_OPEN_IDS and open_id not in ALLOWED_OPEN_IDS:
        reply_text(message_id, "当前账号没有订单查询权限，请联系管理员。")
        return None
    if message.get("message_type") != "text":
        reply_text(message_id, "请发送文字消息。\n直接发送订单号可查询，发送售后信息可建单。")
        return None

    text = extract_text(message.get("content"))

    # 1. 确认/取消建单（有等待中的会话）
    if get_pending(open_id):
        if is_confirm(text):
            handle_confirm(message_id, open_id)
            return None
        if is_cancel(text):
            result = handle_cancel(open_id)
            if result:
                reply_text(message_id, result)
            return None
        # 用户又发了新内容，覆盖旧的待确认
        clear_pending(open_id)

    # 2. 纯订单号或查询指令 → 走查询（用卡片）
    order_no = extract_order_query(text)
    if order_no:
        try:
            result = query_case(order_no)
            reply_card(message_id, build_query_card(result))
            log("订单查询完成", order_no=order_no, open_id=open_id)
        except Exception as exc:
            log("订单查询失败", order_no=order_no, error=exc)
            reply_text(message_id, "订单查询暂时失败，请稍后重试；如果持续失败，请联系管理员。")
        return None

    # 3. 看起来像建单请求 → 走建单流程
    if looks_like_create_request(text):
        handle_create_request(message_id, open_id, text)
        return None

    # 4. 其他 → 帮助提示（用卡片更好看）
    help_card = build_result_card(
        "售后助手使用说明",
        "**查询订单**\n直接发送订单号，或发送「查询 + 订单号」\n例如：260708-560380003972903\n\n"
        "**创建售后单**\n发送售后信息，我会识别并让你确认后创建\n例如：260708-560380003972903 补发两个6600灰",
        "blue",
    )
    try:
        reply_card(message_id, help_card)
    except Exception:
        reply_text(
            message_id,
            "你可以这样使用我：\n\n"
            "【查询】直接发送订单号，或发送「查询 + 订单号」\n"
            "例如：260708-560380003972903\n\n"
            "【建单】发送售后信息，我会识别并让你确认后创建\n"
            "例如：260708-560380003972903 补发两个6600灰",
        )
    return None


def handle_card_action(data):
    """处理卡片按钮点击回调"""
    event = data.get("event") or {}
    action = event.get("action") or {}
    value = action.get("value") or {}
    action_type = value.get("action") or ""

    open_id = ((event.get("operator") or {}).get("tenant_key") or {}).get(
        "open_id"
    ) or ((event.get("operator") or {}).get("open_id") or "")

    card_message_id = (event.get("token") or "") or ""

    if ALLOWED_OPEN_IDS and open_id not in ALLOWED_OPEN_IDS:
        return

    if action_type == "confirm_create":
        handle_confirm(card_message_id or "card_action", open_id, trigger_from_card=True)
    elif action_type == "cancel_create":
        result = handle_cancel(open_id, card_message_id)
        if result and card_message_id:
            try:
                update_card(
                    card_message_id,
                    build_result_card("已取消建单", "如有需要，可以重新发送售后信息。", "grey"),
                )
            except Exception:
                pass


def main():
    missing = [
        name
        for name, value in {
            "FEISHU_APP_ID": APP_ID,
            "FEISHU_APP_SECRET": APP_SECRET,
            "FEISHU_INTEGRATION_TOKEN": INTEGRATION_TOKEN,
        }.items()
        if not value
    ]
    if missing:
        raise SystemExit("缺少配置：" + ", ".join(missing))

    import lark_oapi as lark

    def on_message(data):
        payload = json.loads(lark.JSON.marshal(data))
        return handle_message_event(payload)

    def on_card_action(data):
        payload = json.loads(lark.JSON.marshal(data))
        return handle_card_action(payload)

    log("正在启动飞书长连接", api=AFTER_SALES_API_URL)
    event_handler = (
        lark.EventDispatcherHandler.builder("", "")
        .register_p2_im_message_receive_v1(on_message)
        .register_p2_card_action_trigger(on_card_action)
        .build()
    )
    client = lark.ws.Client(
        APP_ID,
        APP_SECRET,
        event_handler=event_handler,
        log_level=lark.LogLevel.INFO,
    )
    client.start()


if __name__ == "__main__":
    main()
