#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/after-sales-platform"
ZIP_FILE="/opt/after-sales-platform.zip"
STAGE_DIR="/opt/after-sales-platform-stage"
BACKUP_DIR="/opt/after-sales-platform-backup-$(date +%Y%m%d-%H%M%S)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ ! -f "$APP_DIR/infra/.env" ]; then
  echo "未找到服务器现有配置 $APP_DIR/infra/.env，已停止，避免覆盖密码。"
  exit 1
fi
if [ ! -d "$APP_DIR/infra/data" ]; then
  echo "未找到服务器现有数据目录 $APP_DIR/infra/data，已停止，避免误部署。"
  exit 1
fi
if [ ! -d "$APP_DIR/infra/ssl" ]; then
  echo "未找到服务器现有证书目录 $APP_DIR/infra/ssl，已停止，避免覆盖 HTTPS 配置。"
  exit 1
fi

cp -a "$APP_DIR" "$BACKUP_DIR"

if [ -f "$PACKAGE_DIR/apps/api/src/server.js" ] && [ "$PACKAGE_DIR" != "$APP_DIR" ]; then
  SOURCE_DIR="$PACKAGE_DIR"
  echo "使用已解压升级目录：$SOURCE_DIR"
else
  if [ ! -f "$ZIP_FILE" ]; then
    echo "未找到已解压升级目录，也未找到 $ZIP_FILE"
    exit 1
  fi
  rm -rf "$STAGE_DIR"
  mkdir -p "$STAGE_DIR"
  set +e
  unzip -q -o "$ZIP_FILE" -d "$STAGE_DIR"
  UNZIP_STATUS=$?
  set -e
  if [ "$UNZIP_STATUS" -gt 1 ] || [ ! -f "$STAGE_DIR/apps/api/src/server.js" ]; then
    echo "升级包解压失败。"
    exit 1
  fi
  SOURCE_DIR="$STAGE_DIR"
fi

cp -a "$SOURCE_DIR/apps/." "$APP_DIR/apps/"
cp -a "$SOURCE_DIR/docs/." "$APP_DIR/docs/"
cp -a "$SOURCE_DIR/infra/docker-compose.yml" "$APP_DIR/infra/docker-compose.yml"
cp -a "$SOURCE_DIR/infra/nginx/." "$APP_DIR/infra/nginx/"
cp -a "$SOURCE_DIR/infra/initdb/." "$APP_DIR/infra/initdb/"
cp -a "$SOURCE_DIR/README.md" "$APP_DIR/README.md"

cd "$APP_DIR/infra"
docker compose up -d
docker compose restart api web feishu-bot
docker compose ps

echo "升级完成。代码备份：$BACKUP_DIR"
