CREATE TABLE IF NOT EXISTS after_sales_cases (
  id BIGSERIAL PRIMARY KEY,
  case_no VARCHAR(50) UNIQUE NOT NULL,
  type VARCHAR(20) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  platform VARCHAR(30),
  shop_name VARCHAR(100),
  order_no VARCHAR(100),
  customer_name VARCHAR(100),
  customer_phone VARCHAR(50),
  product_name VARCHAR(255),
  product_sku VARCHAR(100),
  quantity INTEGER DEFAULT 1 CHECK (quantity > 0),
  color VARCHAR(50),
  reason TEXT,
  solution TEXT,
  resend_tracking_no VARCHAR(100),
  exchange_out_tracking_no VARCHAR(100),
  exchange_return_tracking_no VARCHAR(100),
  return_tracking_no VARCHAR(100),
  owner_name VARCHAR(100),
  assigned_to BIGINT,
  created_by BIGINT,
  parsed_raw_text TEXT,
  parse_warnings TEXT,
  remark TEXT,
  completed_at TIMESTAMPTZ,
  priority VARCHAR(20) NOT NULL DEFAULT 'normal',
  due_at TIMESTAMPTZ,
  tags TEXT NOT NULL DEFAULT '',
  feishu_record_id VARCHAR(100),
  source VARCHAR(30) NOT NULL DEFAULT 'web',
  shipping_carrier VARCHAR(50),
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_after_sales_cases_order_no ON after_sales_cases(order_no);
CREATE INDEX IF NOT EXISTS idx_after_sales_cases_status ON after_sales_cases(status);
CREATE INDEX IF NOT EXISTS idx_after_sales_cases_platform ON after_sales_cases(platform);

CREATE TABLE IF NOT EXISTS package_scans (
  id BIGSERIAL PRIMARY KEY,
  tracking_no VARCHAR(100) UNIQUE NOT NULL,
  carton_spec VARCHAR(100) NOT NULL,
  batch_id VARCHAR(100) NOT NULL,
  created_by BIGINT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_package_scans_batch ON package_scans(batch_id);

CREATE TABLE IF NOT EXISTS scan_registry (
  tracking_hash CHAR(64) PRIMARY KEY,
  tracking_no VARCHAR(100),
  scan_type VARCHAR(30) NOT NULL,
  carrier VARCHAR(50) NOT NULL DEFAULT '未分类',
  created_by BIGINT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_scan_registry_created ON scan_registry(created_at);

CREATE TABLE IF NOT EXISTS scan_batches (
  batch_id VARCHAR(100) PRIMARY KEY,
  batch_name VARCHAR(150) NOT NULL,
  copied_at TIMESTAMPTZ,
  created_by BIGINT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS return_receipts (
  id BIGSERIAL PRIMARY KEY,
  tracking_no VARCHAR(100) UNIQUE NOT NULL,
  carrier VARCHAR(50) NOT NULL DEFAULT '待确认',
  carrier_confidence NUMERIC(4,3) NOT NULL DEFAULT 0,
  return_type VARCHAR(30) NOT NULL DEFAULT '退件',
  remark TEXT NOT NULL DEFAULT '',
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by BIGINT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_return_receipts_received ON return_receipts(received_at DESC);
CREATE INDEX IF NOT EXISTS idx_return_receipts_carrier ON return_receipts(carrier);

CREATE TABLE IF NOT EXISTS interception_records (
  id BIGSERIAL PRIMARY KEY,
  tracking_no VARCHAR(100) UNIQUE NOT NULL,
  carrier VARCHAR(50) NOT NULL,
  intercepted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_interception_records_time ON interception_records(intercepted_at DESC);

CREATE TABLE IF NOT EXISTS ai_parse_cache (
  cache_key CHAR(64) PRIMARY KEY,
  result JSONB NOT NULL,
  prompt_tokens INTEGER DEFAULT 0,
  completion_tokens INTEGER DEFAULT 0,
  cache_hit_tokens INTEGER DEFAULT 0,
  hit_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
