const assert = require('assert');
const { splitIds, createFeishuService } = require('./feishu-service');

assert.deepStrictEqual(splitIds('ou_1, ou_2,,ou_1'), ['ou_1', 'ou_2', 'ou_1']);
assert.deepStrictEqual(splitIds(''), []);
assert.deepStrictEqual(splitIds(undefined), []);

const service = createFeishuService({
  FEISHU_APP_ID: 'cli_test',
  FEISHU_APP_SECRET: 'secret_test',
  FEISHU_PRINTER_OPEN_IDS: 'ou_p1, ou_p2',
  FEISHU_CUSTOMER_SERVICE_OPEN_IDS: 'ou_cs1',
  FEISHU_OPERATOR_OPEN_IDS: '',
});
assert.strictEqual(service.enabled(), true);
assert.deepStrictEqual(service.printerIds, ['ou_p1', 'ou_p2']);
assert.deepStrictEqual(service.customerServiceIds, ['ou_cs1']);
assert.deepStrictEqual(service.operatorIds, []);

const disabled = createFeishuService({});
assert.strictEqual(disabled.enabled(), false);

(async () => {
  const fetchImpl = async (url, options = {}) => {
    if (url.includes('/auth/v3/tenant_access_token/internal')) {
      return {
        ok: true,
        json: async () => ({ code: 0, tenant_access_token: 'token', expire: 7200 }),
      };
    }
    const body = JSON.parse(options.body || '{}');
    const failed = body.receive_id === 'ou_failed';
    return {
      ok: true,
      json: async () => (
        failed
          ? { code: 230013, msg: 'recipient unavailable' }
          : { code: 0, data: { message_id: `msg_${body.receive_id}` } }
      ),
    };
  };
  const detailed = createFeishuService({
    FEISHU_APP_ID: 'cli_test',
    FEISHU_APP_SECRET: 'secret_test',
  }, fetchImpl);
  const result = await detailed.sendCard(['ou_ok', 'ou_failed'], { elements: [] });
  assert.strictEqual(result.sent, 1);
  assert.strictEqual(result.failed, 1);
  assert.deepStrictEqual(result.failedOpenIds, ['ou_failed']);
  assert.deepStrictEqual(result.failureDetails, [
    { openId: 'ou_failed', error: 'recipient unavailable' },
  ]);

  const authFetch = async (url) => {
    if (url.includes('/authen/v2/oauth/token')) {
      return { ok: true, json: async () => ({ access_token: 'user-token' }) };
    }
    if (url.includes('/authen/v1/user_info')) {
      return { ok: true, json: async () => ({ code: 0, data: { open_id: 'ou_user', name: '测试用户' } }) };
    }
    if (url.includes('/auth/v3/tenant_access_token/internal')) {
      return { ok: true, json: async () => ({ code: 0, tenant_access_token: 'tenant-token', expire: 7200 }) };
    }
    if (url.includes('/jssdk/ticket/get')) {
      return { ok: true, json: async () => ({ code: 0, data: { ticket: 'ticket-value', expire_in: 7200 } }) };
    }
    throw new Error(`Unexpected URL: ${url}`);
  };
  const authService = createFeishuService({
    FEISHU_APP_ID: 'cli_test',
    FEISHU_APP_SECRET: 'secret_test',
  }, authFetch);
  const user = await authService.exchangeUserCode('one-use-code');
  assert.strictEqual(user.open_id, 'ou_user');
  const signed = await authService.jsapiSignature('https://frao.cn/?page=scanner');
  assert.strictEqual(signed.appId, 'cli_test');
  assert.match(signed.nonceStr, /^[a-f0-9]{32}$/);
  assert.match(signed.signature, /^[a-f0-9]{40}$/);

  const integrationFetch = async (url) => {
    if (url.includes('/auth/v3/tenant_access_token/internal')) {
      return { ok: true, json: async () => ({ code: 0, tenant_access_token: 'tenant-token', expire: 7200 }) };
    }
    if (url.includes('/contact/v3/scopes')) {
      return { ok: true, json: async () => ({ code: 0, data: { user_ids: ['ou_staff'], department_ids: [], has_more: false } }) };
    }
    if (url.includes('/contact/v3/users/ou_staff')) {
      return { ok: true, json: async () => ({ code: 0, data: { user: { open_id: 'ou_staff', name: '飞书员工', department_ids: ['od_1'], status: { is_activated: true } } } }) };
    }
    if (url.includes('/bitable/v1/apps/app_token/tables/tbl_products/records')) {
      return { ok: true, json: async () => ({ code: 0, data: { items: [{ record_id: 'rec_1', fields: { '商品型号': '7001', '启用': true } }], has_more: false } }) };
    }
    if (url.includes('/bitable/v1/apps/app_token/tables')) {
      return { ok: true, json: async () => ({ code: 0, data: { items: [{ table_id: 'tbl_products', name: '商品知识库' }], has_more: false } }) };
    }
    throw new Error(`Unexpected URL: ${url}`);
  };
  const integrationService = createFeishuService({ FEISHU_APP_ID: 'cli_test', FEISHU_APP_SECRET: 'secret_test' }, integrationFetch);
  const directory = await integrationService.listDirectoryUsers();
  assert.deepStrictEqual(directory.map((item) => item.openId), ['ou_staff']);
  const knowledge = await integrationService.ensureProductKnowledgeBase('https://example.feishu.cn/base/app_token?table=tbl_products');
  assert.strictEqual(knowledge.tableId, 'tbl_products');
  assert.strictEqual(knowledge.records[0].fields['商品型号'], '7001');
  console.log('Feishu service helpers passed');
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
