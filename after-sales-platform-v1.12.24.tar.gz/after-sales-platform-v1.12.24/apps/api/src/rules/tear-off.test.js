const assert = require('assert');
const { parseTearOffText } = require('./tear-off');

const parsed = parseTearOffText('JT5515830658872 撕单 7001大象灰');
assert(parsed);
assert.strictEqual(parsed.trackingNo, 'JT5515830658872');
assert.strictEqual(parsed.carrier, '极兔');
assert.strictEqual(parsed.productInfo, '7001大象灰');
assert.strictEqual(parseTearOffText('JT5515830658872 拦截'), null);
assert.strictEqual(parseTearOffText('撕单 7001大象灰'), null);
console.log('Tear-off parser tests passed');
