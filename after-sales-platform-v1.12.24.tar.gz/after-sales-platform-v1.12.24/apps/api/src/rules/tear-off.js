const { detectCarrier, isPlausibleTracking } = require('./carrier');
const { normalizeAnengTracking, isAnengTracking } = require('./tracking');

const normalizeTracking = (value) => String(value || '').trim().replace(/\s+/g, '').toUpperCase();

function parseTearOffText(value) {
  const text = String(value || '').trim();
  if (!text || !/(?:撕单|退款撕单)/.test(text)) return null;
  const candidates = text.toUpperCase().match(/[A-Z0-9][A-Z0-9-]{7,39}/g) || [];
  const rawTrackingNo = candidates.find((item) => isPlausibleTracking(item));
  if (!rawTrackingNo) return null;
  const trackingNo = isAnengTracking(rawTrackingNo)
    ? normalizeAnengTracking(rawTrackingNo)
    : normalizeTracking(rawTrackingNo);
  const detected = detectCarrier(trackingNo);
  const productInfo = text
    .replace(new RegExp(rawTrackingNo.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'), ' ')
    .replace(/退款撕单|撕单/g, ' ')
    .replace(/(?:安能|中通|极兔|圆通|京东|顺丰|韵达|申通|邮政|德邦|其他)快递?/g, ' ')
    .replace(/[，,。；;：:]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return {
    trackingNo,
    carrier: detected.matched ? detected.carrier : '待确认',
    productInfo,
  };
}

module.exports = { parseTearOffText };
