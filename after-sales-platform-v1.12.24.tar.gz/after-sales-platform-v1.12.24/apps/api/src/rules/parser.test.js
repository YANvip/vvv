const assert = require('assert');
const { parseAfterSalesText } = require('./parser');

let result = parseAfterSalesText('260708-560380003972903 补发两个6600灰');
assert.equal(result.platform, '拼多多');
assert.equal(result.quantity, 2);
assert.equal(result.model, '6600');
assert.equal(result.color, '灰色');

result = parseAfterSalesText('6953585234348872915补发5个6600脚垫');
assert.equal(result.platform, '抖店');
assert.equal(result.quantity, 5);
assert.equal(result.model, '6600脚垫');
assert.equal(result.color, '');

result = parseAfterSalesText('260725-1234567890001 补发6600 5个脚垫');
assert.equal(result.items[0].model, '6600脚垫');
assert.equal(result.items[0].quantity, 5);

result = parseAfterSalesText('260725-1234567890002 一把6600抹茶绿+10个脚垫');
assert.equal(result.items.length, 2);
assert.deepEqual(result.items.map((item) => [item.model, item.quantity, item.color]), [
  ['6600', 1, '抹茶绿'],
  ['6600脚垫', 10, ''],
]);

result = parseAfterSalesText('260725-1234567890003 补发6600蓝一个绿一个');
assert.deepEqual(result.items.map((item) => [item.model, item.quantity, item.color]), [
  ['6600', 1, '蓝色'],
  ['6600', 1, '绿色'],
]);

result = parseAfterSalesText('260725-1234567890004 补发33旋风橙黄1个+抹茶绿1个+粉色1个共3把');
assert.equal(result.items.length, 3);
assert.deepEqual(result.items.map((item) => item.color), ['旋风橙黄色', '抹茶绿', '粉色']);

result = parseAfterSalesText('260725-1234567890005 补发10个210蛋白皮脚垫');
assert.equal(result.items[0].model, '210脚垫');
assert.equal(result.items[0].quantity, 10);

result = parseAfterSalesText('260725-1234567890006 补发5个210螺丝钉和3个脚垫');
assert.deepEqual(result.items.map((item) => [item.model, item.quantity]), [
  ['210螺丝', 5],
  ['210脚垫', 3],
]);

result = parseAfterSalesText('260725-1234567890007 补发5个脚垫1把7002');
assert.equal(result.needReview, true);
assert(result.warnings.some((warning) => warning.includes('多个商品数量')));

result = parseAfterSalesText('260724-259543559820500补蛋卷桌50cm黑色杆子两根');
assert.equal(result.platform, '拼多多');
assert.equal(result.needReview, false);
assert.equal(result.model, '补蛋卷桌50cm黑色杆子两根');
assert.equal(result.productName, '补蛋卷桌50cm黑色杆子两根');
assert.equal(result.productType, '客服原话');
assert.equal(result.quantity, 2);
assert.equal(result.items[0].catalogMatched, false);

result = parseAfterSalesText('260725-684321687053207补发 50cm蛋卷桌桌面原木色一个', []);
assert.equal(result.orderNo, '260725-684321687053207');
assert.equal(result.platform, '拼多多');
assert.equal(result.quantity, 1);
assert.equal(result.needReview, false);
assert(result.productName.includes('50cm蛋卷桌桌面原木色一个'));
assert.equal(result.items[0].catalogMatched, false);

console.log('Parser tests passed');
