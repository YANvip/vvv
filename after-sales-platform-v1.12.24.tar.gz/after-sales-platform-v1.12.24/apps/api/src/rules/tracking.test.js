const assert = require('assert');
const { normalizeAnengTracking, isAnengTracking } = require('./tracking');

assert.strictEqual(normalizeAnengTracking('741011448638'), '741011448638');
assert.strictEqual(normalizeAnengTracking('7410114486380001'), '741011448638');
assert.strictEqual(normalizeAnengTracking('74101144863800010001'), '741011448638');
assert.strictEqual(normalizeAnengTracking('SF123456789012'), 'SF123456789012');
assert.strictEqual(normalizeAnengTracking('1234567890129999'), '1234567890129999');
assert.strictEqual(isAnengTracking('741011448638'), true);
assert.strictEqual(isAnengTracking('750100983882'), true);
assert.strictEqual(isAnengTracking('760100983882'), true);
assert.strictEqual(isAnengTracking('7601009838820001'), true);
assert.strictEqual(isAnengTracking('7410114486380001'), true);
assert.strictEqual(isAnengTracking('JT5508800000790'), false);
assert.strictEqual(isAnengTracking('SF123456789012'), false);

console.log('Tracking normalization tests passed');
