const normalizeCarrierTracking = (value) => String(value || '')
  .trim()
  .replace(/\s+/g, '')
  .toUpperCase();

const rules = [
  { carrier: '安能', confidence: 1, matchType: 'exact', pattern: /^(?:74|75|76)\d{10}$/ },
  { carrier: '顺丰', confidence: 1, matchType: 'exact', pattern: /^SF\d{10,18}$/ },
  { carrier: '京东', confidence: 1, matchType: 'exact', pattern: /^(?:JD[A-Z]{0,3}|VA|VC)\d{8,20}(?:-\d+)*-?$/ },
  { carrier: '极兔', confidence: 1, matchType: 'exact', pattern: /^JT\d{10,20}$/ },
  { carrier: '圆通', confidence: 1, matchType: 'exact', pattern: /^YT\d{8,20}$/ },
  { carrier: '中通', confidence: 1, matchType: 'exact', pattern: /^ZTO\d{8,20}$/ },
  { carrier: '申通', confidence: 1, matchType: 'exact', pattern: /^STO\d{8,20}$/ },
  { carrier: '韵达', confidence: 1, matchType: 'exact', pattern: /^(?:YD|YUNDA)\d{8,20}$/ },
  { carrier: '德邦', confidence: 1, matchType: 'exact', pattern: /^(?:DPK|DEPPON)\d{7,20}$/ },
  { carrier: '邮政', confidence: 0.98, matchType: 'exact', pattern: /^(?:EMS\d{8,20}|[A-Z]{2}\d{9}CN)$/ },

  // Numeric waybills cannot always be distinguished globally. Keep only
  // high-value patterns backed by official examples or stable production use.
  { carrier: '中通', confidence: 0.96, matchType: 'numeric', pattern: /^73\d{12}$/ },
  { carrier: '中通', confidence: 0.88, matchType: 'numeric', pattern: /^6\d{11}$/ },
  { carrier: '韵达', confidence: 0.86, matchType: 'numeric', pattern: /^(?:12|16|19|43|46|48|50|55|58)\d{11}$/ },
];

function detectCarrier(value) {
  const trackingNo = normalizeCarrierTracking(value);
  const matched = rules.find((rule) => rule.pattern.test(trackingNo));
  if (matched) {
    return {
      trackingNo,
      carrier: matched.carrier,
      confidence: matched.confidence,
      matched: true,
      matchType: matched.matchType,
    };
  }
  return { trackingNo, carrier: '待确认', confidence: 0, matched: false, matchType: 'unknown' };
}

function isLikelyRetailBarcode(value) {
  const trackingNo = normalizeCarrierTracking(value);
  if (!/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/.test(trackingNo)) return false;

  const digits = trackingNo.split('').map(Number);
  const expected = digits.pop();
  let sum = 0;
  let weight = 3;
  for (let index = digits.length - 1; index >= 0; index -= 1) {
    sum += digits[index] * weight;
    weight = weight === 3 ? 1 : 3;
  }
  return (10 - (sum % 10)) % 10 === expected;
}

function isPlausibleTracking(value) {
  const trackingNo = normalizeCarrierTracking(value);
  if (!/^[A-Z0-9-]{8,30}$/.test(trackingNo)) return false;
  if (!/[0-9]/.test(trackingNo) || /^(.)\1+$/.test(trackingNo)) return false;
  if (/^\d+$/.test(trackingNo)) return trackingNo.length >= 10 && trackingNo.length <= 20;
  return /[A-Z]/.test(trackingNo) && trackingNo.length >= 10 && trackingNo.length <= 24;
}

module.exports = {
  detectCarrier,
  normalizeCarrierTracking,
  isLikelyRetailBarcode,
  isPlausibleTracking,
};
