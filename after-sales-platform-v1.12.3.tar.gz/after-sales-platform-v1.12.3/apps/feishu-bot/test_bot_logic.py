from bot_logic import is_my_id_request


def test_my_id_commands():
    accepted = (
        "我的id",
        "我的 ID",
        "我的飞书ID",
        "获取ID",
        "查询 open_id",
        "查看用户ID？",
    )
    rejected = (
        "",
        "订单ID",
        "我的订单",
        "查询260708-560380003972903",
    )

    for value in accepted:
        assert is_my_id_request(value), value
    for value in rejected:
        assert not is_my_id_request(value), value


if __name__ == "__main__":
    test_my_id_commands()
    print("Feishu identity command tests passed")
