# 网店售后工作台 1.12.22 升级说明

本次升级增加任务数字角标、飞书通知记录与重新通知、数据库自动备份。

## 本次调整

- 顶部“打单中心、拦截记录、退款撕单、异常中心”显示待处理任务数量，每 30 秒刷新。
- 管理后台“飞书通知”显示通知时间、接收人、发送结果、失败原因和尝试次数。
- 发送失败的飞书通知可由管理员点击“重新通知”。
- 每天凌晨 2 点后自动生成一次 PostgreSQL 数据库备份，默认保留 30 天。
- 管理后台新增“数据备份”，支持立即备份、查看备份和下载备份文件。
- 升级继续保留 `.env`、数据库、SSL 证书和已有备份文件。

说明：飞书通知记录从升级完成后开始积累，升级前已经发出的通知不会补录。

## GitHub 仓库升级

把压缩包上传至 `YANvip/vvv` 仓库根目录后，在服务器执行现有的 GitHub 下载和解压步骤，再运行：

```bash
bash /opt/after-sales-platform-upload/infra/deploy-update.sh
```

## 直接上传服务器升级

把压缩包上传到服务器 `/opt` 后执行：

```bash
cd /opt
tar -xzf after-sales-platform-v1.12.22.tar.gz
bash after-sales-platform-v1.12.22/deploy-v1.12.22.sh
```

升级后检查：

```bash
curl --max-time 10 http://127.0.0.1:3000/api/health
docker compose -f /opt/after-sales-platform/infra/docker-compose.yml ps
```

健康检查应显示版本 `1.12.22`。

## 自动备份

- 备份目录：`/opt/after-sales-platform/infra/backups`
- 默认保留天数：30 天
- 可在 `/opt/after-sales-platform/infra/.env` 中设置 `BACKUP_RETENTION_DAYS=30`
- 自动清理只删除系统生成的数据库 `.dump` 备份，不影响数据库、证书或其他文件。
