import json
import os
import threading
import time
from collections import deque

import lark_oapi as lark
from lark_oapi.api.im.v1 import (
    CreateMessageRequest,
    CreateMessageRequestBody,
    PatchMessageRequest,
    PatchMessageRequestBody,
    ReplyMessageRequest,
    ReplyMessageRequestBody,
)
from lark_oapi.event.callback.model.p2_card_action_trigger import (
    CallBackToast,
    P2CardActionTriggerResponse,
)

from bot_logic import (
    extract_interception_command,
    extract_tear_off_command,
    extract_order_query,
    is_confirm,
    is_cancel,
    is_my_id_request,
    looks_like_create_request,
    build_query_card,
    build_existing_case_card,
    build_parse_card,
    build_create_success_card,
    build_result_card,
    build_scanner_card,
)
from ai_router import interpret_with_bailian

APP_ID = os.environ.get("FEISHU_APP_ID", "").strip()
APP_SECRET = os.environ.get("FEISHU_APP_SECRET", "").strip()
INTEGRATION_TOKEN = os.environ.get("FEISHU_INTEGRATION_TOKEN", "").strip()
AFTER_SALES_API_URL = os.environ.get("AFTER_SALES_API_URL", "http://api:3000").rstrip("/")
ALLOWED_OPEN_IDS = {
    value.strip()
    for value in os.environ.get("FEISHU_ALLOWED_OPEN_IDS", "").split(",")
    if value.strip()
}
BAILIAN_API_KEY = os.environ.get("BAILIAN_API_KEY", "").strip()
BAILIAN_BASE_URL = os.environ.get(
    "BAILIAN_BASE_URL",
    "https://dashscope.aliyuncs.com/compatible-mode/v1",
).strip().rstrip("/")
BAILIAN_MODEL = os.environ.get("BAILIAN_MODEL", "qwen-plus").strip()
BAILIAN_TIMEOUT_SECONDS = max(3, min(30, int(os.environ.get("BAILIAN_TIMEOUT_SECONDS", "12"))))

_client = None
_client_lock = threading.Lock()

_processed_ids = set()
_processed_order = deque()
_processed_lock = threading.Lock()

_pending_create = {}
_pending_lock = threading.Lock()
MAX_PENDING = 200
PENDING_TTL_SECONDS = 10 * 60

_conversation_context = {}
_conversation_lock = threading.Lock()
CONTEXT_TTL_SECONDS = 30 * 60
MAX_CONTEXTS = 500

def remember_context(open_id, order_no="", text=""):
    if not open_id:
        return
    with _conversation_lock:
        previous = _conversation_context.get(open_id) or {}
        _conversation_context[open_id] = {
            "last_order_no": str(order_no or previous.get("last_order_no") or "").strip(),
            "last_text": str(text or previous.get("last_text") or "").strip()[:500],
            "updated_at": time.time(),
        }
        while len(_conversation_context) > MAX_CONTEXTS:
            oldest = min(_conversation_context, key=lambda key: _conversation_context[key]["updated_at"])
            _conversation_context.pop(oldest, None)

def get_context(open_id):
    with _conversation_lock:
        context = _conversation_context.get(open_id)
        if not context:
            return {}
        if time.time() - context["updated_at"] > CONTEXT_TTL_SECONDS:
            _conversation_context.pop(open_id, None)
            return {}
        return dict(context)

def log(message, **fields):
    suffix = " ".join(f"{key}={value}" for key, value in fields.items())
    print(f"[feishu-bot] {message}{' ' + suffix if suffix else ''}", flush=True)

def get_client():
    global _client
    with _client_lock:
        if _client is None:
            _client = (
                lark.Client.builder()
                .app_id(APP_ID)
                .app_secret(APP_SECRET)
                .log_level(lark.LogLevel.ERROR)
                .build()
            )
        return _client

def api_request(path, method="GET", body=None):
    import urllib.error
    import urllib.parse
    import urllib.request

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {INTEGRATION_TOKEN}",
    }
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    url = f"{AFTER_SALES_API_URL}{path}"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            detail = json.loads(raw).get("error") or raw
        except json.JSONDecodeError:
            detail = raw
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc

def query_case(order_no):
    import urllib.parse
    return api_request(
        f"/api/integrations/feishu/cases/by-order/{urllib.parse.quote(order_no, safe='')}"
    )

def query_bound_user(open_id):
    import urllib.parse
    if not open_id:
        return {"found": False, "user": None}
    return api_request(
        f"/api/integrations/feishu/users/by-open-id/{urllib.parse.quote(open_id, safe='')}"
    )

def bound_user_or_none(open_id):
    try:
        result = query_bound_user(open_id)
        return result.get("user") if result.get("found") else None
    except Exception as exc:
        log("查询后台绑定失败", open_id=open_id, error=exc)
        raise

def parse_text(text):
    return api_request("/api/integrations/feishu/parse", method="POST", body={"text": text})

def create_case(text, open_id, overrides=None, allow_duplicate=False, confirmed=False):
    body = {
        "text": text,
        "openId": open_id,
        "allowDuplicate": allow_duplicate,
        "confirmed": bool(confirmed),
    }
    if overrides:
        body["overrides"] = overrides
    return api_request("/api/integrations/feishu/cases", method="POST", body=body)

def create_interception(tracking_no, open_id, command):
    return api_request(
        "/api/integrations/feishu/interceptions",
        method="POST",
        body={"trackingNo": tracking_no, "openId": open_id, "command": command},
    )

def create_tear_off(text, tracking_no, product_info, open_id):
    return api_request(
        "/api/integrations/feishu/tear-off-tasks",
        method="POST",
        body={
            "text": text,
            "trackingNo": tracking_no,
            "productInfo": product_info,
            "openId": open_id,
        },
    )

def resolve_tear_off(task_id, result, open_id):
    return api_request(
        f"/api/integrations/feishu/tear-off-tasks/{task_id}/warehouse",
        method="PATCH",
        body={"result": result, "openId": open_id},
    )

def format_interception_reply(result):
    title = "该单号已经登记过拦截" if result.get("duplicate") else "拦截记录已登记"
    returned = "已退回入库" if result.get("returnedAt") else "尚未退回"
    return (
        f"{title}\n"
        f"快递公司：{result.get('carrier') or '未知'}\n"
        f"快递单号：{result.get('trackingNo') or '-'}\n"
        f"拦截时间：{result.get('interceptedAtText') or '-'}\n"
        f"退回状态：{returned}"
    )

def normalize_parsed_result(parsed):
    result = dict(parsed or {})
    warnings = list(result.get("warnings") or [])
    source_items = result.get("items") if isinstance(result.get("items"), list) else []
    if not source_items:
        source_items = [{
            "model": result.get("model") or result.get("productSku") or "",
            "productName": result.get("productName") or result.get("model") or "",
            "quantity": result.get("quantity") or 1,
            "color": result.get("color") or "",
        }]
    items = []
    for source in source_items:
        item = dict(source or {})
        model = str(item.get("model") or item.get("productSku") or "").strip()
        color = str(item.get("color") or "").strip()
        # 6600 only has one grey business color. Other models keep grey
        # ambiguous because they may have several grey colour numbers.
        if model == "6600" and color in {"灰", "灰色"}:
            item["color"] = "高级灰"
        items.append(item)

    if any(item.get("model") == "6600" and item.get("color") == "高级灰" for item in items):
        warnings = [
            warning for warning in warnings
            if not ("灰色" in str(warning) and "色号" in str(warning))
        ]
    result["items"] = items
    if items:
        result["model"] = items[0].get("model") or ""
        result["productName"] = items[0].get("productName") or result["model"]
        result["quantity"] = items[0].get("quantity") or 1
        result["color"] = items[0].get("color") or ""
    result["warnings"] = warnings
    result["needReview"] = bool(warnings)
    return result

def reply_text(message_id, text):
    client = get_client()
    req = (
        ReplyMessageRequest.builder()
        .message_id(message_id)
        .request_body(
            ReplyMessageRequestBody.builder()
            .msg_type("text")
            .content(json.dumps({"text": text}, ensure_ascii=False))
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.reply(req)
    if not resp.success():
        raise RuntimeError(f"回复消息失败：{resp.msg} (code={resp.code})")
    return resp.data

def reply_card(message_id, card):
    client = get_client()
    card_json = card if isinstance(card, str) else json.dumps(card, ensure_ascii=False)
    req = (
        ReplyMessageRequest.builder()
        .message_id(message_id)
        .request_body(
            ReplyMessageRequestBody.builder()
            .msg_type("interactive")
            .content(card_json)
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.reply(req)
    if not resp.success():
        raise RuntimeError(f"回复卡片失败：{resp.msg} (code={resp.code})")
    return resp.data

def update_card(message_id, card):
    client = get_client()
    card_json = card if isinstance(card, str) else json.dumps(card, ensure_ascii=False)
    req = (
        PatchMessageRequest.builder()
        .message_id(message_id)
        .request_body(
            PatchMessageRequestBody.builder()
            .content(card_json)
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.patch(req)
    if not resp.success():
        raise RuntimeError(f"更新卡片失败：{resp.msg} (code={resp.code})")
    return resp.data

def as_dict(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return {}
        return value if isinstance(value, dict) else {}
    return {}

def event_to_dict(data):
    if isinstance(data, dict):
        return data
    try:
        marshaled = lark.JSON.marshal(data)
    except Exception:
        return {}
    return as_dict(marshaled) if isinstance(marshaled, str) else as_dict(marshaled)

def extract_text(content):
    if isinstance(content, str):
        parsed = as_dict(content)
        if not parsed:
            return content.strip()
        content = parsed
    return str(as_dict(content).get("text") or "").strip()

def mark_once(message_id):
    with _processed_lock:
        if message_id in _processed_ids:
            return False
        _processed_ids.add(message_id)
        _processed_order.append(message_id)
        while len(_processed_order) > 5000:
            _processed_ids.discard(_processed_order.popleft())
        return True

def set_pending(open_id, text, parsed, card_message_id=""):
    with _pending_lock:
        _pending_create[open_id] = {
            "text": text,
            "parsed": parsed,
            "card_message_id": card_message_id,
            "created_at": time.time(),
        }
        while len(_pending_create) > MAX_PENDING:
            oldest_key = min(
                _pending_create, key=lambda k: _pending_create[k]["created_at"]
            )
            _pending_create.pop(oldest_key, None)

def get_pending(open_id):
    with _pending_lock:
        entry = _pending_create.get(open_id)
        if not entry:
            return None
        if time.time() - entry["created_at"] > PENDING_TTL_SECONDS:
            _pending_create.pop(open_id, None)
            return None
        return entry

def clear_pending(open_id, expected_text=None):
    with _pending_lock:
        entry = _pending_create.get(open_id)
        if expected_text is not None and entry and entry.get("text") != expected_text:
            return None
        return _pending_create.pop(open_id, None)

def handle_create_request(message_id, open_id, text):
    try:
        parsed = normalize_parsed_result(parse_text(text))
    except Exception as exc:
        log("解析失败", error=exc, open_id=open_id)
        try:
            reply_text(message_id, f"解析失败：{exc}\n请稍后再试，或联系管理员。")
        except Exception:
            pass
        return

    order_no = parsed.get("orderNo") or ""
    if not order_no:
        try:
            reply_text(
                message_id,
                "没有识别到订单号。\n"
                "请确保消息中包含完整的订单号，例如：\n"
                "260708-560380003972903 补发两个6600灰",
            )
        except Exception:
            pass
        return

    remember_context(open_id, order_no=order_no, text=text)

    try:
        existing = query_case(order_no)
        if existing.get("found"):
            reply_card(message_id, build_existing_case_card(existing))
            return
    except Exception:
        pass

    try:
        card_result = reply_card(message_id, build_parse_card(parsed, text))
        card_message_id = card_result.message_id or ""
    except Exception as exc:
        log("发送确认卡片失败", error=exc)
        try:
            from bot_logic import format_parse_result
            reply_text(message_id, format_parse_result(parsed, text))
        except Exception:
            pass
        card_message_id = ""

    set_pending(open_id, text, parsed, card_message_id)

def handle_confirm(message_id, open_id, trigger_from_card=False, action_value=None):
    action_value = action_value if isinstance(action_value, dict) else {}
    pending = get_pending(open_id)
    action_text = str(action_value.get("text") or "").strip()
    action_order_no = str(action_value.get("order_no") or "").strip()
    if not pending and not action_text:
        if not trigger_from_card:
            try:
                reply_card(
                    message_id,
                    build_result_card(
                        "没有待确认的建单请求",
                        "请直接发送售后信息，例如：\n260708-560380003972903 补发两个6600灰",
                        "grey",
                    ),
                )
            except Exception:
                pass
        return

    pending_text = str((pending or {}).get("text") or "").strip()
    source_text = action_text or pending_text
    card_message_id = (
        str(message_id or "").strip()
        if trigger_from_card
        else str((pending or {}).get("card_message_id") or "").strip()
    )
    if not action_order_no:
        action_order_no = str(((pending or {}).get("parsed") or {}).get("orderNo") or "").strip()

    try:
        # The API is the single source of truth for parsing. A card click is an
        # explicit human confirmation, so unmatched catalog text is preserved.
        result = create_case(source_text, open_id, confirmed=True)
        clear_pending(open_id, expected_text=source_text)

        if card_message_id:
            try:
                update_card(card_message_id, build_create_success_card(result))
                log("飞书建单成功（卡片已更新）", open_id=open_id,
                    case_no=(result.get("case") or {}).get("caseNo") or "-")
                return
            except Exception as exc:
                log("更新卡片失败，改用回复", error=exc)

        if message_id and not trigger_from_card:
            reply_card(message_id, build_create_success_card(result))
        log("飞书建单成功", open_id=open_id,
            case_no=(result.get("case") or {}).get("caseNo") or "-")
    except RuntimeError as exc:
        if "HTTP 409" in str(exc):
            clear_pending(open_id, expected_text=source_text)
            existing = None
            if action_order_no:
                try:
                    existing = query_case(action_order_no)
                except Exception:
                    existing = None
            if card_message_id:
                try:
                    card = (
                        build_existing_case_card(existing)
                        if existing and existing.get("found")
                        else build_result_card(
                            "该订单已有售后单",
                            "系统未重复创建。你可以直接发送订单号查询最新进度。",
                            "orange",
                        )
                    )
                    update_card(card_message_id, card)
                    return
                except Exception:
                    pass
            try:
                reply_text(
                    message_id,
                    "该订单已有售后单，不能重复创建。\n"
                    "你可以直接发送订单号查询进度，或联系管理员确认。",
                )
            except Exception:
                pass
            return
        log("建单失败", error=exc, open_id=open_id)
        try:
            reply_text(message_id, f"建单失败：{exc}\n请稍后再试，或联系管理员。")
        except Exception:
            pass
    except Exception as exc:
        log("建单异常", error=exc, open_id=open_id)
        try:
            reply_text(message_id, f"建单失败：{exc}\n请稍后再试，或联系管理员。")
        except Exception:
            pass

def handle_cancel(open_id, card_message_id="", expected_text=None):
    pending = clear_pending(open_id, expected_text=expected_text)
    if not pending:
        return "没有待确认的建单请求。"

    if card_message_id:
        try:
            update_card(
                card_message_id,
                build_result_card("已取消建单", "如有需要，可以重新发送售后信息。", "grey"),
            )
            return None
        except Exception:
            pass
    return "已取消建单。"

def handle_ai_fallback(message_id, open_id, text, bound_user):
    if not BAILIAN_API_KEY:
        return False
    try:
        result = interpret_with_bailian(
            text=text,
            context=get_context(open_id),
            api_key=BAILIAN_API_KEY,
            base_url=BAILIAN_BASE_URL,
            model=BAILIAN_MODEL,
            timeout=BAILIAN_TIMEOUT_SECONDS,
        ) or {}
    except Exception as exc:
        log("阿里云 AI 路由失败，使用原有帮助", error=exc.__class__.__name__)
        return False

    intent = result.get("intent") or "unknown"
    order_no = result.get("order_no") or ""
    resolved_text = result.get("resolved_text") or ""
    log("阿里云 AI 识别完成", intent=intent, open_id=open_id)

    if intent == "query" and order_no:
        try:
            payload = query_case(order_no)
            reply_card(message_id, build_query_card(payload))
            remember_context(open_id, order_no=order_no, text=text)
        except Exception as exc:
            log("AI 路由后的订单查询失败", error=exc)
            reply_text(message_id, "订单查询暂时失败，请稍后重试。")
        return True

    if intent == "create" and resolved_text:
        handle_create_request(message_id, open_id, resolved_text)
        return True

    if intent == "scanner":
        try:
            reply_card(message_id, build_scanner_card())
        except Exception:
            reply_text(message_id, "请打开仓库扫码：https://frao.cn/?page=scanner")
        return True

    if intent == "interception" and result.get("tracking_no"):
        try:
            created = create_interception(
                result["tracking_no"], open_id, result.get("command") or "拦截"
            )
            reply_text(message_id, format_interception_reply(created))
        except Exception as exc:
            detail = str(exc).split(": ", 1)[-1]
            reply_text(message_id, f"拦截登记失败：{detail}")
        return True

    if intent == "tear_off" and result.get("tracking_no") and result.get("product_info"):
        try:
            created = create_tear_off(
                text, result["tracking_no"], result["product_info"], open_id
            )
            reply_text(
                message_id,
                "退款撕单任务已发起\n"
                f"快递单号：{created.get('tracking_no') or result['tracking_no']}\n"
                f"商品信息：{created.get('product_info') or result['product_info']}\n"
                "已通知仓库确认撕单，并通知打单回收快递单号。",
            )
        except Exception as exc:
            detail = str(exc).split(": ", 1)[-1]
            reply_text(message_id, f"撕单任务发起失败：{detail}")
        return True

    if intent == "unknown" and result.get("reply"):
        reply_text(message_id, result["reply"][:300])
        return True

    return False

def handle_message_raw(event_dict):
    event = as_dict(event_dict.get("event"))
    message = as_dict(event.get("message"))
    message_id = message.get("message_id") or ""
    if not message_id or not mark_once(message_id):
        return

    sender = as_dict(event.get("sender"))
    sender_id = as_dict(sender.get("sender_id"))
    open_id = sender_id.get("open_id") or ""

    msg_type = message.get("message_type") or ""
    if msg_type != "text":
        try:
            reply_text(message_id, "请发送文字消息。\n直接发送订单号可查询，发送售后信息可建单。")
        except Exception:
            pass
        return

    text = extract_text(message.get("content") or "{}")
    log("收到消息", open_id=open_id, msg_type=msg_type, preview=text[:50])

    # Identity lookup must remain available before role checks so a new user can
    # obtain their own Open ID and ask an administrator to bind the account.
    if is_my_id_request(text):
        try:
            if open_id:
                reply_text(
                    message_id,
                    f"你的飞书 Open ID：\n{open_id}\n\n请把这段 ID 发给管理员，在管理后台绑定对应账号。",
                )
            else:
                reply_text(message_id, "暂时没有读取到你的飞书 Open ID，请稍后重试。")
        except Exception as exc:
            log("发送用户ID失败", error=exc)
        return

    try:
        bound_user = bound_user_or_none(open_id)
    except Exception:
        try:
            reply_text(message_id, "账号权限查询暂时失败，请稍后重试。")
        except Exception:
            pass
        return
    if not bound_user:
        try:
            reply_text(
                message_id,
                "当前账号尚未绑定权限。\n发送「我的ID」获取飞书 Open ID，再交给管理员绑定。",
            )
        except Exception:
            pass
        return

    if get_pending(open_id):
        if is_confirm(text):
            handle_confirm(message_id, open_id)
            return
        if is_cancel(text):
            result = handle_cancel(open_id)
            if result:
                try:
                    reply_text(message_id, result)
                except Exception:
                    pass
            return
        clear_pending(open_id)

    if text.strip() in {"扫码", "仓库扫码", "打开扫码", "安能扫码"}:
        try:
            reply_card(message_id, build_scanner_card())
        except Exception:
            reply_text(message_id, "请打开仓库扫码：https://frao.cn/?page=scanner")
        return

    tear_off = extract_tear_off_command(text)
    if tear_off:
        try:
            result = create_tear_off(
                tear_off["text"], tear_off["trackingNo"], tear_off["productInfo"], open_id
            )
            reply_text(
                message_id,
                "退款撕单任务已发起\n"
                f"快递单号：{result.get('tracking_no') or tear_off['trackingNo']}\n"
                f"商品信息：{result.get('product_info') or tear_off['productInfo']}\n"
                "已通知仓库确认撕单，并通知打单回收快递单号。",
            )
        except Exception as exc:
            detail = str(exc).split(": ", 1)[-1]
            try:
                reply_text(message_id, f"撕单任务发起失败：{detail}")
            except Exception:
                pass
        return

    interception = extract_interception_command(text)
    if interception:
        try:
            result = create_interception(
                interception["trackingNo"], open_id, interception["command"]
            )
            reply_text(message_id, format_interception_reply(result))
            log(
                "拦截记录处理完成",
                tracking_no=result.get("trackingNo"),
                carrier=result.get("carrier"),
                duplicate=result.get("duplicate"),
                open_id=open_id,
            )
        except Exception as exc:
            log("拦截记录处理失败", tracking_no=interception["trackingNo"], error=exc)
            try:
                detail = str(exc).split(": ", 1)[-1]
                reply_text(message_id, f"拦截登记失败：{detail}")
            except Exception:
                pass
        return

    order_no = extract_order_query(text)
    if order_no:
        try:
            result = query_case(order_no)
            reply_card(message_id, build_query_card(result))
            remember_context(open_id, order_no=order_no, text=text)
            log("订单查询完成", order_no=order_no, open_id=open_id)
        except Exception as exc:
            log("订单查询失败", order_no=order_no, error=exc)
            try:
                reply_text(message_id, "订单查询暂时失败，请稍后重试；如果持续失败，请联系管理员。")
            except Exception:
                pass
        return

    if looks_like_create_request(text):
        handle_create_request(message_id, open_id, text)
        return

    if handle_ai_fallback(message_id, open_id, text, bound_user):
        return

    help_card = build_result_card(
        "售后助手使用说明",
        "**查询订单**\n直接发送订单号，或发送「查询 + 订单号」\n例如：260708-560380003972903\n\n"
        "**创建售后单**\n发送售后信息，我会识别并让你确认后创建\n例如：260708-560380003972903 补发两个6600灰\n\n"
        "**获取身份 ID**\n发送「我的ID」，获取管理员绑定账号所需的飞书 Open ID\n\n"
        "**登记拦截件**\n发送「快递单号 + 拦截」或「快递单号 + 退回」\n例如：JT5515830658872 拦截\n\n"
        "**退款撕单**\n发送「快递单号 + 撕单 + 商品信息」\n例如：JT5515830658872 撕单 7001大象灰\n\n"
        "**仓库扫码**\n发送「扫码」，在飞书内打开连续扫码页面",
        "blue",
    )
    try:
        reply_card(message_id, help_card)
    except Exception as exc:
        log("发送帮助卡片失败", error=exc)
        try:
            reply_text(
                message_id,
                "你可以这样使用我：\n\n"
                "【查询】直接发送订单号，或发送「查询 + 订单号」\n"
                "例如：260708-560380003972903\n\n"
                "【建单】发送售后信息，我会识别并让你确认后创建\n"
                "例如：260708-560380003972903 补发两个6600灰\n\n"
                "【登记拦截件】发送「快递单号 + 拦截」或「快递单号 + 退回」\n"
                "例如：JT5515830658872 拦截\n\n"
                "【退款撕单】发送「快递单号 + 撕单 + 商品信息」\n"
                "例如：JT5515830658872 撕单 7001大象灰\n\n"
                "【仓库扫码】发送「扫码」打开连续扫码页面",
            )
        except Exception:
            pass

def handle_card_action_raw(event_dict):
    event = as_dict(event_dict.get("event"))
    action = as_dict(event.get("action"))
    value = action.get("value") or {}
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (json.JSONDecodeError, TypeError):
            value = {}

    action_type = value.get("action") or ""

    operator = as_dict(event.get("operator"))
    open_id = ""
    tenant_key = as_dict(operator.get("tenant_key"))
    if tenant_key:
        open_id = tenant_key.get("open_id") or ""
    if not open_id:
        open_id = operator.get("open_id") or ""

    context = as_dict(event.get("context"))
    card_message_id = (
        context.get("open_message_id")
        or event.get("open_message_id")
        or event.get("token")
        or ""
    )

    log("卡片按钮点击", action=action_type, open_id=open_id)

    try:
        bound_user = bound_user_or_none(open_id)
    except Exception:
        return {"toast": {"type": "error", "content": "权限查询失败，请稍后重试"}}
    if not bound_user:
        return {"toast": {"type": "error", "content": "没有操作权限"}}

    def process():
        if action_type == "confirm_create":
            handle_confirm(
                card_message_id or "card_action",
                open_id,
                trigger_from_card=True,
                action_value=value,
            )
        elif action_type == "cancel_create":
            handle_cancel(open_id, card_message_id, expected_text=value.get("text"))
        elif action_type == "tear_off_result":
            resolve_tear_off(value.get("task_id"), value.get("result"), open_id)

    threading.Thread(target=process, daemon=True).start()

    return {"toast": {"type": "info", "content": "处理请求已接收，请稍候"}}

def raw_event_handler(data):
    """原始事件处理函数"""
    try:
        # 尝试各种方式解析 data
        event_dict = None
        if isinstance(data, dict):
            event_dict = data
        elif isinstance(data, str):
            event_dict = json.loads(data)
        elif hasattr(data, '__dict__'):
            try:
                marshaled = lark.JSON.marshal(data)
                if isinstance(marshaled, str):
                    event_dict = json.loads(marshaled)
                elif isinstance(marshaled, dict):
                    event_dict = marshaled
            except Exception:
                event_dict = vars(data)

        if not event_dict:
            log("无法解析事件数据", type=type(data).__name__)
            return None

        header = event_dict.get("header") or event_dict.get("header", {})
        event_type = ""
        if isinstance(header, dict):
            event_type = header.get("event_type") or ""
        elif hasattr(header, "event_type"):
            event_type = header.event_type or ""

        if event_type == "im.message.receive_v1":
            handle_message_raw(event_dict)
            return None
        elif event_type == "card.action.trigger":
            result = handle_card_action_raw(event_dict)
            return result
        # 其他事件忽略
        return None
    except Exception as exc:
        log("事件处理异常", error=exc, type=type(data).__name__)
        import traceback
        log("异常堆栈", trace=traceback.format_exc()[:500])
        return None

def on_message_receive(data):
    event_dict = event_to_dict(data)
    if event_dict:
        handle_message_raw(event_dict)

def card_response(toast_type="info", content=""):
    response = P2CardActionTriggerResponse()
    if content:
        toast = CallBackToast()
        toast.type = toast_type
        toast.content = content
        response.toast = toast
    return response

def on_card_action(data):
    try:
        event = getattr(data, "event", None)
        action = getattr(event, "action", None)
        value = getattr(action, "value", None) or {}
        if isinstance(value, str):
            value = json.loads(value)
        if not isinstance(value, dict):
            value = {}

        action_type = str(value.get("action") or "")
        operator = getattr(event, "operator", None)
        open_id = str(getattr(operator, "open_id", "") or "")
        context = getattr(event, "context", None)
        card_message_id = str(getattr(context, "open_message_id", "") or "")

        log(
            "卡片按钮点击",
            action=action_type or "-",
            open_id=open_id or "-",
            message_id=card_message_id or "-",
        )

        try:
            bound_user = bound_user_or_none(open_id)
        except Exception:
            return card_response("error", "权限查询失败，请稍后重试")
        if not bound_user:
            return card_response("error", "没有操作权限")
        if action_type not in {"confirm_create", "cancel_create", "tear_off_result"}:
            return card_response("error", "无法识别本次操作")

        def process():
            try:
                if action_type == "confirm_create":
                    handle_confirm(
                        card_message_id or "card_action",
                        open_id,
                        trigger_from_card=True,
                        action_value=value,
                    )
                elif action_type == "cancel_create":
                    handle_cancel(open_id, card_message_id, expected_text=value.get("text"))
                else:
                    resolve_tear_off(value.get("task_id"), value.get("result"), open_id)
            except Exception as exc:
                import traceback
                log("卡片按钮后台处理失败", error=exc)
                log("卡片按钮异常堆栈", trace=traceback.format_exc())

        threading.Thread(target=process, daemon=True).start()
        return card_response("info", "处理请求已接收，请稍候")
    except Exception as exc:
        import traceback
        log("卡片回调处理失败", error=exc, data_type=type(data).__name__)
        log("卡片回调异常堆栈", trace=traceback.format_exc())
        return card_response("error", "处理失败，请稍后重试")

def on_message_read(_data):
    return None

def main():
    missing = [
        name
        for name, value in {
            "FEISHU_APP_ID": APP_ID,
            "FEISHU_APP_SECRET": APP_SECRET,
            "FEISHU_INTEGRATION_TOKEN": INTEGRATION_TOKEN,
        }.items()
        if not value
    ]
    if missing:
        raise SystemExit("缺少配置：" + ", ".join(missing))

    get_client()
    log("正在启动飞书长连接", api=AFTER_SALES_API_URL)

    try:
        handler = (
            lark.EventDispatcherHandler.builder("", "")
            .register_p2_im_message_receive_v1(on_message_receive)
            .register_p2_im_message_message_read_v1(on_message_read)
            .register_p2_card_action_trigger(on_card_action)
            .build()
        )
        client = lark.ws.Client(
            APP_ID,
            APP_SECRET,
            event_handler=handler,
            log_level=lark.LogLevel.INFO,
        )
        client.start()
    except Exception as exc:
        log("启动失败", error=exc)
        import traceback
        log(traceback.format_exc())

if __name__ == "__main__":
    main()
