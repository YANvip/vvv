import json

from ai_router import interpret_with_bailian


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self):
        return json.dumps(self.payload, ensure_ascii=False).encode("utf-8")


def test_disabled_without_credentials():
    result = interpret_with_bailian("查上一单", {}, "", "https://example.com/v1", "qwen-plus")
    assert result is None


def test_contextual_query_and_markdown_json():
    captured = {}

    def opener(request, timeout):
        captured["url"] = request.full_url
        captured["body"] = json.loads(request.data.decode("utf-8"))
        captured["timeout"] = timeout
        return FakeResponse({
            "choices": [{
                "message": {
                    "content": "```json\n{\"intent\":\"query\",\"order_no\":\"6927550207970082166\"}\n```"
                }
            }]
        })

    result = interpret_with_bailian(
        "查一下刚才那单",
        {"last_order_no": "6927550207970082166", "last_text": "上一条"},
        "secret-key",
        "https://example.com/compatible-mode/v1/",
        "qwen-plus",
        opener=opener,
    )
    assert result["intent"] == "query"
    assert result["order_no"] == "6927550207970082166"
    assert captured["url"] == "https://example.com/compatible-mode/v1/chat/completions"
    assert "上下文订单号：6927550207970082166" in captured["body"]["messages"][1]["content"]


def test_rejects_unlisted_intent():
    def opener(request, timeout):
        return FakeResponse({
            "choices": [{"message": {"content": '{"intent":"delete_database"}'}}]
        })

    result = interpret_with_bailian(
        "删除全部", {}, "key", "https://example.com/v1", "model", opener=opener
    )
    assert result["intent"] == "unknown"


if __name__ == "__main__":
    test_disabled_without_credentials()
    test_contextual_query_and_markdown_json()
    test_rejects_unlisted_intent()
    print("Bailian router tests passed")
